# Titan Omni Agent Pack

This pack contains:
- 12 pass specifications
- 12 pass prompts for GitHub agents

## Recommended execution order
1. PASS_01_SOURCE_MAP
2. PASS_02_CONVERSATION_GRAPH
3. PASS_03_RECEPTION_ENGINE
4. PASS_04_INTENTS
5. PASS_05_CAMPAIGN_RUNTIME
6. PASS_08_THREAD_LINKING
7. PASS_06_VOICE_LAYER
8. PASS_07_CHANNEL_DRIVERS
9. PASS_09_SENTINEL_SCOUT
10. PASS_10_VERTICAL_OVERLAYS
11. PASS_11_CONSENT_HANDOFF
12. PASS_12_UI_INTEGRATION

## Donor bundles to scan
- zero-repo.zip
- MarketingBot_Integrated_v4_CommsUpgrades.zip
- MarketingBot.zip
- TitanTalk.zip
- TitanHelloBase.zip
- comms.zip
- extension_library.zip
- utilities.zip

## Reminder
Use the host as canonical truth.
Do not rebuild from scratch.
Prefer reuse → extend → refactor → repair → replace.
