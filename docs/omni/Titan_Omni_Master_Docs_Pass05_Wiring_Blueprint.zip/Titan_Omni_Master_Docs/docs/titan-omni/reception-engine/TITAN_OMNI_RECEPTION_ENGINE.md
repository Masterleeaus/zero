# Titan Omni Reception Engine

## Routing model

channel → identity → contact → object → intent → destination

## Destinations

- AI receptionist
- human queue
- escalation queue
- workflow
- booking capture
- unresolved thread

## Destination governance

Reception does not execute business workflows directly.  
It emits routed work to downstream human, automation, or orchestration layers.

## Inbound rules

- keep unmatched identities as first-class records
- preserve tenant boundary before any merge
- attach to contact/site/job/quote/invoice/issue when evidence exists
- escalate low-confidence matching instead of forcing merges

## Merge basis

This document combines:
- Omni pass 03 reception engine
- Titan Comms reception architecture
- Zero contact identity + state machine + triage guidance
