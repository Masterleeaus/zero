# Channel Driver Interface Standard

Drivers:

SmsDriver
EmailDriver
WhatsappDriver
TelegramDriver
MessengerDriver
VoiceDriver
WebChatDriver

Interface:

receive()
send()
status()
retry()
attachIdentity()

Each driver must:

map delivery states
support fallback routing
store attachments
emit automation hooks
