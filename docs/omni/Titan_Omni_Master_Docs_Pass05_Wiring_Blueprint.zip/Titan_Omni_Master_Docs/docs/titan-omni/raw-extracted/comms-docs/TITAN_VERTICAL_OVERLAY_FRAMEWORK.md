# Vertical Overlay Framework

Overlay Components:

OverlayTemplate
OverlayOffer
OverlayScript
OverlayQualificationRule
OverlayComplianceRule
OverlayWorkflowLink
OverlayPromptPack

Overlay Responsibilities:

modify routing
adjust cadence
inject prompts
enforce compliance
attach workflows
