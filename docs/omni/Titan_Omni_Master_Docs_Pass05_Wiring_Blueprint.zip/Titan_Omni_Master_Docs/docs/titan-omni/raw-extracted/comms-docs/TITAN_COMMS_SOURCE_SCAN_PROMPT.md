# Titan Comms Source Scan Prompt

Agent must scan:

CodeToUse/
MarketingBotIntegrated
TitanTalk
TitanHello
comms.zip
extension_library.zip

Detect reusable:

channel drivers
campaign engines
identity bindings
message ledgers
call session handlers
automation triggers
template engines

Output:

docs/TITAN_COMMS_SOURCE_MAP.md
