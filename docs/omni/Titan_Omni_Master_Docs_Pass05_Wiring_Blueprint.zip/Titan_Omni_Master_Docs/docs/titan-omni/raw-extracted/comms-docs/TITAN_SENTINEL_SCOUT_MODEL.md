# Sentinel / Scout Model

Sentinel:

intent resolution
conversation routing
workflow linking
overlay selection
handoff decisions
escalation triggers

Scout Agents:

lead sourcing
followups
reminders
qualification
booking capture
sequence execution
contact enrichment

Tools:

SendMessageTool
StartSequenceTool
AttachConversationTool
ClassifyIntentTool
ScheduleFollowupTool
CreateLeadTool
EscalateConversationTool
