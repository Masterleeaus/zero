# Titan Reception Engine

Pipeline:

Inbound Signal
→ Identity Resolution
→ Contact Match
→ Object Link
→ Intent Classification
→ Routing Decision
→ Destination

Destinations:

Sentinel
Scout
Workflow
Queue
Human
Automation

Outputs:

thread creation
task generation
workflow trigger
campaign start
escalation event
