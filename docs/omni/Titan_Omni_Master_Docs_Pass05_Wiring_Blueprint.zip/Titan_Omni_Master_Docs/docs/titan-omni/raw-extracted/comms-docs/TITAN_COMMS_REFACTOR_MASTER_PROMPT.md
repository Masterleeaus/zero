# Titan Comms Refactor Master Prompt

Goal:

Convert MarketingBotIntegrated into Titan Comms Core

Steps:

1. rename marketing entities
2. create canonical conversation graph
3. implement receptionist routing
4. integrate telephony donors
5. normalize channel drivers
6. attach operational object links
7. add intent classification layer
8. enable overlay runtime support
9. expose Sentinel / Scout tools

Constraints:

no duplicate schema
extend existing logic
preserve tenancy
document all integrations
