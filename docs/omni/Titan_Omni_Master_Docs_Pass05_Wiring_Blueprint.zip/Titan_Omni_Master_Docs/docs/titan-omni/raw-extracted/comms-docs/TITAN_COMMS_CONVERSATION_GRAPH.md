# Titan Conversation Graph Model

Core Entities:

Contact
ContactIdentity
ChannelAccount
Conversation
ConversationParticipant
Message
MessageDelivery
MessageAttachment
CallSession
CallEvent
CommsThreadLink
CommsAutomationEvent
ConversationIntent

Rules:

- tenant scoped by company_id
- channel agnostic
- object-attachable
- audit safe
