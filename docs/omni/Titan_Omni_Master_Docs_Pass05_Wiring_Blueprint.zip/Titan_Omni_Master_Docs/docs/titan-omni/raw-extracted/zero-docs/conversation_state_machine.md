# Conversation State Machine

This is an agent-facing lifecycle model for Titan Comms / Omni planning.

## Core states

1. **ingested** — a channel event enters the system
2. **identified** — sender/contact/company resolution is attempted
3. **linked** — conversation is attached to a contact, site, job, quote, invoice, or issue where possible
4. **triaged** — routed to receptionist AI, human inbox, queue, automation, or draft response path
5. **awaiting_action** — requires human decision, approval, or outbound response
6. **in_progress** — active reply or workflow underway
7. **resolved** — request answered or workflow completed
8. **archived** — closed but retained in inbox ledger / history

## Cross-cutting rules

- The **conversation** belongs to Comms even when triggered by Work or Money.
- Entity links should be additive; a conversation can be related to more than one object over time.
- Channel delivery status belongs at the message/event level, not the conversation level.
- Approval-sensitive outbound actions should emit signals rather than execute directly.
