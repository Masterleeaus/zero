# Tenant Boundary Rules for Comms

1. `company_id` is the tenant boundary for new Worksuite-based comms integrations.
2. A conversation ledger must never mix messages from different companies.
3. Contact matching must be tenant-scoped first, then channel-scoped, then global only if an explicit cross-tenant rule exists.
4. Extensions may share code, but not conversation data, identities, or delivery state across tenants.
5. Telephony, mailbox, SMS, and social channel adapters should emit company-scoped events into the inbox or signal pipeline.
