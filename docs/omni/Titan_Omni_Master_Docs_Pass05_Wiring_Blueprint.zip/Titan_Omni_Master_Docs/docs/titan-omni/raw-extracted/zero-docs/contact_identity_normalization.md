# Contact Identity Normalization

Use this when building unified inbox, receptionist, or cross-channel identity logic.

## Goals

- Resolve multiple channel handles to one contact when confidence is sufficient.
- Preserve raw channel identity even when a canonical contact is known.
- Keep company tenancy boundaries intact during identity merges.

## Identity layers

1. raw channel identity — phone number, email, handle, channel account id
2. canonical contact — CRM-level person or organization record
3. scoped linkage — site, job, invoice, issue, or campaign relevance
4. trust/confidence metadata — how certain the linkage is

## Safety rules

- Never collapse identities across tenant/company boundaries.
- Keep original channel identifiers for audit and replay.
- Prefer additive linking over destructive merging during early passes.
