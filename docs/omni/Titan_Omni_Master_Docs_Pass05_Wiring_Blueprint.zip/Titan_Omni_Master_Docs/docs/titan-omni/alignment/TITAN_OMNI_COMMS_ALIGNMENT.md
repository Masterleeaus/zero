# Titan Omni Comms Alignment

Titan Comms contributes the reception, conversation, campaign, and overlay frame.  
Titan Omni becomes the canonical execution-oriented documentation bundle for that stack.
