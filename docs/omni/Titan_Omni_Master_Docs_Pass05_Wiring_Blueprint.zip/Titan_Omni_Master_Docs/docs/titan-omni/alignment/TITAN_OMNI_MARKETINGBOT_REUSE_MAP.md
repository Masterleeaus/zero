# Titan Omni MarketingBot Reuse Map

MarketingBot is the main donor for campaign runtime logic:
- contact/list segmentation
- channel-specific campaign dispatch
- delivery tracking
- follow-up sequence patterns
