# Titan Omni Zero Alignment

Omni sits inside Titan Zero as the communications execution layer.  
Zero remains the broader orchestration and signal-governance layer.
