# Titan Omni Namespace Map

## Suggested namespace layout

- App\TitanOmni\Models\*
- App\TitanOmni\Services\Identity\*
- App\TitanOmni\Services\Routing\*
- App\TitanOmni\Services\Drivers\*
- App\TitanOmni\Services\Sequences\*
- App\TitanOmni\Services\Policies\*
- App\TitanOmni\Http\Controllers\*
- App\TitanOmni\Providers\*
- App\TitanOmni\Support\*

## Alternative if integrated into existing Titan structure

- App\Services\TitanOmni\*
- App\Http\Controllers\TitanOmni\*
- App\Models\TitanOmni\*

## Rule

Choose one namespace tree and keep providers, routes, controllers, and models aligned to it. Do not create parallel trees for the same concern.
