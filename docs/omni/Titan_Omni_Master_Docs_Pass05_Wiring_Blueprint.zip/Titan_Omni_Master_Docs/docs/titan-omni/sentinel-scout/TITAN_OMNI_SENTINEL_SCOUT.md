# Titan Omni Sentinel / Scout

## Sentinel responsibilities

- intent resolution
- conversation routing
- workflow linking
- overlay selection
- handoff decisions
- escalation triggers
- validation checkpoints

## Scout responsibilities

- lead sourcing
- followups
- reminders
- qualification
- booking capture
- sequence execution
- contact enrichment

## Exposed tools

- SendMessageTool
- StartSequenceTool
- AttachConversationTool
- ClassifyIntentTool
- ScheduleFollowupTool
- CreateLeadTool
- EscalateConversationTool

## Merge basis

This doc merges Omni pass expectations with Zero Sentinel/Scout layers and validation checkpoints.
