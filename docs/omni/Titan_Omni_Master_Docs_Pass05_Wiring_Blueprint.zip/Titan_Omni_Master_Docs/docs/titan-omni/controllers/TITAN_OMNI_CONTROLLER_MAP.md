# Titan Omni Controller Map

## Ingress controllers
- OmniInboundController
- OmniWebhookController
- OmniVoiceWebhookController

## Conversation controllers
- OmniConversationController
- OmniThreadAttachController
- OmniIntentController

## Dispatch controllers
- OmniSendController
- OmniDeliveryStatusController
- OmniRetryController

## Sequence controllers
- OmniSequenceController
- OmniSequenceRunController

## Admin / ops controllers
- OmniDriverRegistryController
- OmniHandoffRuleController
- OmniOverlayBindingController

## Principle

Controllers should stay thin and delegate to services. They should not contain matching, routing, or sequence logic directly.
