# Titan Omni Architecture

Titan Omni is the communications execution engine inside Titan Zero.

## Canonical stack

1. **Reception Layer**  
   Inbound payload intake, identity resolution, contact match, object link, intent classification, destination routing.

2. **Conversation Graph**  
   Cross-channel message and thread ledger with additive linking to host objects.

3. **Campaign Runtime**  
   Outbound automation for nurture, reminders, rebooking, feedback recovery, promotions, and receptionist sequences.

4. **Channel Driver Layer**  
   Transport adapters for SMS, email, WhatsApp, Telegram, Messenger, voice, and web chat.

5. **Sentinel / Scout Layer**  
   Sentinel handles triage and routing policy. Scout handles follow-up, capture, sequence execution, and enrichment.

6. **Growth / Vertical Overlay Runtime**  
   Compliance, cadence, prompt, and workflow specialization by vertical and mode.

## Ownership boundaries

Omni does **not** own CRM, Jobs, or Finance.  
Omni links communications to host objects instead of duplicating those domains.

## Source merge basis

This canonical document was rebuilt from:
- Omni base pass pack
- Titan Comms docs
- Titan Zero comms-and-omni docs
