# Titan Omni Overlay Runtime

## Overlay components

- OverlayTemplate
- OverlayOffer
- OverlayScript
- OverlayQualificationRule
- OverlayComplianceRule
- OverlayWorkflowLink
- OverlayPromptPack

## Responsibilities

- modify routing
- adjust cadence
- inject prompts
- enforce compliance
- attach workflows

## Zero alignment

Overlays operate as mode/vertical adjustments to routing and execution.  
They should not create parallel comms stacks.
