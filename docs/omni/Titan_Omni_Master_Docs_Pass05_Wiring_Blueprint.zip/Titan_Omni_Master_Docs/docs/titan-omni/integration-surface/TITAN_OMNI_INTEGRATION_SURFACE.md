# Titan Omni Integration Surface

## Omni inside Titan Zero

Omni is the communications execution engine.

## Connected surfaces

- signal processing
- workflow triggers
- object linking
- assistant tools
- mode routing
- AI orchestration layers

## Signals

- `message.received`
- `message.sent`
- `conversation.escalated`
- `assistant.intervened`

## Explicit non-duplication rules

- no duplicate CRM ownership
- no duplicate Jobs ownership
- no duplicate Finance ownership
- no parallel conversation data across tenants
