# Titan Omni Provider Map

## Proposed provider split

- OmniServiceProvider
- ConversationGraphServiceProvider
- ReceptionEngineServiceProvider
- ChannelDriverRegistryProvider
- CampaignRuntimeProvider
- SentinelScoutProvider
- OverlayRuntimeProvider

## Responsibilities

### OmniServiceProvider
Bootstrap config, core bindings, route loading, event subscriptions.

### ConversationGraphServiceProvider
Bind conversation, message, delivery, attachment, and thread-link repositories/services.

### ReceptionEngineServiceProvider
Bind identity resolution, contact matching, triage, and routing pipeline services.

### ChannelDriverRegistryProvider
Register channel drivers and fallback order resolution.

### CampaignRuntimeProvider
Bind sequence runtime, scheduling, delay evaluation, and dispatch orchestration.

### SentinelScoutProvider
Bind intent resolution, handoff decisions, escalation logic, and scout sequence tools.

### OverlayRuntimeProvider
Bind overlay rules, compliance injection, cadence changes, and vertical prompt packs.
