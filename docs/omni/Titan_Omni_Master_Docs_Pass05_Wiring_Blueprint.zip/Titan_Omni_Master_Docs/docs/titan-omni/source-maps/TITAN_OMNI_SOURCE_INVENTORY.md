# Titan Omni Source Inventory

## Base used first

### Omni base
- `Titan_Omni_Pass_Docs_v2.zip`
  - `INDEX.md`
  - `Pass_Specs/PASS_01_SOURCE_MAP.md`
  - `Pass_Specs/PASS_02_CONVERSATION_GRAPH.md`
  - `Pass_Specs/PASS_03_RECEPTION_ENGINE.md`
  - `Pass_Specs/PASS_04_INTENTS.md`
  - `Pass_Specs/PASS_05_CAMPAIGN_RUNTIME.md`
  - `Pass_Specs/PASS_06_VOICE_LAYER.md`
  - `Pass_Specs/PASS_07_CHANNEL_DRIVERS.md`
  - `Pass_Specs/PASS_08_THREAD_LINKING.md`
  - `Pass_Specs/PASS_09_SENTINEL_SCOUT.md`
  - `Pass_Specs/PASS_10_VERTICAL_OVERLAYS.md`
  - `Pass_Specs/PASS_11_CONSENT_HANDOFF.md`
  - `Pass_Specs/PASS_12_UI_INTEGRATION.md`
  - `Pass_Prompts/*`

## Added next

### Titan Comms docs
- `TITAN_COMMS_ARCHITECTURE.md`
- `TITAN_COMMS_CONVERSATION_GRAPH.md`
- `TITAN_RECEPTION_ENGINE.md`
- `TITAN_CHANNEL_DRIVER_STANDARD.md`
- `TITAN_SENTINEL_SCOUT_MODEL.md`
- `TITAN_VERTICAL_OVERLAY_FRAMEWORK.md`
- `TITAN_COMMS_SOURCE_SCAN_PROMPT.md`
- `TITAN_COMMS_REFACTOR_MASTER_PROMPT.md`

### Titan Zero relevant docs
- `DOC81_Comms_Mode_Blueprint.md`
- `DOC91_Comms_Mode_Execution_Prompt.md`
- `COMMS_TRIAGE_PLAN.md`
- `contact_identity_normalization.md`
- `conversation_state_machine.md`
- `tenant_boundary_rules.md`
- `intent_router.yaml`
- `channel_connector_registry.yaml`
- `comms.yaml`
- `DOC11_Sentinel_Layer.md`
- `DOC12_Scout_Layer.md`
- `DOC23_Mode_Lifecycle_Overlays.md`
- `DOC24_Sentinel_Validation_Checkpoints.md`
- `WORKSUITE_VOICE_FIRST_PWA_ARCHITECTURE.pdf`
