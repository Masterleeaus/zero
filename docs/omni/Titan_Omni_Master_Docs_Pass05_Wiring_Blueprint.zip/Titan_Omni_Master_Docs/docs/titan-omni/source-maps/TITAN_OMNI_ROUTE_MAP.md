# Titan Omni Route Map

## Core ingress routes

- `titan.omni.receive`
- `titan.omni.send`
- `titan.omni.status`
- `titan.omni.retry`

## Conversation routes

- `titan.omni.conversation.open`
- `titan.omni.conversation.attach`
- `titan.omni.conversation.intent`
- `titan.omni.conversation.escalate`

## Sequence routes

- `titan.omni.sequence.start`
- `titan.omni.sequence.stop`
- `titan.omni.sequence.status`
- `titan.omni.sequence.preview`

## Admin / ops routes

- `titan.omni.drivers.index`
- `titan.omni.handoffs.index`
- `titan.omni.overlays.index`

## Rule

Keep transport ingress channel-agnostic. Controllers should only validate, delegate to services, and return delivery-safe responses.
