# Titan Omni Table Map

## Canonical table set

- omni_contacts
- omni_contact_identities
- omni_channel_accounts
- omni_conversations
- omni_conversation_participants
- omni_messages
- omni_message_deliveries
- omni_message_attachments
- omni_call_sessions
- omni_call_events
- omni_thread_links
- omni_automation_events
- omni_conversation_intents

## Table rules

- `company_id` tenancy everywhere
- append-only audit-safe message history
- original channel IDs retained
- channel delivery tracked separately from conversation state
