# Titan Omni Conversation Graph

## Canonical entities

- Contact
- ContactIdentity
- ChannelAccount
- Conversation
- ConversationParticipant
- Message
- MessageDelivery
- MessageAttachment
- CallSession
- CallEvent
- CommsThreadLink
- CommsAutomationEvent
- ConversationIntent

## Core rules

- `company_id` is the tenant boundary
- raw channel identity is preserved for audit and replay
- contact linking is additive, not destructive
- attachment and delivery state live at message/event level
- one conversation can link to multiple host objects over time

## Lifecycle

ingested → identified → linked → triaged → awaiting_action → in_progress → resolved → archived

## Why this model

The Zero docs add:
- tenant boundary rules
- contact identity normalization
- conversation state machine

The Omni base adds:
- target entity list
- pass outputs
- thread-linking expectations
