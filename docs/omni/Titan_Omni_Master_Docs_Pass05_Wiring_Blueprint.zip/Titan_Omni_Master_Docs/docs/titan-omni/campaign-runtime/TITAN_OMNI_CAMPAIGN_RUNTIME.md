# Titan Omni Campaign Runtime

## Supported outbound flows

- lead nurture
- quote reminders
- invoice reminders
- rebooking flows
- feedback recovery
- promotions
- receptionist sequences

## Runtime chain

Sequence → Step → Delay → Channel → Template → Condition → Dispatch

## Donor logic

Campaign runtime is primarily reused from:
- MarketingBot
- MarketingBot_Integrated_v4_CommsUpgrades
- Titan Comms conceptual layer

## Boundary rule

Campaign runtime executes communications sequences only.  
It must link back to host objects and Titan Zero signals for approval-sensitive actions.
