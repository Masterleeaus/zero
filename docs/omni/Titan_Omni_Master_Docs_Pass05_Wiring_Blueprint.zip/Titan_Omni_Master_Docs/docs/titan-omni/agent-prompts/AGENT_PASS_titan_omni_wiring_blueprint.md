# Agent Pass — Titan Omni Wiring Blueprint

## Objective

Use the canonical Omni docs bundle to create implementation-ready:
- migrations
- model classes
- service providers
- service bindings
- route files
- thin controllers
- config files

## Rules

- preserve `company_id` tenancy
- no duplicate CRM / Jobs / Finance ownership
- channel drivers stay transport-only
- routing logic stays in services
- build additive migrations only
- preserve audit/event history

## Required outputs

- migration files
- model map implementation
- provider registration
- route registration
- driver registry
- controller stubs with service calls
