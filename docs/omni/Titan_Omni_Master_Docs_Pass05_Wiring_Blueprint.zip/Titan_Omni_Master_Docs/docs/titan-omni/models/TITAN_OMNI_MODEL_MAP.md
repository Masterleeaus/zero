# Titan Omni Model Map

## Identity models
- OmniContact
- OmniContactIdentity
- OmniChannelAccount

## Conversation models
- OmniConversation
- OmniConversationParticipant
- OmniConversationIntent
- OmniThreadLink

## Message models
- OmniMessage
- OmniMessageDelivery
- OmniMessageAttachment

## Voice models
- OmniCallSession
- OmniCallEvent

## Runtime models
- OmniSequence
- OmniSequenceStep
- OmniSequenceRun
- OmniAutomationEvent

## Policy / overlay models
- OmniOverlayBinding
- OmniHandoffRule
- OmniConsentRecord

## Relationship notes

- OmniContact has many OmniContactIdentity
- OmniConversation has many OmniMessage
- OmniMessage has many OmniMessageDelivery
- OmniConversation may link to many host objects through thread links
- OmniSequenceRun belongs to a sequence and a target conversation/contact
