# Titan Omni Config Surface

## Config groups
- omni.channels
- omni.drivers
- omni.routing
- omni.sequences
- omni.overlays
- omni.handoffs
- omni.consent
- omni.audit

## Example settings
- enabled channels by company
- provider credentials / key indirection
- retry policy
- fallback order
- consent enforcement mode
- handoff confidence thresholds
- attachment retention policy
