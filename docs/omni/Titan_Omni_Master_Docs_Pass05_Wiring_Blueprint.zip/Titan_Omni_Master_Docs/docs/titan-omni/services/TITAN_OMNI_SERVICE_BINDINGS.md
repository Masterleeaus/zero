# Titan Omni Service Bindings

## Core services
- IdentityResolutionService
- ContactMatchService
- ConversationLinkService
- IntentClassificationService
- ReceptionRoutingService
- DeliveryTrackingService
- SequenceExecutionService
- OverlayResolutionService
- ConsentPolicyService
- HandoffDecisionService

## Driver services
- SmsDriver
- EmailDriver
- WhatsappDriver
- TelegramDriver
- MessengerDriver
- VoiceDriver
- WebChatDriver

## Registry
- ChannelDriverRegistry

## Service flow

Inbound payload
→ IdentityResolutionService
→ ContactMatchService
→ ConversationLinkService
→ IntentClassificationService
→ ReceptionRoutingService
→ destination

## Binding guidance

Bind interfaces in service providers, keep driver registration centralized, and avoid business-domain ownership inside Omni services.
