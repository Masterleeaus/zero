# Titan Omni Schema Blueprint

This pass converts the merged Omni docs into a build-ready schema layer.

## Canonical persistence domains

1. Identity
2. Conversation graph
3. Messaging + delivery
4. Calls + events
5. Automation + sequences
6. Overlay bindings
7. Object links + audit

## Table family

### Identity
- omni_contacts
- omni_contact_identities
- omni_channel_accounts

### Conversation graph
- omni_conversations
- omni_conversation_participants
- omni_thread_links
- omni_conversation_intents

### Messaging
- omni_messages
- omni_message_deliveries
- omni_message_attachments

### Voice / calls
- omni_call_sessions
- omni_call_events

### Automation
- omni_sequences
- omni_sequence_steps
- omni_sequence_runs
- omni_automation_events

### Overlay / policy
- omni_overlay_bindings
- omni_handoff_rules
- omni_consent_records

## Global rules

- `company_id` is mandatory on every tenant-owned table
- external provider IDs must be preserved
- append-only event tables stay immutable except retry metadata
- all state changes should be representable through events, not destructive overwrite
