# Titan Omni Migration Plan

## Recommended migration order

1. omni_contacts
2. omni_contact_identities
3. omni_channel_accounts
4. omni_conversations
5. omni_conversation_participants
6. omni_conversation_intents
7. omni_thread_links
8. omni_messages
9. omni_message_deliveries
10. omni_message_attachments
11. omni_call_sessions
12. omni_call_events
13. omni_sequences
14. omni_sequence_steps
15. omni_sequence_runs
16. omni_automation_events
17. omni_overlay_bindings
18. omni_handoff_rules
19. omni_consent_records

## Key indexes

- company_id + channel
- company_id + external_identity
- company_id + conversation_id + created_at
- company_id + message_id + delivery_status
- company_id + sequence_id + active

## Safety notes

- use additive migrations
- do not mutate host CRM / Jobs / Finance tables here
- object links should reference host objects generically or via thread-link tables
