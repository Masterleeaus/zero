# Titan Omni Channel Drivers

## Standard driver interface

- `receive()`
- `send()`
- `status()`
- `retry()`
- `attachIdentity()`

## Drivers

- SmsDriver
- EmailDriver
- WhatsappDriver
- TelegramDriver
- MessengerDriver
- VoiceDriver
- WebChatDriver

## Required behavior

- delivery-state tracking
- fallback routing
- attachment persistence
- automation hooks
- company-scoped event emission

## Zero integration notes

Titan Zero adds a connector registry and comms manifest slice.  
That makes the driver layer a reusable transport surface, not a business-domain owner.
