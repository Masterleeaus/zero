# Pass 4 — Intent Layer

## Objective
Add conversation intent detection and routing intelligence.

## Starter intents
- booking_request
- quote_followup
- invoice_query
- reschedule
- complaint
- lead_response
- campaign_reply
- compliance_ack
- escalation_required

## Outputs
- docs/TITAN_OMNI_INTENTS.md
- docs/TITAN_OMNI_ROUTING_RULES.md
