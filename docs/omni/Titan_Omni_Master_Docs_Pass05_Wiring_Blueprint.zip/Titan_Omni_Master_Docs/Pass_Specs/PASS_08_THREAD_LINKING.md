# Pass 8 — Thread Linking

## Objective
Link conversations to operational host objects.

## Attachments
- customer
- site
- job
- quote
- invoice
- issue
- campaign
- workflow

## Outputs
- docs/TITAN_OMNI_THREAD_LINKING.md
- docs/TITAN_OMNI_OBJECT_ATTACHMENT_RULES.md
