# Pass 1 — Source Map

## Objective
Deep-scan the repo, host, docs, and donor bundles to build the factual Titan Omni reuse map before any implementation.

## Scan first
- repo root
- docs/
- CodeToUse/
- mobile_apps/
- zero-repo.zip
- MarketingBot_Integrated_v4_CommsUpgrades.zip
- MarketingBot.zip
- TitanTalk.zip
- TitanHelloBase.zip
- comms.zip
- extension_library.zip
- utilities.zip

## Outputs
- docs/TITAN_OMNI_SOURCE_MAP.md
- docs/TITAN_OMNI_HOST_OVERLAP_MAP.md
- docs/TITAN_OMNI_REUSE_PLAN.md

## Core questions
- what already exists in host
- what donor logic is reusable
- what must be extended
- what must not be recreated
- what operational objects Omni must connect to
