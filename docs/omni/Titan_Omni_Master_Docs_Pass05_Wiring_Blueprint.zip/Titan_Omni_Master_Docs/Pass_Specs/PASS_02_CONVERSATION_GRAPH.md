# Pass 2 — Conversation Graph

## Objective
Create the canonical conversation graph as the single truth for cross-channel communications.

## Target entities
- Contact
- ContactIdentity
- ChannelAccount
- Conversation
- ConversationParticipant
- Message
- MessageDelivery
- MessageAttachment
- CallSession
- CallEvent
- CommsThreadLink
- CommsAutomationEvent
- ConversationIntent

## Outputs
- docs/TITAN_OMNI_CONVERSATION_GRAPH.md
- docs/TITAN_OMNI_TABLE_MAP.md
- docs/TITAN_OMNI_THREAD_MODEL.md
