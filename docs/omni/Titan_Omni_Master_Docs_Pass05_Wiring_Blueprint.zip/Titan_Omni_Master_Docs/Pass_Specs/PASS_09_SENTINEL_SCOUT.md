# Pass 9 — Sentinel & Scout

## Objective
Add agent orchestration without bypassing Titan Zero / Titan Core.

## Sentinel
- intent routing
- escalation
- overlay selection

## Scout
- follow-ups
- enrichment
- booking capture

## Outputs
- docs/TITAN_OMNI_SENTINEL_SCOUT_MODEL.md
- docs/TITAN_OMNI_TOOL_SURFACES.md
