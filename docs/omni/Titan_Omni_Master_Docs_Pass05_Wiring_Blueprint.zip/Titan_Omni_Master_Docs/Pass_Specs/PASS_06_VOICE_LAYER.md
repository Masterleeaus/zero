# Pass 6 — Voice Layer

## Objective
Merge TitanTalk and TitanHelloBase into the same Omni conversation graph.

## Components
- VoiceChannelDriver
- CallSessionManager
- CallTranscriptStore
- VoiceIntentResolver

## Outputs
- docs/TITAN_OMNI_VOICE_LAYER.md
- docs/TITAN_OMNI_CALL_SESSION_MODEL.md
