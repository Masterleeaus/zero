# Pass 11 — Consent & Handoff

## Objective
Harden consent, unsubscribe, and marketing → operations ownership transitions.

## Focus
- consent model
- opt-out
- Duo handoff
- timeline/backfeed

## Outputs
- docs/TITAN_OMNI_CONSENT_AND_HANDOFF.md
