# GitHub Agent Prompt — Pass 8 Titan Omni Thread Linking

Deep-scan the repo, host object models, and previous Omni docs first.

## Objective
Link conversations to host operational objects.

## Required links
- conversation → customer
- conversation → site
- conversation → job
- conversation → quote
- conversation → invoice
- conversation → issue
- conversation → campaign
- conversation → workflow

## Use
- CommsThreadLink

## Rules
- no duplicate host entities
- link instead of copy
- preserve audit trail and cross-channel continuity

## Required outputs
- docs/TITAN_OMNI_THREAD_LINKING.md
- docs/TITAN_OMNI_OBJECT_ATTACHMENT_RULES.md
- docs/AGENT_PASS_titan_omni_pass08.md
