# GitHub Agent Prompt — Pass 9 Titan Omni Sentinel / Scout

Deep-scan the repo, Omni docs, AI donor bundles, and assistant/chat logic first.

## Objective
Add Sentinel and Scout orchestration to Titan Omni without bypassing Titan Zero / Titan Core.

## Sentinel responsibilities
- intent resolution
- conversation routing
- workflow linking
- handoff decisions
- escalation triggers
- overlay selection

## Scout responsibilities
- lead sourcing
- follow-ups
- sequence execution
- reminders
- qualification
- booking capture
- contact enrichment

## Expose or extend tools
- SendMessageTool
- StartSequenceTool
- AttachConversationTool
- ClassifyIntentTool
- ScheduleFollowupTool
- CreateLeadTool
- EscalateConversationTool

## Required outputs
- docs/TITAN_OMNI_SENTINEL_SCOUT_MODEL.md
- docs/TITAN_OMNI_TOOL_SURFACES.md
- docs/AGENT_PASS_titan_omni_pass09.md
