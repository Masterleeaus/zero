# GitHub Agent Prompt — Pass 1 Titan Omni Source Map

Deep-scan the current repository and all project-source donor archives before making any changes.

## Mandatory scan targets
Repository:
- repo root
- app/
- routes/
- database/
- resources/
- config/
- docs/
- CodeToUse/
- mobile_apps/
- .github/agent-docs/

Project sources:
- zero-repo.zip (latest host truth)
- MarketingBot_Integrated_v4_CommsUpgrades.zip
- MarketingBot.zip
- TitanTalk.zip
- TitanHelloBase.zip
- comms.zip
- extension_library.zip
- utilities.zip
- socialmedia.zip if comms-adjacent helpers exist

## Task
Produce a factual source map for Titan Omni.
Do not implement yet.
Do not infer from filenames.
Inspect actual contents and overlaps.

## Required outputs
Create:
- docs/TITAN_OMNI_SOURCE_MAP.md
- docs/TITAN_OMNI_HOST_OVERLAP_MAP.md
- docs/TITAN_OMNI_REUSE_PLAN.md
- docs/AGENT_PASS_titan_omni_pass01.md

## Must answer
- what already exists in the host
- what donor logic is reusable
- what must be extended
- what must not be duplicated
- what operational objects Omni must connect to
- what comms-related schemas/routes/providers already exist
