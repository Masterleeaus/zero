# GitHub Agent Prompt — Pass 7 Titan Omni Channel Drivers

Deep-scan the repo, Omni docs, and donor channel abstractions first.

## Objective
Normalize channel drivers so the conversation graph remains channel-agnostic.

## Drivers
- SmsDriver
- EmailDriver
- WhatsappDriver
- TelegramDriver
- MessengerDriver
- VoiceDriver
- WebChatDriver

## Methods
- receive()
- send()
- status()
- retry()
- attachIdentity()

## Rules
- preserve central delivery state
- centralize message audit trail
- reuse existing transport/provider logic if available

## Required outputs
- docs/TITAN_OMNI_CHANNEL_DRIVERS.md
- docs/TITAN_OMNI_DELIVERY_STATE_MODEL.md
- docs/AGENT_PASS_titan_omni_pass07.md
