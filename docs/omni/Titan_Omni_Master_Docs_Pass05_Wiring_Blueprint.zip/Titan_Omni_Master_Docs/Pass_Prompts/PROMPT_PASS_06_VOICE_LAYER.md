# GitHub Agent Prompt — Pass 6 Titan Omni Voice Layer

Deep-scan the repo, Omni docs, TitanTalk donor, and TitanHelloBase donor first.

## Objective
Merge voice and call logic into the same Omni conversation graph.

## Build or extend
- VoiceChannelDriver
- CallSessionManager
- CallTranscriptStore
- VoiceIntentResolver

## Rules
- attach voice sessions to conversations
- attach call events to thread history
- do not build isolated telephony stack
- preserve Titan Hello voice authority and Titan Go/Talk donor roles

## Required outputs
- docs/TITAN_OMNI_VOICE_LAYER.md
- docs/TITAN_OMNI_CALL_SESSION_MODEL.md
- docs/AGENT_PASS_titan_omni_pass06.md
