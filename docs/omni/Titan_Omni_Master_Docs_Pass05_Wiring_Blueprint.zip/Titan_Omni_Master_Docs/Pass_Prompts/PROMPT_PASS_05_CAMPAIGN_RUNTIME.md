# GitHub Agent Prompt — Pass 5 Titan Omni Campaign Runtime

Deep-scan the repo and Omni docs first.

## Objective
Generalize MarketingBot runtime into Titan Omni outbound campaign and outreach engine.

## Support
- lead nurture
- quote follow-up
- overdue invoice reminders
- rebooking campaigns
- feedback recovery
- promotions
- outbound receptionist sequences
- vertical outreach sequences

## Core entities
- Campaign
- CampaignAudience
- CampaignStep
- CampaignRun
- CampaignMessage
- CampaignResponse
- Offer
- Sequence
- LeadSource

## Rules
- preserve host operational ownership
- no marketing-only framing
- outbound actions must link back to conversations and operational objects

## Required outputs
- docs/TITAN_OMNI_CAMPAIGN_RUNTIME.md
- docs/TITAN_OMNI_SEQUENCE_MODEL.md
- docs/AGENT_PASS_titan_omni_pass05.md
