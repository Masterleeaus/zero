# GitHub Agent Prompt — Pass 4 Titan Omni Intents

Deep-scan the repository and previous Omni docs first.

## Objective
Add conversation intent detection and routing intelligence.

## Build or extend
- ConversationIntent
- IntentClassifier
- IntentResolver
- IntentOverride

## Starter intents
- booking_request
- quote_followup
- invoice_query
- reschedule
- complaint
- lead_response
- campaign_reply
- compliance_ack
- escalation_required

## Important rules
- route through Titan Zero / Titan Core authority where AI is involved
- do not bypass host confirmation/risk rules
- reuse classifier/chat logic from donor bundles if present

## Required outputs
- docs/TITAN_OMNI_INTENTS.md
- docs/TITAN_OMNI_ROUTING_RULES.md
- docs/AGENT_PASS_titan_omni_pass04.md
