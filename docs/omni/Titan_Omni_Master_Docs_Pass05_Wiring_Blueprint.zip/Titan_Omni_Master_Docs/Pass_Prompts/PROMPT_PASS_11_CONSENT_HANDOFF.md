# GitHub Agent Prompt — Pass 11 Titan Omni Consent and Handoff

Deep-scan the constitution docs, CustomerConnect/ownership docs, and current Omni docs first.

## Objective
Harden consent handling, opt-out, and marketing → operations ownership transitions.

## Focus
- consent model
- unsubscribe handling
- Duo handoff
- timeline/backfeed handling
- ownership cut-over clarity

## Rules
- operational comms live in the host system of record
- no silent ownership duplication
- preserve audit trail and consent state

## Required outputs
- docs/TITAN_OMNI_CONSENT_AND_HANDOFF.md
- docs/AGENT_PASS_titan_omni_pass11.md
