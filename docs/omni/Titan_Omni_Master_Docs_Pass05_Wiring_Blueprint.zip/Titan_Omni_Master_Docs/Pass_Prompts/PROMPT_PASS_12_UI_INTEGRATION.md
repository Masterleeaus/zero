# GitHub Agent Prompt — Pass 12 Titan Omni UI Integration

Deep-scan the host UI structure, route/menu patterns, and previous Omni docs first.

## Objective
Normalize Titan Omni UI and host integration.

## Scope
- inbox UI
- receptionist queue
- diagnostics
- admin settings
- menu placement
- route normalization
- linked-object side panels
- campaign runtime UI polish

## Rules
- fit native host Blade/theme patterns
- preserve named routes where possible
- no duplicate navigation trees

## Required outputs
- docs/TITAN_OMNI_UI_INTEGRATION.md
- docs/TITAN_OMNI_ROUTE_MAP.md
- docs/AGENT_PASS_titan_omni_pass12.md
