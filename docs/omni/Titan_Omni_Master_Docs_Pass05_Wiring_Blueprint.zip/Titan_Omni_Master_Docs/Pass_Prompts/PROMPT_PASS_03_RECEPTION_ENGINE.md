# GitHub Agent Prompt — Pass 3 Titan Omni Reception Engine

Deep-scan the repository and Pass 1/2 docs first.

## Objective
Build the inbound receptionist engine for Titan Omni.

## Routing model
channel → identity → contact → linked object → intent → destination

## Destinations
- AI receptionist
- human queue
- escalation queue
- workflow
- booking capture
- unresolved thread

## Core responsibilities
- receive inbound comms
- identify sender/contact/company
- attach to customer/site/job/quote/invoice/issue
- route to AI/human/workflow
- preserve thread continuity
- create follow-up actions and signals

## Required outputs
- docs/TITAN_OMNI_RECEPTION_ENGINE.md
- docs/TITAN_OMNI_INBOUND_ROUTING.md
- docs/TITAN_OMNI_UNMATCHED_THREAD_RULES.md
- docs/AGENT_PASS_titan_omni_pass03.md
