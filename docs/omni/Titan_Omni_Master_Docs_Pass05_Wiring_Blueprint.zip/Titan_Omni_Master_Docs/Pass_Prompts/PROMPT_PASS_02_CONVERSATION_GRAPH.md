# GitHub Agent Prompt — Pass 2 Titan Omni Conversation Graph

Deep-scan the repository again first, plus the outputs from Pass 1.

## Objective
Build or extend the canonical Titan Omni conversation graph as the single source of truth for all channel conversations.

## Required entities
- Contact
- ContactIdentity
- ChannelAccount
- Conversation
- ConversationParticipant
- Message
- MessageDelivery
- MessageAttachment
- CallSession
- CallEvent
- CommsThreadLink
- CommsAutomationEvent
- ConversationIntent

## Rules
- tenant scoped via company_id
- channel-agnostic
- attachable to CRM + Jobs + Finance objects
- preserve existing host structures where possible
- do not create duplicate contact/customer silos

## Required outputs
- docs/TITAN_OMNI_CONVERSATION_GRAPH.md
- docs/TITAN_OMNI_TABLE_MAP.md
- docs/TITAN_OMNI_THREAD_MODEL.md
- docs/AGENT_PASS_titan_omni_pass02.md
