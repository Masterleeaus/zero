# GitHub Agent Prompt — Pass 10 Titan Omni Vertical Overlays

Deep-scan the repo, Omni docs, and growth/sector donor bundles first.

## Objective
Add reusable vertical growth overlays above the shared Omni core.

## Registry
- VerticalOverlay
- OverlayTemplate
- OverlayOffer
- OverlayScript
- OverlayQualificationRule
- OverlayComplianceRule
- OverlayWorkflowLink
- OverlayPromptPack

## Initial overlays
- Cleaning
- Medical Equipment
- Trades
- Home Services

## Rules
- overlays modify behavior, not ownership
- no separate silo systems
- same core graph, same inbox, same reception engine

## Required outputs
- docs/TITAN_OMNI_VERTICAL_OVERLAYS.md
- docs/TITAN_OMNI_OVERLAY_REGISTRY.md
- docs/AGENT_PASS_titan_omni_pass10.md
