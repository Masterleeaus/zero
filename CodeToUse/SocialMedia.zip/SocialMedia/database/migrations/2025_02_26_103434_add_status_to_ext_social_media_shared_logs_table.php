<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ext_social_media_shared_logs', function (Blueprint $table) {
            $table->string('status')
                ->nullable()
                ->after('response');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ext_social_media_shared_logs', function (Blueprint $table) {
            $table->dropColumn('status');
        });
    }
};
