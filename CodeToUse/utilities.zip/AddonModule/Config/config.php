<?php

return [
    'name' => 'AddonModule'
];
