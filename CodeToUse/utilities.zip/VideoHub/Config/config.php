<?php

return [
    'name' => 'VideoHub'
];
