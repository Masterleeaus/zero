<?php

return [
    'name' => 'BusinessSettingsModule'
];
