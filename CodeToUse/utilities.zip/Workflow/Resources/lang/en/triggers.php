<?php

return [
  'title' => 'Triggers',
];
