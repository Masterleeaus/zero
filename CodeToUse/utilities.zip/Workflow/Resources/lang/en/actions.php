<?php

return [
  'title' => 'Actions',
];
