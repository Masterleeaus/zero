# QRTrack Module (Worksuite)

**Alias:** `qrtrack`

## Install
1. Copy `Modules/QRTrack` into your project.
2. Run:
   ```bash
   composer dump-autoload -o
   php artisan optimize:clear
   php artisan migrate
   php artisan route:list | grep qrtrack
   ```

## Permissions
- `view_qrtrack`

## Routes
- `GET /qrtrack` → `qrtrack.index`

## Notes
- Providers: `QRTrackServiceProvider`, `RouteServiceProvider`, `EventServiceProvider`
- Views namespace: `qrtrack::`
