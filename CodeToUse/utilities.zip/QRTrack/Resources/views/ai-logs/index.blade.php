@extends('layouts.app')
@section('content')
<div class="card p-3">
  <h5>AI Logs</h5>
  <table class="table table-sm table-striped">
    <thead>
      <tr>
        <th>ID</th><th>User</th><th>Tool</th><th>Status</th><th>Created</th>
      </tr>
    </thead>
    <tbody>
      @foreach($logs as $log)
      <tr>
        <td>{{ $log->id }}</td>
        <td>{{ optional($log->user)->name ?? 'N/A' }}</td>
        <td>{{ $log->tool }}</td>
        <td>{{ $log->status }}</td>
        <td>{{ $log->created_at }}</td>
      </tr>
      @endforeach
    </tbody>
  </table>
  {{ $logs->links() }}
</div>
@endsection
