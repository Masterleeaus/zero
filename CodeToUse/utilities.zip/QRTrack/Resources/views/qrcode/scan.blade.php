@php($has = !empty($code))
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>QR Scan — {{ $slug }}</title>
  <meta name="robots" content="noindex">
  <style>
    body { font-family: system-ui, Arial, sans-serif; margin: 24px; }
    .muted { color:#666; font-size: 12px; }
    .box { border:1px solid #eee; padding:16px; border-radius:8px; }
    .btn { display:inline-block; padding:10px 14px; border:1px solid #333; text-decoration:none; color:#333; border-radius:6px; }
  </style>
</head>
<body>
  <h1>QR {{ $has ? 'Linked' : 'Unknown' }}</h1>
  <div class="box">
    <div class="muted">Slug: <code>{{ $slug }}</code></div>
    @if($has)
      <p>Label: <strong>{{ $code->label }}</strong></p>
      @if(!empty($code->meta['redirect_url']))
        <p><a class="btn" href="{{ $code->meta['redirect_url'] }}">Open linked document</a></p>
      @else
        <p class="muted">No redirect configured for this QR.</p>
      @endif
    @else
      <p class="muted">No QR record exists for this slug.</p>
    @endif
  </div>
</body>
</html>
