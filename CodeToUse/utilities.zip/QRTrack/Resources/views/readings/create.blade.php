@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Record Reading — {{ $code->name }}</h1>
    <form method="POST" action="{{ route('qrtrack.readings.store', ['slug' => $code->slug]) }}">
        @csrf
        <div class="mb-3">
            <label class="form-label">Reading Type</label>
            <input type="text" name="reading_type" class="form-control" placeholder="meter, temperature, psi, checkin" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Value</label>
            <input type="number" step="0.0001" name="reading_value" class="form-control" placeholder="e.g., 123.45">
        </div>
        <div class="mb-3">
            <label class="form-label">Unit</label>
            <input type="text" name="unit" class="form-control" placeholder="kWh, °C, PSI">
        </div>
        <div class="mb-3">
            <label class="form-label">Notes</label>
            <textarea name="notes" class="form-control" rows="3" placeholder="Optional notes..."></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Save Reading</button>
    </form>
</div>
@endsection
