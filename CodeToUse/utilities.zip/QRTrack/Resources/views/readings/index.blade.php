@extends('layouts.app')

@section('content')
<div class="container">
    <h1>QR — Readings</h1>
    <table class="table table-striped">
        <thead><tr><th>When</th><th>Type</th><th>Value</th><th>Unit</th><th>Notes</th></tr></thead>
        <tbody>
        @foreach($latest as $r)
            <tr>
                <td>{{ $r->recorded_at ?? $r->created_at }}</td>
                <td>{{ $r->reading_type }}</td>
                <td>{{ $r->reading_value }}</td>
                <td>{{ $r->unit }}</td>
                <td>{{ $r->notes }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <hr>
    <h3>Preview QR (example)</h3>
    <p>Replace <code>{slug}</code> with an actual QR slug to preview its image.</p>
    <img src="{{ route('qrtrack.image.show', ['slug' => $latest->first()->qrCode->slug ?? 'example']) }}" alt="QR" style="max-width:256px">
</div>
@endsection

