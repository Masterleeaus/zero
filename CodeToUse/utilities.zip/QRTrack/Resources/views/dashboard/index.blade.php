
<x-cards.layout>
    <x-slot name="header">
        <div class="d-flex align-items-center justify-content-between">
            <h3 class="mb-0">@lang('modules.module.qrtrack') — Dashboard</h3>
        </div>
    </x-slot>
    <div class="row">
        <div class="col-md-4"><x-cards.widget :title="__('Active QR Assets')" value="—" icon="fa-solid fa-qrcode" /></div>
        <div class="col-md-4"><x-cards.widget :title="__('Scans (30d)')" value="—" icon="fa-solid fa-chart-line" /></div>
        <div class="col-md-4"><x-cards.widget :title="__('Locations')" value="—" icon="fa-solid fa-location-dot" /></div>
    </div>
</x-cards.layout>
