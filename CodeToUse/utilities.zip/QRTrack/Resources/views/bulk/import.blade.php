@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Import QR Codes from CSV</h1>
    <div class="alert alert-info">CSV headers: <code>name, slug, target_type, target_id</code>. Slug optional.</div>
    <form method="POST" action="{{ route('qrtrack.bulk.import') }}" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <input type="file" name="csv" accept=".csv,text/csv" class="form-control" required>
        </div>
        <button class="btn btn-primary">Upload & Create</button>
    </form>
</div>
@endsection
