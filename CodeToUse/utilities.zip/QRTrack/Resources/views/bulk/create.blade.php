@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Bulk Create QR Codes</h1>
    <form method="POST" action="{{ route('qrtrack.bulk.store') }}">
        @csrf
        <div class="row">
            <div class="col-md-3">
                <label class="form-label">Count</label>
                <input type="number" name="count" value="10" min="1" max="1000" class="form-control">
            </div>
            <div class="col-md-3">
                <label class="form-label">Prefix</label>
                <input type="text" name="prefix" value="asset" class="form-control">
            </div>
            <div class="col-md-3">
                <label class="form-label">Target Type</label>
                <input type="text" name="target_type" placeholder="asset, room, work_order" class="form-control">
            </div>
            <div class="col-md-3">
                <label class="form-label">Target ID Start</label>
                <input type="number" name="target_id_start" class="form-control" placeholder="optional">
            </div>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary">Create</button>
            <a class="btn btn-outline-secondary" href="{{ route('qrtrack.bulk.import.form') }}">Import CSV</a>
        </div>
    </form>
</div>
@endsection
