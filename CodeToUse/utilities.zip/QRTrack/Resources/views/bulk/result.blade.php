@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Created QR Codes</h1>
    <div class="mb-3">
        <a class="btn btn-outline-primary" href="{{ route('qrtrack.labels.print', ['ids' => $codes->pluck('id')->join(',')]) }}">Print Stickers (A4)</a>
    </div>
    <table class="table table-striped">
        <thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>QR</th><th>Scan URL</th></tr></thead>
        <tbody>
        @foreach($codes as $c)
            <tr>
                <td>{{ $c->id }}</td>
                <td>{{ $c->name }}</td>
                <td>{{ $c->slug }}</td>
                <td><img src="{{ route('qrtrack.image.show', ['slug' => $c->slug]) }}" style="width:64px"></td>
                <td>{{ url(config('qrtrack.qr.url_prefix').$c->slug) }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@endsection
