@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Generate & Print — One Click</h1>
    @if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
    <form method="POST" action="{{ route('qrtrack.quick.run') }}">
        @csrf
        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Count</label>
                <input type="number" name="count" value="20" min="1" max="500" class="form-control">
            </div>
            <div class="col-md-3">
                <label class="form-label">Prefix</label>
                <input type="text" name="prefix" value="site" class="form-control">
            </div>
            <div class="col-md-3">
                <label class="form-label">Layout</label>
                <select name="layout" class="form-select">
                    <option value="l7160">Avery L7160 (3x7)</option>
                    <option value="a4-3x8">A4 3x8</option>
                    <option value="single">Single (custom mm)</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Margins (mm)</label>
                <input type="number" name="margin_mm" value="2" class="form-control">
            </div>
            <div class="col-md-3">
                <label class="form-label">Custom Width (mm)</label>
                <input type="number" name="mm_w" class="form-control" placeholder="e.g., 50 for Zebra">
            </div>
            <div class="col-md-3">
                <label class="form-label">Custom Height (mm)</label>
                <input type="number" name="mm_h" class="form-control" placeholder="e.g., 25 for Zebra">
            </div>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary">Generate & Queue to Printer</button>
            <a class="btn btn-outline-secondary" href="{{ route('qrtrack.labels.print', ['layout'=>'l7160','ids'=>'']) }}">Download PDF (manual)</a>
        </div>
    </form>
</div>
@endsection
