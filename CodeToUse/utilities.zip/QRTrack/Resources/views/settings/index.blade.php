@extends('layouts.app')
@section('content')
<div class="container">
    <h1>QRTrack Settings</h1>
    @if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif

    <form method="POST" action="{{ route('qrtrack.settings.save') }}" class="mb-4">
        @csrf
        <div class="card mb-3">
            <div class="card-header">Short Links</div>
            <div class="card-body row g-3">
                <div class="col-md-6">
                    <label class="form-label">Short Domain</label>
                    <input type="text" class="form-control" name="short[domain]" value="{{ data_get($vals,'short.domain') }}" placeholder="qrz.one">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Base Path</label>
                    <input type="text" class="form-control" name="short[base_path]" value="{{ data_get($vals,'short.base_path','/s/') }}">
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header">Branding</div>
            <div class="card-body row g-3">
                <div class="col-md-8">
                    <label class="form-label">Title</label>
                    <input type="text" class="form-control" name="branding[title]" value="{{ data_get($vals,'branding.title') }}" placeholder="Tradie Smart">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Current Logo</label><br>
                    @php $logo = data_get($vals,'branding.logo_path'); @endphp
                    @if($logo)
                        <img src="{{ Storage::url(str_replace('public/','',$logo)) }}" style="max-height:50px">
                    @else
                        <em>No logo uploaded</em>
                    @endif
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header">PrintNode</div>
            <div class="card-body row g-3">
                <div class="col-md-4">
                    <label class="form-label">Printer ID</label>
                    <input type="number" class="form-control" name="printnode[printer_id]" value="{{ data_get($vals,'printnode.printer_id') }}">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Scale</label>
                    <select class="form-select" name="printnode[scale]">
                        @foreach(['noscale','fit','fill'] as $opt)
                            <option value="{{ $opt }}" @selected(data_get($vals,'printnode.scale','noscale')===$opt)>{{ strtoupper($opt) }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>

        <button class="btn btn-primary">Save Settings</button>
    </form>

    <form method="POST" action="{{ route('qrtrack.settings.logo') }}" enctype="multipart/form-data">
        @csrf
        <div class="card">
            <div class="card-header">Upload Logo</div>
            <div class="card-body">
                <input type="file" name="logo" accept="image/*" class="form-control" required>
                <button class="btn btn-secondary mt-2">Upload</button>
            </div>
        </div>
    </form>
</div>
@endsection
