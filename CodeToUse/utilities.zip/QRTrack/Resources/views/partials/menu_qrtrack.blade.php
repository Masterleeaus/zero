@canqrtrack('qrtrack.view')
<li class="{{ request()->routeIs('qrtrack.*') ? 'active' : '' }}">
@if(Route::has('qrtrack.dashboard'))
    <a href="{{ route('qrtrack.dashboard') }}">
@endif
        <i class="fa fa-qrcode"></i> <span>QR Track</span>
    </a>
</li>
@endcanqrtrack