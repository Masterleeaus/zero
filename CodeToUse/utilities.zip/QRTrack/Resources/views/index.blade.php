@extends('layouts.app')

@section('content')
<div class="container">
    <div class="card">
        <div class="card-body">
            <h1>QRCode Module</h1>
            <p>This is the scaffolded index view for <code>qrcode</code>.</p>
        </div>
    </div>
</div>
@endsection

@include('qrtrack::sections.ai-assistant')
@include('qrtrack::sections.ai-actions')
