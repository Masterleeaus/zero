<div class="card mt-3 p-3">
  <h5>AI-Powered QR Actions ⚡</h5>
  <div class="d-flex flex-wrap gap-2">
    <button class="btn btn-outline-primary" onclick="runAITool('qr_summary')">🧾 Summary</button>
    <button class="btn btn-outline-info" onclick="runAITool('predict_missing')">📈 Predict Missing</button>
    <button class="btn btn-outline-warning" onclick="runAITool('qr_audit')">🔍 Find Issues</button>
    <button class="btn btn-outline-success" onclick="runAITool('qr_pdf')">🧰 Report PDF</button>
    <button class="btn btn-outline-secondary" onclick="runAITool('qr_help')">💬 Smart Help</button>
  </div>
  <pre id="aiToolResponse" class="bg-dark text-white p-3 mt-3 small" style="min-height:100px;"></pre>
</div>

<script>
async function runAITool(tool) {
  document.getElementById('aiToolResponse').innerText = 'Running '+tool+'...';
  const res = await fetch('{{ route("qrtrack.ai.tool") }}', {
    method: 'POST',
    headers: {'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Content-Type': 'application/json'},
    body: JSON.stringify({ tool })
  });
  const data = await res.json();
  document.getElementById('aiToolResponse').innerText =
    data.message || JSON.stringify(data, null, 2);
}
</script>
