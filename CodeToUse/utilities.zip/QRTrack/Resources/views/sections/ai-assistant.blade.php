<div id="aicopilot-chat" class="card p-3 mt-3">
    <h5 class="mb-2">Smart QR Assistant</h5>
    <textarea id="aiMessage" class="form-control" rows="3" placeholder="Ask about QR jobs, scans, logs, or printing..."></textarea>
    <button class="btn btn-primary mt-2" id="sendAI">Ask AI</button>
    <pre id="aiResponse" class="bg-dark text-white p-2 mt-3 small" style="min-height: 100px;"></pre>
</div>
<script>
(function(){
    const btn = document.getElementById('sendAI');
    if(!btn) return;
    btn.addEventListener('click', async function(){
        const msg = document.getElementById('aiMessage').value;
        const res = await fetch('{{ route("qrtrack.ai.chat") }}', {
            method: 'POST',
            headers: {'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Content-Type': 'application/json'},
            body: JSON.stringify({ message: msg })
        });
        const data = await res.json();
        document.getElementById('aiResponse').innerText = (data && data.reply) ? data.reply : JSON.stringify(data, null, 2);
    });
})();
</script>
