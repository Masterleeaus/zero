@php $user = auth()->user(); @endphp
@if (function_exists('user_modules') ? in_array('qrtrack', user_modules()) : true)
    @if ($user && method_exists($user, 'can') ? $user->can('view_qrtrack') : true)
        <li class="sidebar-item">
@if(Route::has('qrtrack.index'))
            <a class="sidebar-link" href="{{ route('qrtrack.index') }}">
@endif
                <i class="fa fa-qrcode sidebar-icon"></i>
                <span>{{ __('QRTrack') }}</span>
            </a>
        </li>
    @endif
@endif


@if(isset($user) && $user && $user->can('view_ai_logs'))
<li class="sidebar-item">
@if(Route::has('qrtrack.ai.logs'))
  <a href="{{ route('qrtrack.ai.logs') }}" class="sidebar-link">
@endif
    <i class="fa fa-robot sidebar-icon"></i>
    <span>AI Logs</span>
  </a>
</li>
@endif
