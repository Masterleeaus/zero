<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page { size: A4 portrait; margin: 10mm; }
        body { font-family: DejaVu Sans, Arial, sans-serif; }
        .sheet { display: grid; grid-gap: 0; }

        /* Presets (A4 & Thermal) */
        /* Thermal approx: Zebra 50x25mm (2x1"): use single with mm_w=50, mm_h=25 */
        /* Dymo 54x101mm: single with mm_w=54, mm_h=101 */
        /* Avery L7160: 3 columns x 7 rows, label ~63.5 x 38.1 mm */
        @php use Modules\QRTrack\Services\SettingsService; $set = app(SettingsService::class);
            $cols = 3; $rows = 7; $w = 63.5; $h = 38.1; $margin = 2;
            if ($layout === 'a4-3x8') { $cols = 3; $rows = 8; $w = 70; $h = 35; }
            if ($layout === 'single') { $cols = 1; $rows = 1; $w = 90; $h = 50; }
            if (!empty($custom['cols'])) $cols = $custom['cols'];
            if (!empty($custom['rows'])) $rows = $custom['rows'];
            if (!empty($custom['mm_w'])) $w = $custom['mm_w'];
            if (!empty($custom['mm_h'])) $h = $custom['mm_h'];
            if (!empty($custom['margin_mm'])) $margin = $custom['margin_mm'];
        @endphp

        .sheet { grid-template-columns: repeat({{ $cols }}, {{ $w }}mm); }
        .label { width: {{ $w }}mm; height: {{ $h }}mm; padding: {{ $margin }}mm; box-sizing: border-box; display: flex; gap: 4mm; align-items: center; border: 0; }
        .qr { width: calc({{ $h }}mm - {{ $margin*2 }}mm); height: calc({{ $h }}mm - {{ $margin*2 }}mm); }
        .meta { font-size: 10pt; line-height: 1.2; overflow: hidden; }

        .name { font-weight: bold; font-size: 11pt; }
        .slug { color: #444; font-size: 9pt; }
        .url { color: #000; font-size: 8pt; word-break: break-all; }
    </style>
</head>
<body>
<header style="display:flex; align-items:center; gap:8mm; margin-bottom:6mm;">
    @php use Modules\QRTrack\Services\SettingsService; $set = app(SettingsService::class);
        $logo = $set->brandingLogoPath() ? storage_path('app/' . ltrim($set->brandingLogoPath(), '/')) : null;
        $title = $set->brandingTitle() ?: config('app.name', 'QRTrack');
    @endphp
    @if($logo && is_file($logo))
        <img src="{{ $logo }}" style="height:15mm;">
    @endif
    <h2 style="margin:0;">{{ $title }} — QR Labels</h2>
</header>
<div class="sheet">
@foreach($codes as $code)
    @php use Modules\QRTrack\Services\SettingsService; $set = app(SettingsService::class);
        $img = storage_path('app/public/' . ltrim($code->image_path ?? '', '/'));
        $shortUrl = url(config('qrtrack.qr.url_prefix') . $code->slug);
    @endphp
    <div class="label">
        @if(is_file($img))
            <img class="qr" src="{{ $img }}" alt="QR">
        @else
            <div class="qr" style="border:1px solid #000;"></div>
        @endif
        <div class="meta">
            <div class="name">{{ $code->name }}</div>
            <div class="slug">#{{ $code->slug }}</div>
            <div class="url">{{ $shortUrl }}</div>
        </div>
    </div>
@endforeach
</div>
</body>
</html>
