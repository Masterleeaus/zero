@extends('layouts.app')
@section('content')
<div class="container">
    <h1>QRTrack — Print Logs</h1>
    <a class="btn btn-outline-primary mb-3" href="{{ route('qrtrack.logs.export', request()->only('status')) }}">Export CSV</a>
    <table class="table table-striped">
        <thead><tr>
            <th>#</th><th>When</th><th>User</th><th>Codes</th><th>Layout</th><th>Printer</th><th>Status</th>
        </tr></thead>
        <tbody>
        @foreach($logs as $log)
            <tr>
                <td>{{ $log->id }}</td>
                <td>{{ $log->created_at }}</td>
                <td>{{ optional($log->user)->name }}<br><small>{{ optional($log->user)->email }}</small></td>
                <td>{{ is_array($log->code_ids) ? implode(',', $log->code_ids) : $log->code_ids }}</td>
                <td>{{ $log->layout }}</td>
                <td>{{ $log->printer_id }}</td>
                <td>{{ strtoupper($log->status) }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    {{ $logs->links() }}
</div>
@endsection
