<?php
return [
  'title' => 'QRTrack',
  'menu' => 'QRTrack',
];
