<?php

// Module name translations for the QRTrack module.
return ['module' => ['qrtrack' => 'QRTrack']];
