<?php
namespace Modules\QRTrack;

if (!defined('QRTRACK_BOOTSTRAPPED')) define('QRTRACK_BOOTSTRAPPED', true);
