<?php

namespace Modules\QRTrack\Http\Controllers;

use Illuminate\Routing\Controller;
use Modules\QRTrack\Entities\AiLog;

class LogController extends Controller
{
    public function index()
    {
        $logs = AiLog::with('user')->latest()->paginate(20);
        return view('qrtrack::ai-logs.index', compact('logs'));
    }
}
