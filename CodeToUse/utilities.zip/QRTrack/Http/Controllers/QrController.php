<?php

namespace Modules\QRTrack\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\QRTrack\Entities\QrCode;
use Modules\QRTrack\Entities\QrReading;

class QrController extends Controller
{
    public function scan(Request $request, $slug)
    {
        $code = QrCode::query()->where('slug', $slug)->first();
        if (!$code) {
            return response()->view('qrtrack::qrcode.scan', ['slug' => $slug, 'code' => null]);
        }

        // Log a reading
        QrReading::create([
            'qr_code_id' => $code->id,
            'ip' => $request->ip(),
            'user_agent' => (string) $request->userAgent(),
            'referer' => (string) $request->headers->get('referer'),
            'meta' => ['t' => now()->toIso8601String()]
        ]);

        // If redirect_url is present in meta, show a button to continue
        return response()->view('qrtrack::qrcode.scan', ['slug' => $slug, 'code' => $code]);
    }
}
