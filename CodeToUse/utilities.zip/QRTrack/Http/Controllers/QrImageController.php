<?php

namespace Modules\QRTrack\Http\Controllers;

use Illuminate\Routing\Controller;
use Modules\QRTrack\Services\QrImageService;
use Symfony\Component\HttpFoundation\Response;

class QrImageController extends Controller
{
    public function show($slug)
    {
        $png = app(QrImageService::class)->pngFor($slug);
        $bin = base64_decode($png, true);
        if ($bin === false) {
            return response('Invalid QR data', 500);
        }
        return response($bin, 200, [
            'Content-Type' => 'image/png',
            'Cache-Control' => 'public, max-age=86400'
        ]);
    }

    public function regenerate($slug)
    {
        // Simple invalidate and rebuild
        cache()->forget('qrtrack:img:'.$slug);
        return $this->show($slug);
    }
}
