<?php

namespace Modules\QRTrack\Http\Controllers;
use Illuminate\Routing\Controller as BaseController;
class DashboardController extends BaseController {
    public function index() { return view('qrtrack::dashboard.index'); }
}
