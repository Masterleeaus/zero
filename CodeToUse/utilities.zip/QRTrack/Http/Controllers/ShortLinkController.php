<?php

namespace Modules\QRTrack\Http\Controllers;

use Illuminate\Routing\Controller;
use Modules\QRTrack\Entities\QrCode;
use Modules\QRTrack\Services\SettingsService;

class ShortLinkController extends Controller
{
    // Public redirect: /s/{slug} -> /qr/scan/{slug}
    public function redirect(string $slug)
    {
        $code = QrCode::where('slug', $slug)->first();
        if (!$code) abort(404);
        $target = url(config('qrtrack.qr.url_prefix') . $code->slug);
        return redirect()->to($target, 302);
    }
}
