<?php

namespace Modules\QRTrack\Http\Controllers;

use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Modules\QRTrack\Entities\QrCode;
use Modules\QRTrack\Services\QrImageService;

class BulkController extends Controller
{
    public function create()
    {
        return view('qrtrack::bulk.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'count' => 'nullable|integer|min:1|max:1000',
            'prefix' => 'nullable|string|max:40',
            'target_type' => 'nullable|string|max:50',
            'target_id_start' => 'nullable|integer|min:1',
        ]);

        $count = $data['count'] ?? 10;
        $prefix = $data['prefix'] ?? 'qr';
        $targetType = $data['target_type'] ?? null;
        $targetIdStart = $data['target_id_start'] ?? null;

        $svc = app(QrImageService::class);
        $created = [];

        for ($i = 0; $i < $count; $i++) {
            $name = strtoupper($prefix) . ' ' . ($i + 1);
            $slug = Str::slug($prefix . '-' . Str::random(6) . '-' . ($i + 1));

            // Ensure unique slug
            while (QrCode::where('slug', $slug)->exists()) {
                $slug = Str::slug($prefix . '-' . Str::random(6) . '-' . ($i + 1));
            }

            $code = new QrCode([
                'tenant_id' => tenant('id') ?? 0,
                'name' => $name,
                'slug' => $slug,
                'target_type' => $targetType,
                'target_id' => $targetIdStart ? ($targetIdStart + $i) : null,
                'meta' => [],
            ]);
            $code->save();

            // Generate QR image
            try { $svc->makeAndStore($code); } catch (\Throwable $e) {}

            $created[] = $code;
        }

        return view('qrtrack::bulk.result', ['codes' => $created]);
    }

    public function importForm()
    {
        return view('qrtrack::bulk.import');
    }

    public function import(Request $request)
    {
        $request->validate([
            'csv' => 'required|file|mimes:csv,txt|max:20480',
        ]);
        $allowed = collect(config('qrtrack.import.allowed_headers', []))->map(fn($h) => strtolower($h))->all();
        $fh = fopen($request->file('csv')->getRealPath(), 'r');
        $header = fgetcsv($fh);
        if (!$header) abort(422, 'Empty CSV.');
        $header = array_map('strtolower', $header);
        foreach ($header as $h) {
            if (!in_array($h, $allowed)) {
                abort(422, 'Unexpected header: ' . $h);
            }
        }
        $idx = array_flip($header);

        $svc = app(QrImageService::class);
        $created = [];
        while (($row = fgetcsv($fh)) !== false) {
            $name = $row[$idx['name']] ?? null;
            $slug = $row[$idx['slug']] ?? null;
            $targetType = $row[$idx['target_type']] ?? null;
            $targetId = $row[$idx['target_id']] ?? null;

            if (!$name) continue;
            if (!$slug) $slug = Str::slug($name . '-' . Str::random(6));
            // uniquify
            $base = $slug; $n = 1;
            while (QrCode::where('slug', $slug)->exists()) { $slug = $base . '-' . $n++; }

            $code = new QrCode([
                'tenant_id' => tenant('id') ?? 0,
                'name' => $name,
                'slug' => $slug,
                'target_type' => $targetType ?: null,
                'target_id' => is_numeric($targetId) ? (int)$targetId : null,
                'meta' => [],
            ]);
            $code->save();
            try { $svc->makeAndStore($code); } catch (\Throwable $e) {}
            $created[] = $code;
        }
        fclose($fh);

        return view('qrtrack::bulk.result', ['codes' => $created]);
    }
}
