<?php

namespace Modules\QRTrack\Http\Controllers;

use Modules\QRTrack\Entities\AiLog;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Http;

class AiController extends Controller
{
    protected function logAi($tool, $payload, $response, $status = null)
    {
        try {
            $payloadJson = is_string($payload) ? $payload : json_encode($payload);
            $responseJson = is_string($response) ? $response : json_encode($response);
            \Modules\QRTrack\Entities\AiLog::create([
                'user_id' => auth()->id(),
                'company_id' => function_exists('company') && company() ? company()->id : null,
                'tool' => $tool ?: 'chat',
                'request' => substr($payloadJson ?? '', 0, 1000),
                'response_summary' => substr($responseJson ?? '', 0, 1000),
                'status' => $status ?: 'success',
            ]);
        } catch (\Throwable $e) {
            // swallow log errors to avoid breaking UX
        }
    }

    protected string $base;

    public function __construct()
    {
        $this->base = env('AICOPILOT_API', 'https://ai.tradiesm.art');
    }

    public function chat(Request $request)
    {
        $payload = [
            'assistant' => 'main',
            'message' => $request->input('message'),
            'tenant_system_append' => function_exists('company') && company() ? (company()->short_code ?? '') : ''
        ];
        $response = Http::withToken(env('AICOPILOT_KEY'))
            ->post("{$this->base}/api/aicopilot/assistant", $payload);

        
        $this->logAi('chat', $payload ?? request()->all(), isset($response) ? (method_exists($response, 'json') ? $response->json() : $response) : null, (isset($response) && method_exists($response, 'successful') ? ($response->successful() ? 'success' : 'error') : 'success'));
return response()->json($response->json(), $response->status());
    }

    public function generatePdf(Request $request)
    {
        $payload = $request->all();
        $response = Http::withToken(env('AICOPILOT_KEY'))
            ->post("{$this->base}/api/aicopilot/compliance/pdf", $payload);
        $this->logAi('generatePdf', $payload ?? request()->all(), isset($response) ? (method_exists($response, 'json') ? $response->json() : $response) : null, (isset($response) && method_exists($response, 'successful') ? ($response->successful() ? 'success' : 'error') : 'success'));
        return response()->json($response->json(), $response->status());
    }

    public function tool(Request $request)
    {
        $tool = $request->input('tool');
        $payload = $request->all();

        $response = Http::withToken(env('AICOPILOT_KEY'))
            ->post("{$this->base}/api/aicopilot/tool", [
                'tool' => $tool,
                'payload' => $payload,
                'tenant_system_append' => function_exists('company') && company() ? (company()->short_code ?? '') : ''
            ]);

        
        $this->logAi('tool', $payload ?? request()->all(), isset($response) ? (method_exists($response, 'json') ? $response->json() : $response) : null, (isset($response) && method_exists($response, 'successful') ? ($response->successful() ? 'success' : 'error') : 'success'));
return response()->json($response->json(), $response->status());
    }
}
