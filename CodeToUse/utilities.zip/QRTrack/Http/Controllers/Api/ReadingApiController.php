<?php

namespace Modules\QRTrack\Http\Controllers\Api;

use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use Modules\QRTrack\Entities\QrCode;
use Modules\QRTrack\Entities\QrReading;

class ReadingApiController extends Controller
{
    public function index(Request $request)
    {
        $q = QrReading::query()->orderByDesc('recorded_at');
        if ($type = $request->query('type')) $q->where('reading_type', $type);
        if ($slug = $request->query('slug')) {
            $code = QrCode::where('slug', $slug)->first();
            if ($code) $q->where('qr_code_id', $code->id);
        }
        return response()->json(['data' => $q->paginate(50)]);
    }

    public function store(Request $request, string $slug)
    {
        $code = QrCode::where('slug', $slug)->firstOrFail();
        $data = $request->validate([
            'reading_type'  => 'required|string|max:64',
            'reading_value' => 'nullable|numeric',
            'unit'          => 'nullable|string|max:16',
            'notes'         => 'nullable|string',
            'recorded_at'   => 'nullable|date',
            'latitude'      => 'nullable|numeric',
            'longitude'     => 'nullable|numeric',
        ]);

        $reading = new QrReading($data);
        $reading->tenant_id = tenant('id') ?? 0;
        $reading->qr_code_id = $code->id;
        $reading->recorded_by = auth()->id();
        $reading->save();

        return response()->json(['data' => $reading], 201);
    }
}
