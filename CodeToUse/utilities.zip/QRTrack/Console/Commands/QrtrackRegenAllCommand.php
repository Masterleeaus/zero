<?php

namespace Modules\QRTrack\Console\Commands;

use Illuminate\Console\Command;
use Modules\QRTrack\Entities\QrCode;
use Modules\QRTrack\Services\QrImageService;

class QrtrackRegenAllCommand extends Command
{
    protected $signature = 'qrtrack:regen-all {--tenant=}';
    protected $description = 'Regenerate QR images for all codes (optionally by tenant).';

    public function handle(): int
    {
        $tenant = $this->option('tenant');
        $query = QrCode::query();
        if ($tenant) $query->where('tenant_id', $tenant);

        $svc = app(QrImageService::class);
        $count = 0;
        $query->chunkById(200, function($chunk) use ($svc, &$count) {
            foreach ($chunk as $code) {
                $svc->makeAndStore($code);
                $this->info("Generated: {$code->slug}");
                $count++;
            }
        });
        $this->info("Done. Generated {$count} QR images.");
        return self::SUCCESS;
    }
}
