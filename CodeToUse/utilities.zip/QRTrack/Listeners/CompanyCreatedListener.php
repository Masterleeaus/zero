<?php

namespace Modules\QRTrack\Listeners;

use Modules\QRTrack\Entities\QRCodeSetting;

class CompanyCreatedListener
{
    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle($event)
    {
        $company = $event->company;
        QRCodeSetting::addModuleSetting($company);
    }
}
