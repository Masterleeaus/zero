<?php
namespace Modules\QRTrack\Providers;

use Illuminate\Support\ServiceProvider;

class RouteServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $base = __DIR__ . '/../Routes/';
        foreach (['web','api'] as $f) {
            $p = $base . $f . '.php';
            if (file_exists($p)) { $this->loadRoutesFrom($p); }
        }
    }
}

// Note: Do not list this provider twice in module.json to avoid double-loading routes.
