<?php
namespace Modules\QRTrack\Providers;

use Illuminate\Support\ServiceProvider;

class QRTrackServiceProvider extends ServiceProvider
{
    public function register(): void { }

    public function boot(): void
    {
        $base = __DIR__ . '/../';
        if (is_dir($base.'Resources/views')) $this->loadViewsFrom($base.'Resources/views', 'qrtrack');
        if (is_dir($base.'Database/Migrations')) $this->loadMigrationsFrom($base.'Database/Migrations');
        if (file_exists($base.'Config/config.php')) $this->mergeConfigFrom($base.'Config/config.php', 'qrtrack');
        if (is_dir($base.'Resources/lang')) $this->loadTranslationsFrom($base.'Resources/lang', 'qrtrack');
    }
}
