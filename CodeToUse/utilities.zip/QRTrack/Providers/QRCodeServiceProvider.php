<?php
namespace Modules\QRTrack\Providers;

use Illuminate\Support\ServiceProvider;

class QRCodeServiceProvider extends ServiceProvider
{
    public function register(): void {}
    public function boot(): void {}
}
