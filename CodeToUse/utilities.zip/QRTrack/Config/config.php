<?php
return [
  'name' => 'QRTrack',
  'alias' => 'qrtrack',
];
