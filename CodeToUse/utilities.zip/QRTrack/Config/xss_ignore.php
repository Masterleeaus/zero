<?php

// Configuration for routes/fields to ignore in XSS filtering.  No namespace declaration is necessary.
return [

];
