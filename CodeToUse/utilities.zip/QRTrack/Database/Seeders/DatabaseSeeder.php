<?php
namespace Modules\QRTrack\Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(QRTrackPermissionsSeeder::class);
    }
}
