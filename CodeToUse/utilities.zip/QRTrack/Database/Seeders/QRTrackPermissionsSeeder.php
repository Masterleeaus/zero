<?php
namespace Modules\QRTrack\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class QRTrackPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        if (!DB::table('permissions')->where('name', 'view_qrtrack')->exists()) {
            $moduleId = DB::table('modules')->where('module_name', 'QRTrack')->value('id');
            DB::table('permissions')->insert([
                'name' => 'view_qrtrack',
                'display_name' => 'View QRTrack',
                'module' => 'qrtrack',
                'module_id' => $moduleId,
                'guard_name' => 'web',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
