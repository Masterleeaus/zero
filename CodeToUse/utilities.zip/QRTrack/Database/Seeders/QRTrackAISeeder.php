<?php

namespace Modules\QRTrack\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class QRTrackAISeeder extends Seeder
{
    public function run()
    {
        $permissions = ['view_ai_logs','manage_ai_tools','delete_ai_logs'];
        foreach ($permissions as $perm) {
            DB::table('permissions')->updateOrInsert(
                ['name' => $perm],
                [
                    'display_name' => ucfirst(str_replace('_',' ',$perm)),
                    'module' => 'QRTrack',
                    'created_at' => now(),
                    'updated_at' => now()
                ]
            );
        }
    }
}
