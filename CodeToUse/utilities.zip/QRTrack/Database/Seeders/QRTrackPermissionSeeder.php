<?php

namespace Modules\QRTrack\Database\Seeders;

use Illuminate\Database\Seeder;

class QRTrackPermissionSeeder extends Seeder
{
    public function run(): void
    {
        if (!class_exists(\Spatie\Permission\Models\Permission::class)) {
            echo "Spatie\Permission not installed. Skipping QRTrack permissions.\n";
            return;
        }

        $perms = ['qrtrack.view', 'qrtrack.manage', 'qrtrack.print'];

        foreach ($perms as $p) {
            \Spatie\Permission\Models\Permission::findOrCreate($p, config('auth.defaults.guard', 'web'));
        }

        if (class_exists(\Spatie\Permission\Models\Role::class)) {
            $admin = \Spatie\Permission\Models\Role::where('name', 'admin')->first();
            if ($admin) {
                foreach ($perms as $p) {
                    $admin->givePermissionTo($p);
                }
            }
        }
    }
}
