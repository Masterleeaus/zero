<?php

namespace Modules\QRTrack\Database\Seeders;

use Illuminate\Database\Seeder;

class QRTrackRoleSeeder extends Seeder
{
    public function run(): void
    {
        if (!class_exists(\Spatie\Permission\Models\Role::class) || !class_exists(\Spatie\Permission\Models\Permission::class)) {
            echo "Spatie\Permission not installed. Skipping QRTrack roles.\n";
            return;
        }

        $guard = config('auth.defaults.guard', 'web');

        $view = \Spatie\Permission\Models\Permission::findOrCreate('qrtrack.view', $guard);
        $manage = \Spatie\Permission\Models\Permission::findOrCreate('qrtrack.manage', $guard);
        $print = \Spatie\Permission\Models\Permission::findOrCreate('qrtrack.print', $guard);

        $fieldTech = \Spatie\Permission\Models\Role::firstOrCreate(['name' => 'field-tech', 'guard_name' => $guard]);
        $opsManager = \Spatie\Permission\Models\Role::firstOrCreate(['name' => 'ops-manager', 'guard_name' => $guard]);

        $fieldTech->givePermissionTo([$view, $print]);
        $opsManager->givePermissionTo([$view, $manage, $print]);
    }
}
