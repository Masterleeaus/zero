<?php
namespace Modules\QRTrack\Database\Migrations;


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('qrtrack_settings')) {
            Schema::create('qrtrack_settings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tenant_id')->index();
            $table->string('key');
            $table->json('value')->nullable();
            $table->timestamps();
            $table->unique(['tenant_id','key']);
        });
        }
    }
    public function down(): void
    {
        Schema::dropIfExists('qrtrack_settings');
    }
};
