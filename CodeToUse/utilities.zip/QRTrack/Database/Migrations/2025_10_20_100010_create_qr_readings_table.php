<?php
namespace Modules\QRTrack\Database\Migrations;


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('qr_readings')) {
            Schema::create('qr_readings', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('qr_code_id');
                $table->string('ip', 64)->nullable();
                $table->text('user_agent')->nullable();
                $table->text('referer')->nullable();
                $table->json('meta')->nullable();
                $table->timestamps();
                $table->index(['qr_code_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('qr_readings');
    }
};
