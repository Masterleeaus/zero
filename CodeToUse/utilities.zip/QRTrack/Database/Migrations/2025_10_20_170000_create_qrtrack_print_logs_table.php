<?php
namespace Modules\QRTrack\Database\Migrations;


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('qrtrack_print_logs')) {
            Schema::create('qrtrack_print_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tenant_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->json('code_ids'); // array of IDs printed
            $table->string('layout')->default('l7160');
            $table->json('custom')->nullable(); // cols/rows/mm_w/mm_h/margin_mm
            $table->unsignedBigInteger('printer_id')->nullable();
            $table->string('job_ref')->nullable(); // remote job id or ref if available
            $table->string('status')->default('queued'); // queued|sent|error
            $table->text('error')->nullable();
            $table->timestamps();
        });
        }
    }
    public function down(): void
    {
        Schema::dropIfExists('qrtrack_print_logs');
    }
};
