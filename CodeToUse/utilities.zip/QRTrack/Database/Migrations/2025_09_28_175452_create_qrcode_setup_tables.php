<?php
namespace Modules\QRTrack\Database\Migrations;


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // TODO: define tables for qrcode
        // Example:
        // if (!Schema::hasTable('qrcode_items')) {
            Schema::create('qrcode_items', function (Blueprint $table) {
        //     $table->id();
        //     $table->string('name');
        //     $table->timestamps();
        // });
        }
    }

    public function down(): void
    {
        // Schema::dropIfExists('qrcode_items');
    }
};
