<?php
namespace Modules\QRTrack\Database\Migrations;


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('qr_codes', function (Blueprint $table) {
            if (!Schema::hasColumn('qr_codes', 'image_path')) {
                $table->string('image_path')->nullable()->after('meta');
            }
        });
    }
    public function down(): void
    {
        Schema::table('qr_codes', function (Blueprint $table) {
            if (Schema::hasColumn('qr_codes', 'image_path')) {
                $table->dropColumn('image_path');
            }
        });
    }
};
