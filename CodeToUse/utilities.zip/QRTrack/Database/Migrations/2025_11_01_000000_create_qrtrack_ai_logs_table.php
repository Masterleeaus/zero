<?php
namespace Modules\QRTrack\Database\Migrations;


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('qrtrack_ai_logs')) {
            Schema::create('qrtrack_ai_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->unsignedBigInteger('company_id')->nullable();
            $table->string('tool')->nullable();
            $table->text('request')->nullable();
            $table->text('response_summary')->nullable();
            $table->string('status')->default('success');
            $table->timestamps();
        });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('qrtrack_ai_logs');
    }
};
