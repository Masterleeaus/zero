
# QRTrack Permissions & Seeding

If you use Spatie Permissions:

```bash
php artisan db:seed --class="Modules\\QRTrack\\Database\\Seeders\\QRTrackPermissionSeeder"
```

Permissions created:

- `qrtrack.view`
- `qrtrack.manage`
- `qrtrack.print`

Admin role (if present) is granted all three.

## Blade Helper

Use `@canqrtrack('qrtrack.view')` to show QRTrack menu items conditionally:

```blade
@canqrtrack('qrtrack.view')
    <li><a href="{{ route('qrtrack.dashboard') }}">QR Track</a></li>
@endcanqrtrack
```

## Roles & Permissions Seeder

```bash
php artisan db:seed --class="Modules\QRTrack\Database\Seeders\QRTrackPermissionSeeder"
php artisan db:seed --class="Modules\QRTrack\Database\Seeders\QRTrackRoleSeeder"
```

- **field-tech** → `qrtrack.view`, `qrtrack.print`
- **ops-manager** → `qrtrack.view`, `qrtrack.manage`, `qrtrack.print`

## Print Audit Logs

- Table: `qrtrack_print_logs`
- View: `/qrtrack/logs` (requires `qrtrack.manage`)
- Automatically records each print job (ids, layout, printer, status)
