<?php

namespace Modules\QRTrack\Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Modules\QRTrack\Entities\QrCode;

class LabelPdfTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_can_render_labels_pdf()
    {
        QrCode::create(['tenant_id'=>1,'name'=>'Y','slug'=>'slugy']);
        $this->actingAs(\App\Models\User::factory()->create());
        $resp = $this->get('/qrtrack/labels/print?slugs=slugy&layout=single');
        $resp->assertStatus(200);
        $this->assertTrue(str_contains($resp->headers->get('content-disposition'), 'qrtrack-labels.pdf'));
    }
}
