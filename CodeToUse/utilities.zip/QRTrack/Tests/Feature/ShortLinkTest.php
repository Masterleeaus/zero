<?php

namespace Modules\QRTrack\Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Modules\QRTrack\Entities\QrCode;

class ShortLinkTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_redirects_short_link_to_scan_url()
    {
        $code = QrCode::create(['tenant_id'=>1,'name'=>'X','slug'=>'abc123']);
        $resp = $this->get('/s/abc123');
        $resp->assertStatus(302);
        $resp->assertRedirect(url(config('qrtrack.qr.url_prefix').'abc123'));
    }
}
