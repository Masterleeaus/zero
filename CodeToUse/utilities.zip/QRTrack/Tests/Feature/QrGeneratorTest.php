<?php

namespace Modules\QRTrack\Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Modules\QRTrack\Entities\QrCode;
use Modules\QRTrack\Services\QrImageService;

class QrGeneratorTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_generates_qr_image()
    {
        $code = QrCode::create(['tenant_id'=>1,'name'=>'Z','slug'=>'slugz']);
        $svc = app(QrImageService::class);
        $path = $svc->makeAndStore($code);
        $this->assertNotEmpty($path);
    }
}
