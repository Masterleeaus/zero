#!/usr/bin/env bash
set -e

php artisan db:seed --class="Modules\\QRTrack\\Database\\Seeders\\QRTrackAISeeder" || true

php artisan migrate --path=Modules/QRTrack/Database/Migrations --force
composer dump-autoload -o