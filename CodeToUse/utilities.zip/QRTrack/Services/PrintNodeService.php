<?php

namespace Modules\QRTrack\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Modules\QRTrack\Services\SettingsService;

class PrintNodeService
{
    protected string $apiKey;
    public function __construct()
    {
        $this->apiKey = (string) config('qrtrack.printnode.api_key');
    }

    public function sendPdfToPrinter(string $printerId, string $pdfPath, string $title = 'QRTrack Labels'): array /* [success, jobId|null, error|null] */
    {
        if (!$this->apiKey) { Log::warning('PrintNode API key missing'); return [false, null, 'exception']; }
        if (!is_file($pdfPath)) { Log::error('PDF not found: '.$pdfPath); return [false, null, 'exception']; }

        $content = file_get_contents($pdfPath);
        $b64 = base64_encode($content);

        // Build job payload per PrintNode API
        $payload = [
            'printerId' => (int) $printerId,
            'title' => $title,
            'contentType' => 'pdf_base64',
            'content' => $b64,
            'source' => 'QRTrack',
            'options' => [
                'scale' => app(SettingsService::class)->printnodeScale(),
            ],
        ];

        try {
            $res = Http::withBasicAuth($this->apiKey, '')->post('https://api.printnode.com/printjobs', $payload);
            if ($res->successful()) { $id = $res->json()['id'] ?? null; return [true, $id, null]; }
            Log::error('PrintNode error', ['status' => $res->status(), 'body' => $res->body()]);
            return [false, null, 'exception'];
        } catch (\Throwable $e) {
            Log::error('PrintNode exception: '.$e->getMessage());
            return [false, null, 'exception'];
        }
    }
}
