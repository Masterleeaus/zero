<?php

namespace Modules\QRTrack\Services;

use Illuminate\Support\Facades\DB;

class SettingsService
{
    protected int $tenantId;
    public function __construct()
    {
        $this->tenantId = tenant('id') ?? 0;
    }

    protected function get(string $key, $default = null)
    {
        $row = DB::table('qrtrack_settings')->where('tenant_id', $this->tenantId)->where('key', $key)->first();
        if (!$row) return $default;
        $val = json_decode($row->value ?? 'null', true);
        return $val ?? $default;
    }

    public function shortDomain(): ?string
    {
        $v = $this->get('short', null);
        return $v['domain'] ?? config('qrtrack.short.domain');
    }

    public function shortBasePath(): string
    {
        $v = $this->get('short', null);
        return $v['base_path'] ?? config('qrtrack.short.base_path', '/s/');
    }

    public function brandingLogoPath(): ?string
    {
        $v = $this->get('branding', null);
        return $v['logo_path'] ?? config('qrtrack.branding.logo_path');
    }

    public function brandingTitle(): ?string
    {
        $v = $this->get('branding', null);
        return $v['title'] ?? config('qrtrack.branding.title');
    }

    public function printnodePrinterId(): ?int
    {
        $v = $this->get('printnode', null);
        $id = $v['printer_id'] ?? config('qrtrack.printnode.printer_id');
        return $id ? (int) $id : null;
    }

    public function printnodeScale(): string
    {
        $v = $this->get('printnode', null);
        return $v['scale'] ?? config('qrtrack.printnode.scale', 'noscale');
    }
}
