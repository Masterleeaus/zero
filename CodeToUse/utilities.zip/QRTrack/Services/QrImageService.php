<?php

namespace Modules\QRTrack\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;
use Modules\QRTrack\Entities\QrCode;

class QrImageService
{
    public function pngFor(string $slug): string
    {
        $key = 'qrtrack:img:'.$slug;
        return Cache::remember($key, Config::get('qrtrack.qr.cache_ttl', 86400), function () use ($slug) {
            // Generate the URL to the QR scan page.  Use the route name defined in Routes/web.php.
            $url = route('qrtrack.code.scan', ['slug' => $slug]);
            // Use Simple QrCode if available
            if (class_exists('SimpleSoftwareIO\QrCode\Facades\QrCode')) {
                return base64_encode(
                    \SimpleSoftwareIO\QrCode\Facades\QrCode::format('png')->size(300)->margin(1)->generate($url)
                );
            }
            // Fallback: tiny PNG from SVG rendered string (very basic)
            $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300"><rect width="100%" height="100%" fill="#fff"/><text x="10" y="20" font-size="14">QR: '.htmlspecialchars($slug).'</text></svg>';
            return base64_encode($svg);
        });
    }
}
