<?php

use Illuminate\Support\Facades\Route;
use Modules\QRTrack\Http\Controllers\DashboardController;
use Modules\QRTrack\Http\Controllers\QrController;
use Modules\QRTrack\Http\Controllers\QrImageController;
use Modules\QRTrack\Http\Controllers\LogController;

/*
|--------------------------------------------------------------------------
| QRTrack Web Routes
|--------------------------------------------------------------------------
|
| This file defines the routes for the QRTrack module.  All routes are
| grouped under the "qrtrack" prefix and protected by the "web" and
| "auth" middleware stacks.  Feel free to extend these routes with
| additional functionality specific to your implementation.
|
*/

Route::middleware(['web', 'auth'])
    ->prefix('qrtrack')
    ->name('qrtrack.')
    ->group(function () {
        // Dashboard landing page
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard.alt1');

        // Show an individual QR code by slug (scan view)
        Route::get('/code/{slug}', [QrController::class, 'scan'])
            ->where('slug', '[A-Za-z0-9\-]+')
            ->name('code.scan');

        // Serve PNG images for a QR code
        Route::get('/img/{slug}.png', [QrImageController::class, 'show'])
            ->where('slug', '[A-Za-z0-9\-]+')
            ->name('image.show');

        // Regenerate a QR code image
        Route::get('/img/{slug}/regenerate', [QrImageController::class, 'regenerate'])
            ->where('slug', '[A-Za-z0-9\-]+')
            ->name('image.regenerate');

        // Quick print routes removed: functionality temporarily disabled

        // AI log listing
        Route::get('/logs', [LogController::class, 'index'])->name('logs');
    });