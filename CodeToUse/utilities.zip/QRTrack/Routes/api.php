<?php
namespace Modules\QRTrack\Routes;

use Illuminate\Support\Facades\Route;

use Modules\QRTrack\Http\Controllers\Api\ReadingApiController;

Route::middleware(['api','auth:sanctum','tenant'])->prefix('v1/qrcode')->name('qrtrack.api.')->group(function () {
    Route::get('/readings', [ReadingApiController::class, 'index'])->name('readings.index');
    Route::post('/codes/{slug}/readings', [ReadingApiController::class, 'store'])->name('readings.store');
});
