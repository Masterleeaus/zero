<?php

namespace Modules\QRTrack\Entities;

use Illuminate\Database\Eloquent\Model;

class QrReading extends Model
{
    protected $table = 'qr_readings';

    protected $fillable = [
        'tenant_id',
        'qr_code_id',
        'reading_type',
        'reading_value',
        'unit',
        'notes',
        'recorded_at',
        'recorded_by',
        'latitude',
        'longitude',
        'attachments',
        'meta',
    ];

    protected $casts = [
        'recorded_at' => 'datetime',
        'attachments' => 'array',
        'meta' => 'array',
    ];
}
