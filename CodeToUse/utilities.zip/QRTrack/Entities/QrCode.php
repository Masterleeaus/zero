<?php

namespace Modules\QRTrack\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * QrCode
 *
 * This model represents a QR code record.  It stores metadata about the code
 * such as its tenant, slug, target association, and any arbitrary meta data.
 * Related QR readings are available via the `readings()` relation.
 */
class QrCode extends Model
{
    /**
     * The table associated with the model.
     */
    protected $table = 'qr_codes';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'tenant_id',
        'name',
        'slug',
        'target_type',
        'target_id',
        'meta',
        'image_path',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'meta' => 'array',
    ];

    /**
     * Get the readings associated with this QR code.
     */
    public function readings(): HasMany
    {
        return $this->hasMany(QrReading::class, 'qr_code_id');
    }
}
