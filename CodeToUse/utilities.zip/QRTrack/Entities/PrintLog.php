<?php

namespace Modules\QRTrack\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PrintLog extends Model
{
    protected $table = 'qrtrack_print_logs';

    protected $fillable = [
        'tenant_id','user_id','code_ids','layout','custom','printer_id','job_ref','status','error'
    ];

    protected $casts = [
        'code_ids' => 'array',
        'custom'   => 'array',
    ];

    public function user(): BelongsTo
    {
        // assumes default User model namespace
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }
}

