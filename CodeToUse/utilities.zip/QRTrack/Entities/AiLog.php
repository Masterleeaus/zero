<?php

namespace Modules\QRTrack\Entities;

use Illuminate\Database\Eloquent\Model;

class AiLog extends Model
{
    protected $table = 'qrtrack_ai_logs';

    protected $fillable = [
        'user_id', 'company_id', 'tool', 'request', 'response_summary', 'status'
    ];

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }
}
