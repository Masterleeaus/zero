<?php

return [
    'name' => 'ServicemanModule'
];
