<?php

return [
    'name' => 'WMSInventoryCore',
];
