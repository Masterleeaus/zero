<?php

return [
    'name' => 'TrAccessCard'
];
