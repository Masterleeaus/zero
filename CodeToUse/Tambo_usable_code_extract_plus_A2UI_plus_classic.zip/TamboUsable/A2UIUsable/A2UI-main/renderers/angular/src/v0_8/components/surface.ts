/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { ChangeDetectionStrategy, Component, computed, inject, input } from '@angular/core';
import { MessageProcessor } from '../data';
import { Renderer } from '../rendering/renderer';
import { Types } from '../types';

@Component({
  selector: 'a2ui-surface',
  imports: [Renderer],
  template: `
    @if (surface(); as s) {
      @if (s.componentTree; as root) {
        <ng-container
          a2ui-renderer
          [surfaceId]="surfaceId()"
          [component]="root"
        />
      }
    }
  `,
  styles: `
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Surface {
  private readonly processor = inject(MessageProcessor);
  readonly surfaceId = input.required<Types.SurfaceID>();
  readonly surfaceInput = input<Types.Surface | null>(null, { alias: 'surface' });

  protected readonly surface = computed(() => {
    return this.surfaceInput() ?? this.processor.getSurfaces().get(this.surfaceId()) ?? null;
  });
}
