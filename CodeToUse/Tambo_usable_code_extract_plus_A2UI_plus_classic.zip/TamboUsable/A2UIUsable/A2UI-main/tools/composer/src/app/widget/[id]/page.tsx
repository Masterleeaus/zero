/**
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use client';

import { use } from 'react';
import { WidgetEditor } from '@/components/editor/widget-editor';
import { useWidgets } from '@/contexts/widgets-context';

interface WidgetPageProps {
  params: Promise<{ id: string }>;
}

export default function WidgetPage({ params }: WidgetPageProps) {
  const { id } = use(params);
  const { loading, getWidget } = useWidgets();

  if (loading) {
    return (
      <div className="flex flex-1 items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  const widget = getWidget(id);

  if (!widget) {
    return (
      <div className="flex flex-1 items-center justify-center">
        <div className="text-muted-foreground">Widget not found</div>
      </div>
    );
  }

  return <WidgetEditor widget={widget} />;
}
