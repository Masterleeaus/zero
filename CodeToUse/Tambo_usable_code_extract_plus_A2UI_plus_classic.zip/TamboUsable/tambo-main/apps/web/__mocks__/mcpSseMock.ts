export class SSEClientTransport {
  constructor() {}
}
