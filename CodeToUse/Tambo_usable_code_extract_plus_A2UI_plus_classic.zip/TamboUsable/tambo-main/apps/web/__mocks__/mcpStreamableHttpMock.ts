export class StreamableHTTPClientTransport {
  constructor() {}
}
