<?php

namespace Modules\Sms\Notifications;

use App\Models\Project;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\VonageMessage;
use Illuminate\Notifications\Notification;
use Modules\Sms\Entities\SmsTemplateId;
use Modules\Sms\Entities\SmsNotificationSetting;
use Modules\Sms\Http\Traits\WhatsappMessageTrait;
use Modules\Sms\Http\Traits\SmsTitanTalkBridgeTrait;
use NotificationChannels\Telegram\TelegramMessage;
use NotificationChannels\Twilio\TwilioChannel;
use NotificationChannels\Twilio\TwilioSmsMessage;

class NewProjectMemberSms extends Notification implements ShouldQueue
{
    use Queueable, WhatsappMessageTrait, SmsTitanTalkBridgeTrait;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    private $project;

    private $message;

    private $smsSetting;

    private $company;

    private $msg_flow_id;

    public function __construct(Project $project)
    {
        $this->project = $project;

        $this->company = $this->project->company;
        $this->smsSetting = SmsNotificationSetting::where('slug', 'employee-assign-to-project')->where('company_id', $this->company->id)->first();
        $this->msg_flow_id = SmsTemplateId::where('sms_setting_slug', 'new-task')->first();
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        if ($this->smsSetting && $this->smsSetting->send_sms != 'yes') {
            return [];
        }

        $this->message = __('email.newProjectMember.subject')."\n".__('email.newProjectMember.text').' - '.ucwords($this->project->project_name);

        $via = [];

        if (! is_null($notifiable->mobile) && ! is_null($notifiable->country_phonecode)) {
            if (sms_setting()->status) {
                array_push($via, TwilioChannel::class);
            }

            if (sms_setting()->nexmo_status) {
                array_push($via, 'vonage');
            }

            if (sms_setting()->msg91_status) {
                array_push($via, 'msg91');
            }
        }

        if (sms_setting()->telegram_status && $notifiable->telegram_user_id) {
            array_push($via, 'telegram');
        }

        return $via;
    }

    public function toTwilio($notifiable)
    {
        $this->toWhatsapp(
            $this->smsSetting->slug,
            $notifiable,
            __($this->smsSetting->slug->translationString(), ['projectName' => $this->project->project_name]),
            ['1' => $this->project->project_name]
        );

        if (sms_setting()->status) {
            $this->logToTitanTalkSms($notifiable, $this->message);
                        $this->logToTitanTalkSms($notifiable, $this->message);
            return (new TwilioSmsMessage)
                ->content($this->message);
        }
    }

    //phpcs:ignore
    public function toVonage($notifiable)
    {
        if (sms_setting()->nexmo_status) {
            $this->logToTitanTalkSms($notifiable, $this->message);
            return (new VonageMessage)
                ->content($this->message)->unicode();
        }
    }

    //phpcs:ignore
    public function toMsg91($notifiable)
    {
        $mobile = $notifiable->country_phonecode . $notifiable->mobile;
        if ($this->smsSetting->msg91_flow_id && sms_setting()->msg91_status) {
            $this->logToTitanTalkSms($notifiable, $this->message ?? '');
                        $this->logToTitanTalkSms($notifiable, $this->message ?? '');
            return (new \Craftsys\Notifications\Messages\Msg91SMS)
                ->to($mobile)
                ->flow($this->msg_flow_id->msg91_flow_id)
                ->variable('project_name', ucwords($this->member->project->project_name));
        }
    }

    public function toTelegram($notifiable)
    {
        return TelegramMessage::create()
            // Optional recipient user id.
            ->to($notifiable->telegram_user_id)
            // Markdown supported.
            ->content($this->message)
            ->button(__('email.newProjectMember.action'), route('projects.show', $this->project->id));
    }
}
