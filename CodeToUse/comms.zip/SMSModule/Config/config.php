<?php

return [
    'name' => 'SMSModule'
];
