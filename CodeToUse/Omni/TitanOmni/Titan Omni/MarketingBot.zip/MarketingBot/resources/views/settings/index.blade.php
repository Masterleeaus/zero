@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Marketing Bot Settings'))

@section('titlebar_actions')

@endsection

@section('content')

	<div class="flex flex-wrap mt-5">
		<div class="w-full md:w-1/2">
			<x-card>
				<x-slot name="head">
					{{ __('Marketing Bot Telegram') }}
				</x-slot>
				<form action="{{ route('dashboard.user.marketing-bot.settings.telegram') }}" method="post">
					@method('post')
					<x-forms.input
						id="access_token"
						size="lg"
						label="{{ __('Access Token') }}"
						name="access_token"
						required
						value="{{ $app_is_demo ? '**********' : $telegram?->access_token }}"
					/>
					@if ($app_is_demo)
						<x-button
							class="mt-3"
							type="button"
							onclick="return toastr.info('This feature is disabled in Demo version.');"
						>
							{{ __('Save') }}
						</x-button>
					@else
						<x-button
							class="mt-3"

							type="submit"
						>
							{{ __('Save') }}
						</x-button>
					@endif
				</form>
			</x-card>
		</div>
		<div class="w-full md:w-1/2">
			<x-card>
				<x-slot name="head">
					{{ __('Marketing Bot Whatsapp Settings') }}
				</x-slot>
				<form action="{{ route('dashboard.user.marketing-bot.settings.whatsapp') }}" method="post">
					<input hidden name="channel" value="whatsapp">
					<input hidden name="user_id" value="{{ \Illuminate\Support\Facades\Auth::id() }}">
					@csrf
					<div
						class="mb-3">
						<x-forms.input
							:label="__('Whatsapp sid')"
							name="whatsapp_sid"
							size="lg"
							required
							value="{{ $app_is_demo ? '**********' : $whatsapp?->whatsapp_sid }}"
						>
						</x-forms.input>
					</div>
					<div
						class="mb-3">
						<x-forms.input
							:label="__('Whatsapp token')"
							name="whatsapp_token"
							size="lg"
							required
							value="{{ $app_is_demo ? '**********' : $whatsapp?->whatsapp_token }}"
						>
						</x-forms.input>
					</div>
					<div
						class="mb-3">
						<x-forms.input
							:label="__('Whatsapp phone')"
							name="whatsapp_phone"
							size="lg"
							required
							value="{{ $app_is_demo ? '**********' : $whatsapp?->whatsapp_phone }}"
						>
						</x-forms.input>
					</div>
					<div
						class="mb-3">
						<x-forms.input
							:label="__('Whatsapp sandbox phone')"
							name="whatsapp_sandbox_phone"
							size="lg"
							value="{{ $app_is_demo ? '**********' : $whatsapp?->whatsapp_sandbox_phone }}"
						>
						</x-forms.input>
					</div>
					<div class="mb-3">
						<x-forms.input
							id="whatsapp_environment"
							type="select"
							size="lg"
							name="whatsapp_environment"
							label="{{ __('Environment') }}"
						>
							<option {{ $whatsapp?->whatsapp_environment === 'sandbox' ? 'selected' : '' }} value="sandbox">@lang('SANDBOX')</option>
							<option {{ $whatsapp?->whatsapp_environment === 'production' ? 'selected' : '' }} value="production">@lang('PRODUCTION')</option>
						</x-forms.input>
					</div>

					@if($whatsapp)
						<div
							class="mb-3">
							<x-forms.input
								:label="__('Webhook Url')"
								name="webhook"
								size="lg"
								value="{{ route('api.marketing-bot.whatsapp.webhook', $whatsapp?->id) }}"
							>
							</x-forms.input>
						</div>
					@endif

					@if ($app_is_demo)
						<x-button
							type="button"
							onclick="return toastr.info('This feature is disabled in Demo version.');"
						>
							{{ __('Save') }}
						</x-button>
					@else
						<x-button
							class="mt-3"

							type="submit"
						>
							{{ __('Save') }}
						</x-button>
					@endif
				</form>
			</x-card>
		</div>
	
		<div class="w-full md:w-1/2">
			<x-card>
				<x-slot name="head">
					{{ __('Marketing Bot Messenger Settings') }}
				</x-slot>
				<form action="{{ route('dashboard.user.marketing-bot.settings.messenger') }}" method="post">
					@csrf
					<div class="mb-3">
						<x-forms.input
							:label="__('Channel Name')"
							name="name"
							value="{{ $messenger?->name }}"
							required
						/>
					</div>

					<div class="mb-3">
						<x-forms.input
							:label="__('Page Access Token')"
							name="page_access_token"
							value="{{ $messenger?->page_access_token }}"
							required
						/>
					</div>

					<div class="mb-3">
						<x-forms.input
							:label="__('Verify Token')"
							name="verify_token"
							value="{{ $messenger?->verify_token }}"
							required
						/>
					</div>

					<div class="mb-3">
						<x-forms.input
							:label="__('Page ID (optional)')"
							name="page_id"
							value="{{ $messenger?->page_id }}"
						/>
					</div>

					<x-button type="submit">
						{{ __('Save') }}
					</x-button>
				</form>
			</x-card>

			<div class="mt-3 text-xs opacity-75">
				{{ __('Webhook URL:') }} <code>{{ url('/api/marketing-bot/messenger/' . ($messenger?->id ?? 'CHANNEL_ID') . '/webhook') }}</code>
			</div>
		</div>


                <div class="w-full md:w-1/2">
                        <x-card>
                                <x-slot name="head">
                                        {{ __('Marketing Bot SMS Settings') }}
                                </x-slot>
                                <form action="{{ route('dashboard.user.marketing-bot.settings.sms') }}" method="post">
                                        @csrf
                                        <div class="mb-3">
                                                <x-forms.input :label="__('Channel Name')" name="name" value="{{ $sms?->name }}" required />
                                        </div>
                                        <div class="mb-3">
                                                <x-forms.input :label="__('Twilio Account SID')" name="twilio_sid" value="{{ $app_is_demo ? '**********' : $sms?->twilio_sid }}" required />
                                        </div>
                                        <div class="mb-3">
                                                <x-forms.input :label="__('Twilio Auth Token')" name="twilio_token" value="{{ $app_is_demo ? '**********' : $sms?->twilio_token }}" required />
                                        </div>
                                        <div class="mb-3">
                                                <x-forms.input :label="__('From Phone (E.164)')" name="from_phone" value="{{ $sms?->from_phone }}" required />
                                        </div>
                                        <div class="mb-3">
                                                <x-forms.input :label="__('Status')" name="status" value="{{ $sms?->status ?? 'active' }}" />
                                        </div>
                                        <x-button type="submit">{{ __('Save') }}</x-button>
                                </form>
                        </x-card>
                        <div class="mt-3 text-xs opacity-75">
                                {{ __('Tip: store contact phones in E.164 format, e.g. +61400111222') }}
                        </div>
                </div>
</div>
@endsection

@push('script')
@endpush



                        <x-card class="mt-4">
                            <x-slot name="head">
                                {{ __('Marketing Bot Email Settings') }}
                            </x-slot>
                            <form action="{{ route('dashboard.user.marketing-bot.settings.email') }}" method="post">
                                @csrf
                                <div class="mb-3">
                                    <x-forms.input :label="__('Channel Name')" name="name" value="{{ $email?->name }}" required />
                                </div>
                                <div class="mb-3">
                                    <x-forms.input :label="__('From Email (optional)')" name="from_email" value="{{ $email?->from_email }}" />
                                </div>
                                <div class="mb-3">
                                    <x-forms.input :label="__('From Name (optional)')" name="from_name" value="{{ $email?->from_name }}" />
                                </div>
                                <div class="mb-3">
                                    <x-forms.input :label="__('Reply-To (optional)')" name="reply_to" value="{{ $email?->reply_to }}" />
                                </div>
                                <div class="text-end">
                                    <x-button type="submit">{{ __('Save Email Settings') }}</x-button>
                                </div>
                            </form>
                        </x-card>

