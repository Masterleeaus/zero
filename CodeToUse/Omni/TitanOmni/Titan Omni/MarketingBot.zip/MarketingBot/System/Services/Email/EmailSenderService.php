<?php

namespace App\Extensions\MarketingBot\System\Services\Email;

use App\Extensions\MarketingBot\System\Models\Email\EmailChannel;
use Illuminate\Support\Facades\Mail;

class EmailSenderService
{
    /**
     * @param array<int,string> $attachments Paths on the default filesystem (storage) or absolute paths.
     */
    public function send(EmailChannel $channel, string $toEmail, string $subject, string $htmlBody, array $attachments = []): array
    {
        try {
            Mail::send([], [], function ($message) use ($channel, $toEmail, $subject, $htmlBody, $attachments) {
                $message->to($toEmail)->subject($subject);

                if (!empty($channel->from_email)) {
                    $message->from($channel->from_email, $channel->from_name ?: null);
                }

                if (!empty($channel->reply_to)) {
                    $message->replyTo($channel->reply_to);
                }

                $message->setBody($htmlBody, 'text/html');

                foreach ($attachments as $path) {
                    if (is_string($path) && file_exists($path)) {
                        $message->attach($path);
                    }
                }
            });

            return ['ok' => true, 'provider_message_id' => null, 'error' => null];
        } catch (\Throwable $e) {
            return ['ok' => false, 'provider_message_id' => null, 'error' => $e->getMessage()];
        }
    }
}
