<?php

namespace App\Extensions\MarketingBot\System\Services\Telegram;

use App\Extensions\MarketingBot\System\Models\Telegram\TelegramBot;
use Exception;
use Illuminate\Support\Facades\Http;

class TelegramSenderService
{
    public function sendText(TelegramBot $bot, string|int $chatId, string $message): array
    {
        $token = (string) $bot->access_token;
        $url = 'https://api.telegram.org/bot' . $token . '/sendMessage';

        $resp = Http::post($url, [
            'chat_id' => $chatId,
            'text' => $message,
        ]);

        if ($resp->failed()) {
            return [
                'ok' => false,
                'provider_message_id' => null,
                'error' => 'Failed to send message: ' . $resp->body(),
            ];
        }

        if (! $resp->json('ok')) {
            return [
                'ok' => false,
                'provider_message_id' => null,
                'error' => 'Telegram API returned ok=false: ' . $resp->body(),
            ];
        }

        $messageId = data_get($resp->json(), 'result.message_id');

        return [
            'ok' => true,
            'provider_message_id' => $messageId ? (string) $messageId : null,
            'error' => null,
        ];
    }
}
