<?php

namespace App\Extensions\MarketingBot\System\Services\Safety;

class MessageComplianceService
{
    /**
     * Lightweight heuristic: warns when content looks like a quote/invoice/payment request.
     */
    public function warn(string $text): array
    {
        $t = mb_strtolower($text);
        $signals = [
            'invoice' => 0.25,
            'quote' => 0.25,
            'payment' => 0.2,
            'pay now' => 0.2,
            'due' => 0.15,
            'total' => 0.15,
            '$' => 0.15,
            'aud' => 0.1,
            'bank' => 0.1,
            'bsb' => 0.2,
        ];

        $score = 0.0;
        $hits = [];

        foreach ($signals as $kw => $w) {
            if (str_contains($t, $kw)) {
                $score += $w;
                $hits[] = $kw;
            }
        }

        $score = min(1.0, $score);

        return [
            'has_warning' => $score >= 0.35,
            'score' => $score,
            'signals' => $hits,
            'message' => $score >= 0.35
                ? 'This message may look like a quote/invoice/payment request. Confirm it is non-transactional, or route through Quotes/Money.'
                : 'No obvious transactional/payment signals detected.',
        ];
    }
}
