<?php

namespace App\Extensions\MarketingBot\System\Services\Messenger;

use App\Extensions\MarketingBot\System\Models\Messenger\MessengerChannel;
use Illuminate\Support\Facades\Http;

class MessengerSenderService
{
    public function sendText(MessengerChannel $channel, string $recipientId, string $message): array
    {
        $url = 'https://graph.facebook.com/v18.0/me/messages';

        $resp = Http::withToken($channel->page_access_token)
            ->post($url, [
                'recipient' => ['id' => $recipientId],
                'message' => ['text' => $message],
            ]);

        if ($resp->failed()) {
            return [
                'ok' => false,
                'provider_message_id' => null,
                'error' => $resp->body(),
            ];
        }

        return [
            'ok' => true,
            'provider_message_id' => (string) ($resp->json('message_id') ?? ''),
            'error' => null,
        ];
    }
}
