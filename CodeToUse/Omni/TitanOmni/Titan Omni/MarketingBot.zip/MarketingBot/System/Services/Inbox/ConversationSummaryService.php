<?php

namespace App\Extensions\MarketingBot\System\Services\Inbox;

use App\Extensions\MarketingBot\System\Models\MarketingConversation;
use App\Extensions\MarketingBot\System\Models\MarketingMessageHistory;
use OpenAI\Laravel\Facades\OpenAI;

class ConversationSummaryService
{
    public function summarise(MarketingConversation $conversation): string
    {
        $messages = MarketingMessageHistory::query()
            ->where('conversation_id', $conversation->id)
            ->orderBy('created_at')
            ->limit(200)
            ->get(['role','message'])
            ->map(fn($m) => strtoupper((string)$m->role) . ': ' . (string)$m->message)
            ->implode("\n");

        $prompt = "Summarise this customer conversation for a trades/service business. Output:\n"
            . "- 1 sentence summary\n- key details\n- next recommended question\n\nConversation:\n" . $messages;

        $res = OpenAI::chat()->create([
            'model' => 'gpt-4o-mini',
            'messages' => [
                ['role' => 'user', 'content' => $prompt],
            ],
        ]);

        return (string)($res->choices[0]->message->content ?? '');
    }
}
