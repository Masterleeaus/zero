<?php

namespace App\Extensions\MarketingBot\System\Services\Campaign;

use App\Extensions\MarketingBot\System\Models\MarketingCampaign;
use App\Extensions\MarketingBot\System\Models\Whatsapp\Contact;
use App\Extensions\MarketingBot\System\Models\Whatsapp\Segment;
use Illuminate\Support\Collection;

class CampaignAudienceService
{
    /**
     * Returns: ['total' => int, 'contacts' => int, 'segments' => int, 'recipient_ids' => array<string>]
     */
    public function preview(MarketingCampaign $campaign): array
    {
        $contacts = collect($campaign->contacts ?: []);
        $segments = collect($campaign->segments ?: []);

        $contactIds = $contacts->filter()->values();
        $segmentIds = $segments->filter()->values();

        $ids = collect();

        if ($contactIds->isNotEmpty()) {
            $ids = $ids->merge(Contact::query()->whereIn('id', $contactIds)->pluck('id'));
        }

        if ($segmentIds->isNotEmpty()) {
            // segment_id is stored on contacts (per existing schema)
            $ids = $ids->merge(Contact::query()->whereIn('segment_id', $segmentIds)->pluck('id'));
        }

        $ids = $ids->unique()->values();

        return [
            'total' => $ids->count(),
            'contacts' => $contactIds->count(),
            'segments' => $segmentIds->count(),
            'recipient_ids' => $ids->map(fn($v) => (string)$v)->all(),
        ];
    }
}
