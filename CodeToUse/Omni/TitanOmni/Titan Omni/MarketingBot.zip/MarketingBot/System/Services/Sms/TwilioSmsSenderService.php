<?php

namespace App\Extensions\MarketingBot\System\Services\Sms;

use App\Extensions\MarketingBot\System\Models\Sms\SmsChannel;
use Twilio\Rest\Client;

class TwilioSmsSenderService
{
    /**
     * @param array<int,string> $mediaUrls Public URLs for MMS (optional).
     */
    public function send(SmsChannel $channel, string $to, string $body, array $mediaUrls = []): array
    {
        try {
            $client = new Client($channel->twilio_sid, $channel->twilio_token);

            $payload = [
                'from' => $channel->from_number,
                'body' => $body,
            ];

            if (!empty($mediaUrls)) {
                $payload['mediaUrl'] = array_values($mediaUrls);
            }

            $msg = $client->messages->create($to, $payload);

            return ['ok' => true, 'provider_message_id' => (string)$msg->sid, 'error' => null];
        } catch (\Throwable $e) {
            return ['ok' => false, 'provider_message_id' => null, 'error' => $e->getMessage()];
        }
    }
}
