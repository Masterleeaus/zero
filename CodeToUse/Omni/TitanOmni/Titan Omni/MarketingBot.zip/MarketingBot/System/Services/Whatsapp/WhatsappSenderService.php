<?php

namespace App\Extensions\MarketingBot\System\Services\Whatsapp;

use App\Extensions\MarketingBot\System\Models\Whatsapp\WhatsappChannel;
use Exception;
use Twilio\Rest\Client;

class WhatsappSenderService
{
    public function sendText(WhatsappChannel $channel, string $to, string $message, array $mediaUrls = []): array
    {
        $from = $this->resolveFrom($channel);
        $to = $this->normalizeTo($to);

        try {
            $client = new Client($channel->whatsapp_sid, $channel->whatsapp_token);

            $resp = $client->messages->create($to, array_filter([
                'from' => 'whatsapp:' . $from,
                'body' => $message,
                'mediaUrl' => !empty($mediaUrls) ? array_values($mediaUrls) : null,
            ]));

            return [
                'ok' => true,
                'provider_message_id' => (string) ($resp->sid ?? ''),
                'error' => null,
            ];
        } catch (Exception $e) {
            return [
                'ok' => false,
                'provider_message_id' => null,
                'error' => $e->getMessage(),
            ];
        }
    }

    private function resolveFrom(WhatsappChannel $channel): string
    {
        $env = (string) ($channel->whatsapp_environment ?? '');
        if (strtolower($env) === 'sandbox') {
            return (string) $channel->whatsapp_sandbox_phone;
        }
        return (string) $channel->whatsapp_phone;
    }

    private function normalizeTo(string $to): string
    {
        // Twilio expects whatsapp:+E164 or whatsapp:<number>
        if (str_starts_with($to, 'whatsapp:')) {
            return $to;
        }
        return 'whatsapp:' . $to;
    }
}
