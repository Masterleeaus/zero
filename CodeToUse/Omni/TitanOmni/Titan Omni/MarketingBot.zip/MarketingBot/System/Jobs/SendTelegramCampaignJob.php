<?php

namespace App\Extensions\MarketingBot\System\Jobs;

use App\Extensions\MarketingBot\System\Models\MarketingCampaign;
use App\Extensions\MarketingBot\System\Models\MarketingDelivery;
use App\Extensions\MarketingBot\System\Models\Telegram\TelegramBot;
use App\Extensions\MarketingBot\System\Services\Telegram\TelegramSenderService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendTelegramCampaignJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(
        public int $campaignId,
        public int $botId,
    ) {}

    public function handle(TelegramSenderService $sender): void
    {
        $campaign = MarketingCampaign::query()->find($this->campaignId);
        $bot = TelegramBot::query()->find($this->botId);

        if (! $campaign || ! $bot) {
            return;
        }

        $deliveries = MarketingDelivery::query()
            ->where('campaign_id', $campaign->id)
            ->where('channel', 'telegram')
            ->where('status', 'queued')
            ->get();

        foreach ($deliveries as $delivery) {
            $result = $sender->sendText($bot, $delivery->recipient_id, (string) $campaign->content);

            if ($result['ok']) {
                $delivery->update([
                    'status' => 'sent',
                    'provider_message_id' => $result['provider_message_id'],
                    'sent_at' => now(),
                    'error' => null,
                ]);
            } else {
                $delivery->update([
                    'status' => 'failed',
                    'error' => $result['error'],
                ]);
            }
        }
    }
}
