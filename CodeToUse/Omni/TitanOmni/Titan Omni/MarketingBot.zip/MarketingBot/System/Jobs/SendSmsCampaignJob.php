<?php

namespace App\Extensions\MarketingBot\System\Jobs;

use App\Extensions\MarketingBot\System\Models\MarketingCampaign;
use App\Extensions\MarketingBot\System\Models\MarketingDelivery;
use App\Extensions\MarketingBot\System\Models\Sms\SmsChannel;
use App\Extensions\MarketingBot\System\Services\Sms\TwilioSmsSenderService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendSmsCampaignJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(
        public int $campaignId,
        public int $channelId,
    ) {}

    public function handle(TwilioSmsSenderService $sender): void
    {
        $campaign = MarketingCampaign::query()->find($this->campaignId);
        $channel = SmsChannel::query()->find($this->channelId);

        if (! $campaign || ! $channel) {
            return;
        }

        $deliveries = MarketingDelivery::query()
            ->where('campaign_id', $campaign->id)
            ->where('channel', 'sms')
            ->where('status', 'queued')
            ->get();

        foreach ($deliveries as $delivery) {
            $result = $sender->sendText($channel, (string) $delivery->recipient_id, (string) $campaign->content);

            if ($result['ok']) {
                $delivery->update([
                    'status' => 'sent',
                    'provider_message_id' => $result['provider_message_id'],
                    'sent_at' => now(),
                    'error' => null,
                ]);
            } else {
                $delivery->update([
                    'status' => 'failed',
                    'error' => $result['error'],
                ]);
            }
        }
    }
}
