<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Whatsapp;

use App\Extensions\MarketingBot\System\Http\Requests\SegmentRequest;
use App\Extensions\MarketingBot\System\Models\Whatsapp\Segment;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

class SegmentController extends Controller
{
    public function index()
    {
        return view('marketing-bot::segment.index', [
            'items' => Segment::query()->where('user_id', Auth::id())->get(),
        ]);
    }

    public function store(SegmentRequest $request): JsonResponse
    {
        Segment::query()->create($request->validated());

        return response()->json([
            'status'  => 'success',
            'message' => __('Segment created successfully'),
        ]);
    }

    public function edit(Segment $segment)
    {
        return view('marketing-bot::segment.edit', [
            'item' => $segment,
        ]);
    }

    public function update(SegmentRequest $request, Segment $segment): RedirectResponse
    {
        $segment->update($request->validated());

        return back()->with([
            'status'  => 'success',
            'message' => __('Segment updated successfully'),
            'type'    => 'success',
        ]);
    }

    public function destroy(Segment $segment): JsonResponse
    {
        $segment->delete();

        return response()->json([
            'status'  => 'success',
            'message' => __('Segment deleted successfully'),
        ]);
    }
}
