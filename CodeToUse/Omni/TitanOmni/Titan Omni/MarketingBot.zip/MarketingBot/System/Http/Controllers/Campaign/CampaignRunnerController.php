<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Campaign;

use App\Extensions\MarketingBot\System\Jobs\SendTelegramCampaignJob;
use App\Extensions\MarketingBot\System\Jobs\SendWhatsappCampaignJob;
use App\Extensions\MarketingBot\System\Jobs\SendSmsCampaignJob;
use App\Extensions\MarketingBot\System\Models\MarketingCampaign;
use App\Extensions\MarketingBot\System\Models\MarketingDelivery;
use App\Extensions\MarketingBot\System\Models\MarketingConversation;
use App\Extensions\MarketingBot\System\Models\Telegram\TelegramBot;
use App\Extensions\MarketingBot\System\Models\Telegram\TelegramGroup;
use App\Extensions\MarketingBot\System\Models\Whatsapp\WhatsappChannel;
use App\Extensions\MarketingBot\System\Models\Sms\SmsChannel;
use App\Extensions\MarketingBot\System\Models\Whatsapp\Contact;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CampaignRunnerController extends Controller
{
    public function runWhatsapp(Request $request, MarketingCampaign $campaign): RedirectResponse
    {
        $this->authorizeCampaign($campaign);

        $channel = WhatsappChannel::query()->where('user_id', Auth::id())->first();
        if (! $channel) {
            return back()->with('error', __('WhatsApp is not configured.'));
        }

        // MarketingBot does not store phone numbers in contacts; safest audience is existing WhatsApp conversations.
        $recipients = MarketingConversation::query()
            ->where('user_id', Auth::id())
            ->where('type', 'whatsapp')
            ->whereNotNull('session_id')
            ->pluck('session_id')
            ->unique()
            ->values();

        $queued = 0;
        foreach ($recipients as $to) {
            $delivery = MarketingDelivery::query()->firstOrCreate([
                'campaign_id' => $campaign->id,
                'channel' => 'whatsapp',
                'recipient_type' => 'conversation',
                'recipient_id' => (string) $to,
            ], [
                'status' => 'queued',
            ]);

            if ($delivery->wasRecentlyCreated) {
                $queued++;
            }
        }

        if ($queued > 0) {
            SendWhatsappCampaignJob::dispatch($campaign->id, $channel->id);
        }

        return back()->with('success', __('Campaign queued for :count recipients.', ['count' => $queued]));
    }

    public function runTelegram(Request $request, MarketingCampaign $campaign): RedirectResponse
    {
        $this->authorizeCampaign($campaign);

        $bot = TelegramBot::query()->where('user_id', Auth::id())->first();
        if (! $bot) {
            return back()->with('error', __('Telegram is not configured.'));
        }

        // Prefer sending to Telegram groups captured by webhooks.
        $recipients = TelegramGroup::query()
            ->where('user_id', Auth::id())
            ->whereNotNull('group_id')
            ->pluck('group_id')
            ->unique()
            ->values();

        $queued = 0;
        foreach ($recipients as $chatId) {
            $delivery = MarketingDelivery::query()->firstOrCreate([
                'campaign_id' => $campaign->id,
                'channel' => 'telegram',
                'recipient_type' => 'group',
                'recipient_id' => (string) $chatId,
            ], [
                'status' => 'queued',
            ]);

            if ($delivery->wasRecentlyCreated) {
                $queued++;
            }
        }

        if ($queued > 0) {
            SendTelegramCampaignJob::dispatch($campaign->id, $bot->id);
        }

        return back()->with('success', __('Campaign queued for :count recipients.', ['count' => $queued]));
    }


    public function runSms(Request $request, MarketingCampaign $campaign): RedirectResponse
    {
        $this->authorizeCampaign($campaign);

        $channel = SmsChannel::query()->where('user_id', Auth::id())->first();
        if (! $channel) {
            return back()->with('error', __('SMS is not configured.'));
        }

        $contactIds = (array) ($campaign->contacts ?? []);

        $q = Contact::query()
            ->where('user_id', Auth::id())
            ->where('status', 1)
            ->whereNotNull('phone');

        if (! empty($contactIds)) {
            $q->whereIn('id', $contactIds);
        }

        $recipients = $q->pluck('phone')->unique()->values();

        $queued = 0;
        foreach ($recipients as $to) {
            $delivery = MarketingDelivery::query()->firstOrCreate([
                'campaign_id' => $campaign->id,
                'channel' => 'sms',
                'recipient_type' => 'contact',
                'recipient_id' => (string) $to,
            ], [
                'status' => 'queued',
            ]);

            if ($delivery->wasRecentlyCreated) {
                $queued++;
            }
        }

        if ($queued > 0) {
            SendSmsCampaignJob::dispatch($campaign->id, $channel->id);
        }

        return back()->with('success', __('Campaign queued for :count recipients.', ['count' => $queued]));
    }

    private function authorizeCampaign(MarketingCampaign $campaign): void
    {
        if ((int) $campaign->user_id !== (int) Auth::id()) {
            abort(403);
        }
    }
}
