<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Executor;

use App\Extensions\MarketingBot\System\Models\Email\EmailChannel;
use App\Extensions\MarketingBot\System\Models\MarketingCampaign;
use App\Extensions\MarketingBot\System\Models\MarketingConversation;
use App\Extensions\MarketingBot\System\Models\MarketingDelivery;
use App\Extensions\MarketingBot\System\Models\Sms\SmsChannel;
use App\Extensions\MarketingBot\System\Models\Whatsapp\Contact;
use App\Extensions\MarketingBot\System\Models\Whatsapp\WhatsappChannel;
use App\Extensions\MarketingBot\System\Services\Campaign\CampaignAudienceService;
use App\Extensions\MarketingBot\System\Services\Email\EmailSenderService;
use App\Extensions\MarketingBot\System\Services\Inbox\ConversationSummaryService;
use App\Extensions\MarketingBot\System\Services\Messenger\MessengerSenderService;
use App\Extensions\MarketingBot\System\Services\Safety\MessageComplianceService;
use App\Extensions\MarketingBot\System\Services\Sms\TwilioSmsSenderService;
use App\Extensions\MarketingBot\System\Services\Telegram\TelegramSenderService;
use App\Extensions\MarketingBot\System\Services\Whatsapp\WhatsappSenderService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CommunicationsExecutorController
{
    private function requireConfirmed(Request $request): void
    {
        if (!$request->boolean('confirmed')) {
            abort(400, 'confirmed=true is required');
        }
        if (!$request->filled('intent') || !$request->filled('intent_id') || !$request->filled('idempotency_key')) {
            abort(400, 'intent, intent_id, idempotency_key are required');
        }
    }

    private function alreadyProcessed(string $idempotencyKey): ?MarketingDelivery
    {
        return MarketingDelivery::query()->where('idempotency_key', $idempotencyKey)->first();
    }

    public function preview(Request $request, CampaignAudienceService $aud): JsonResponse
    {
        $campaign = MarketingCampaign::query()->findOrFail((int)($request->input('entities.campaign_id')));
        return response()->json(['ok' => true, 'preview' => $aud->preview($campaign)]);
    }

    public function analytics(Request $request): JsonResponse
    {
        $campaignId = (int)($request->input('entities.campaign_id'));
        $q = MarketingDelivery::query();
        if ($campaignId) $q->where('campaign_id', $campaignId);

        $byStatus = (clone $q)->selectRaw('status, count(*) as c')->groupBy('status')->pluck('c','status');
        $byChannel = (clone $q)->selectRaw('channel, count(*) as c')->groupBy('channel')->pluck('c','channel');

        return response()->json(['ok' => true, 'by_status' => $byStatus, 'by_channel' => $byChannel]);
    }

    public function schedule(Request $request): JsonResponse
    {
        $this->requireConfirmed($request);
        if ($request->input('intent') !== 'schedule_campaign') abort(400, 'intent must be schedule_campaign');

        $campaign = MarketingCampaign::query()->findOrFail((int)$request->input('entities.campaign_id'));
        $when = $request->input('entities.scheduled_for');
        if (!$when) abort(400, 'entities.scheduled_for required');

        $campaign->scheduled_for = $when;
        $campaign->state = 'scheduled';
        $campaign->save();

        return response()->json(['ok' => true, 'campaign_id' => $campaign->id, 'state' => $campaign->state]);
    }

    public function pause(Request $request): JsonResponse
    {
        $this->requireConfirmed($request);
        if ($request->input('intent') !== 'pause_campaign') abort(400, 'intent must be pause_campaign');

        $campaign = MarketingCampaign::query()->findOrFail((int)$request->input('entities.campaign_id'));
        $campaign->state = 'paused';
        $campaign->paused_at = now();
        $campaign->save();

        return response()->json(['ok' => true, 'campaign_id' => $campaign->id, 'state' => $campaign->state]);
    }

    public function cancel(Request $request): JsonResponse
    {
        $this->requireConfirmed($request);
        if ($request->input('intent') !== 'cancel_campaign') abort(400, 'intent must be cancel_campaign');

        $campaign = MarketingCampaign::query()->findOrFail((int)$request->input('entities.campaign_id'));
        $campaign->state = 'cancelled';
        $campaign->cancelled_at = now();
        $campaign->save();

        return response()->json(['ok' => true, 'campaign_id' => $campaign->id, 'state' => $campaign->state]);
    }

    public function draft(Request $request): JsonResponse
    {
        // Drafting is read-only; does not require confirmed=true
        $text = (string)($request->input('entities.text') ?? '');
        $svc = new MessageComplianceService();
        return response()->json([
            'ok' => true,
            'draft' => $text,
            'compliance' => $svc->warn($text),
        ]);
    }

    public function summarize(Request $request, ConversationSummaryService $svc): JsonResponse
    {
        $conversation = MarketingConversation::query()->findOrFail((int)$request->input('entities.conversation_id'));
        $summary = $svc->summarise($conversation);
        $conversation->summary = $summary;
        $conversation->save();

        return response()->json(['ok' => true, 'summary' => $summary]);
    }

    public function complianceWarning(Request $request, MessageComplianceService $svc): JsonResponse
    {
        $text = (string)($request->input('entities.text') ?? '');
        return response()->json(['ok' => true, 'result' => $svc->warn($text)]);
    }

    public function send(
        Request $request,
        CampaignAudienceService $aud,
        TwilioSmsSenderService $smsSender,
        WhatsappSenderService $waSender,
        TelegramSenderService $tgSender,
        MessengerSenderService $msSender,
        EmailSenderService $emailSender
    ): JsonResponse {
        $this->requireConfirmed($request);
        if ($request->input('intent') !== 'send_campaign_message') abort(400, 'intent must be send_campaign_message');

        $idempotencyKey = (string)$request->input('idempotency_key');
        if ($existing = $this->alreadyProcessed($idempotencyKey)) {
            return response()->json(['ok' => true, 'replayed' => true, 'delivery_id' => $existing->id]);
        }

        $campaign = MarketingCampaign::query()->findOrFail((int)$request->input('entities.campaign_id'));
        $channel = (string)($request->input('entities.channel') ?? $campaign->type);

        $preview = $aud->preview($campaign);
        $recipientIds = $preview['recipient_ids'];

        $media = (array)($request->input('entities.media_urls') ?? []);

        $results = [
            'queued' => 0,
            'sent' => 0,
            'failed' => 0,
        ];

        DB::transaction(function () use ($campaign, $channel, $recipientIds, $media, $idempotencyKey, $smsSender, $waSender, $tgSender, $msSender, $emailSender, &$results) {
            foreach ($recipientIds as $rid) {
                $contact = Contact::query()->find((int)$rid);
                if (!$contact) continue;

                // opt-out enforcement (local)
                $optOutCol = match ($channel) {
                    'sms' => 'opted_out_sms',
                    'email' => 'opted_out_email',
                    'whatsapp' => 'opted_out_whatsapp',
                    'telegram' => 'opted_out_telegram',
                    'messenger' => 'opted_out_messenger',
                    default => null,
                };
                if ($optOutCol && (bool)$contact->{$optOutCol}) {
                    MarketingDelivery::query()->create([
                        'campaign_id' => $campaign->id,
                        'channel' => $channel,
                        'recipient_type' => 'contact',
                        'recipient_id' => (string)$contact->id,
                        'status' => 'failed',
                        'error' => 'opted_out',
                        'idempotency_key' => $idempotencyKey,
                    ]);
                    $results['failed']++;
                    continue;
                }

                $delivery = MarketingDelivery::query()->create([
                    'campaign_id' => $campaign->id,
                    'channel' => $channel,
                    'recipient_type' => 'contact',
                    'recipient_id' => (string)$contact->id,
                    'status' => 'queued',
                    'idempotency_key' => $idempotencyKey,
                ]);
                $results['queued']++;

                $sendRes = ['ok' => false, 'provider_message_id' => null, 'error' => 'unknown'];

                if ($channel === 'sms') {
                    $smsChannel = SmsChannel::query()->where('user_id', $campaign->user_id)->first();
                    $to = (string)$contact->phone;
                    if (!$smsChannel || !$to) $sendRes = ['ok'=>false,'provider_message_id'=>null,'error'=>'missing_sms_channel_or_phone'];
                    else $sendRes = $smsSender->send($smsChannel, $to, (string)$campaign->content, $media);
                } elseif ($channel === 'whatsapp') {
                    $waChannel = WhatsappChannel::query()->where('user_id', $campaign->user_id)->first();
                    $to = (string)$contact->phone;
                    if (!$waChannel || !$to) $sendRes = ['ok'=>false,'provider_message_id'=>null,'error'=>'missing_whatsapp_channel_or_phone'];
                    else $sendRes = $waSender->sendText($waChannel, $to, (string)$campaign->content, $media);
                } elseif ($channel === 'email') {
                    $emailChannel = EmailChannel::query()->where('user_id', $campaign->user_id)->first();
                    $to = (string)$contact->email;
                    if (!$emailChannel || !$to) $sendRes = ['ok'=>false,'provider_message_id'=>null,'error'=>'missing_email_channel_or_email'];
                    else $sendRes = $emailSender->send($emailChannel, $to, (string)($campaign->name ?? 'Message'), (string)$campaign->content, []);
                } else {
                    // telegram/messenger: require identifiers in contact custom fields (not implemented here)
                    $sendRes = ['ok'=>false,'provider_message_id'=>null,'error'=>'channel_not_fully_configured'];
                }

                $delivery->status = $sendRes['ok'] ? 'sent' : 'failed';
                $delivery->provider_message_id = $sendRes['provider_message_id'];
                $delivery->error = $sendRes['error'];
                $delivery->sent_at = $sendRes['ok'] ? now() : null;
                $delivery->save();

                if ($sendRes['ok']) $results['sent']++; else $results['failed']++;
            }
        });

        return response()->json(['ok' => true, 'results' => $results]);
    }
}
