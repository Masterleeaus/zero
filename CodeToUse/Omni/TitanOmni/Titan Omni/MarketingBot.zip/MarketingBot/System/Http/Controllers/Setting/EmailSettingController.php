<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Setting;

use App\Extensions\MarketingBot\System\Models\Email\EmailChannel;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EmailSettingController extends Controller
{
    public function __invoke(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required','string','max:255'],
            'from_email' => ['nullable','email','max:255'],
            'from_name' => ['nullable','string','max:255'],
            'reply_to' => ['nullable','email','max:255'],
        ]);

        EmailChannel::query()->updateOrCreate(
            ['user_id' => Auth::id()],
            array_merge($data, ['user_id' => Auth::id()])
        );

        return back()->with('success', 'Email settings saved.');
    }
}
