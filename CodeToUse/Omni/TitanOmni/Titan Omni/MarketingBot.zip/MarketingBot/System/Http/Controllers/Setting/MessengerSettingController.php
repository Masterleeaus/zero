<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Setting;

use App\Extensions\MarketingBot\System\Models\Messenger\MessengerChannel;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MessengerSettingController extends Controller
{
    public function __invoke(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required','string','max:255'],
            'page_access_token' => ['required','string'],
            'verify_token' => ['required','string','max:255'],
            'page_id' => ['nullable','string','max:255'],
        ]);

        MessengerChannel::query()->updateOrCreate(
            ['user_id' => Auth::id()],
            [
                'name' => $data['name'],
                'page_access_token' => $data['page_access_token'],
                'verify_token' => $data['verify_token'],
                'page_id' => $data['page_id'] ?? null,
            ]
        );

        return back()->with('success', __('Messenger settings saved.'));
    }
}
