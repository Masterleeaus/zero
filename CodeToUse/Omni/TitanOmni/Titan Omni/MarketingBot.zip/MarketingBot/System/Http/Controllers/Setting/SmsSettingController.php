<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Setting;

use App\Extensions\MarketingBot\System\Models\Sms\SmsChannel;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SmsSettingController extends Controller
{
    public function __invoke(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'twilio_sid' => 'required|string|max:255',
            'twilio_token' => 'required|string|max:2048',
            'from_phone' => 'required|string|max:50',
            'status' => 'nullable|string|max:50',
        ]);

        SmsChannel::query()->updateOrCreate([
            'user_id' => Auth::id(),
        ], [
            'name' => $data['name'],
            'twilio_sid' => $data['twilio_sid'],
            'twilio_token' => $data['twilio_token'],
            'from_phone' => $data['from_phone'],
            'status' => $data['status'] ?? 'active',
        ]);

        return back()->with('success', __('SMS settings saved.'));
    }
}
