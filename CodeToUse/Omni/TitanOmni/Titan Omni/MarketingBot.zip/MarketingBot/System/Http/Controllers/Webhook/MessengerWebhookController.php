<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Webhook;

use App\Extensions\MarketingBot\System\Models\Messenger\MessengerChannel;
use App\Extensions\MarketingBot\System\Models\MarketingConversation;
use App\Extensions\MarketingBot\System\Models\MarketingMessageHistory;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class MessengerWebhookController extends Controller
{
    public function __invoke(Request $request, MessengerChannel $messengerChannel)
    {
        // Verification handshake (Facebook)
        if ($request->isMethod('get')) {
            $mode = $request->query('hub_mode');
            $token = $request->query('hub_verify_token');
            $challenge = $request->query('hub_challenge');

            if ($mode === 'subscribe' && $token === $messengerChannel->verify_token) {
                return response($challenge, 200);
            }

            return response('Forbidden', 403);
        }

        // Inbound messages
        $payload = $request->all();
        // Expect: entry[].messaging[].sender.id + message.text
        $entries = data_get($payload, 'entry', []);
        foreach ($entries as $entry) {
            $messagingEvents = data_get($entry, 'messaging', []);
            foreach ($messagingEvents as $evt) {
                $senderId = (string) data_get($evt, 'sender.id', '');
                $text = (string) data_get($evt, 'message.text', '');
                if ($senderId === '' || $text === '') {
                    continue;
                }

                $conversation = MarketingConversation::query()->firstOrCreate([
                    'type' => 'messenger',
                    'session_id' => $senderId,
                    'user_id' => $messengerChannel->user_id,
                ], [
                    'payload' => $payload,
                ]);

                MarketingMessageHistory::query()->create([
                    'conversation_id' => $conversation->id,
                    'message_id' => (string) (data_get($evt, 'message.mid') ?? ''),
                    'role' => 'user',
                    'message' => $text,
                    'message_type' => 'text',
                    'content_type' => 'text',
                ]);
            }
        }

        return response()->json(['ok' => true]);
    }
}
