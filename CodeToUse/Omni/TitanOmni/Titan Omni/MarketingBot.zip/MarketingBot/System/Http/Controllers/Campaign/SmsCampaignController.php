<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Campaign;

use App\Extensions\MarketingBot\System\Http\Requests\Campaign\CampaignSmsRequest;
use App\Extensions\MarketingBot\System\Models\MarketingCampaign;
use App\Extensions\MarketingBot\System\Models\Whatsapp\Contact;
use App\Extensions\MarketingBot\System\Models\Whatsapp\Segment;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class SmsCampaignController extends Controller
{
    public function index()
    {
        return view('marketing-bot::sms-campaign.index', [
            'title' => 'SMS Campaigns',
            'items' => MarketingCampaign::query()
                ->where('type', 'sms')
                ->where('user_id', Auth::id())
                ->orderByDesc('created_at')
                ->paginate(10),
        ]);
    }

    public function create(): View
    {
        return view('marketing-bot::sms-campaign.create', [
            'title'            => trans('New SMS Campaign'),
            'action'          => route('dashboard.user.marketing-bot.sms-campaign.update', $smsCampaign->id),
            'method'           => 'POST',
            'item'             => new MarketingCampaign,
            'contacts'         => Contact::my()->get(),
            'segments'         => Segment::my()->get(),
            'selectedContact'  => [],
            'selectedSegment'  => [],
        ]);
    }

    public function store(CampaignSmsRequest $request): RedirectResponse
    {
        $data = $request->validated();

        MarketingCampaign::query()->create($data);

        return redirect()->route('dashboard.user.marketing-bot.sms-campaign.index')
            ->with([
                'type'    => 'success',
                'message' => trans('SMS campaign created'),
            ]);
    }

    public function edit(Request $request, MarketingCampaign $smsCampaign): View
    {
        return view('marketing-bot::sms-campaign.create', [
            'title'           => trans('Edit SMS Campaign'),
            'action'          => route('dashboard.user.marketing-bot.sms-campaign.update', $smsCampaign->id),
            'method'          => 'PUT',
            'item'            => $smsCampaign,
            'contacts'        => Contact::my()->get(),
            'segments'        => Segment::query()->where('user_id', Auth::id())->get(),
            'selectedContact' => $smsCampaign->getAttribute('contacts') ?: [],
            'selectedSegment' => $smsCampaign->getAttribute('segments') ?: [],
        ]);
    }

    public function update(CampaignSmsRequest $request, MarketingCampaign $smsCampaign): RedirectResponse
    {
        $smsCampaign->update($request->validated());

        return redirect()->route('dashboard.user.marketing-bot.sms-campaign.index')
            ->with([
                'type'    => 'success',
                'message' => trans('SMS campaign updated'),
            ]);
    }

    public function destroy(MarketingCampaign $smsCampaign): JsonResponse
    {
        $smsCampaign->delete();

        return response()->json([
            'status'  => 'success',
            'message' => trans('SMS campaign deleted'),
        ]);
    }

    public function show(MarketingCampaign $smsCampaign) {}
}
