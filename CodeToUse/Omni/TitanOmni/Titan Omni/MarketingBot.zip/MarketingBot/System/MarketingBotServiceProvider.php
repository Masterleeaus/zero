<?php

declare(strict_types=1);

namespace App\Extensions\MarketingBot\System;

use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\MarketingBot\System\Http\Controllers\Campaign\GenerateController;
use App\Extensions\MarketingBot\System\Http\Controllers\Campaign\TelegramCampaignController;
use App\Extensions\MarketingBot\System\Http\Controllers\Campaign\WhatsappCampaignController;
use App\Extensions\MarketingBot\System\Http\Controllers\Campaign\SmsCampaignController;
use App\Extensions\MarketingBot\System\Http\Controllers\Campaign\EmailCampaignController;
use App\Extensions\MarketingBot\System\Http\Controllers\Campaign\CampaignRunnerController;
use App\Extensions\MarketingBot\System\Http\Controllers\InboxController;
use App\Extensions\MarketingBot\System\Http\Controllers\MarketingDashboardController;
use App\Extensions\MarketingBot\System\Http\Controllers\Setting\TelegramSettingController;
use App\Extensions\MarketingBot\System\Http\Controllers\Setting\ViewSettingController;
use App\Extensions\MarketingBot\System\Http\Controllers\Setting\WhatsappSettingController;
use App\Extensions\MarketingBot\System\Http\Controllers\Setting\SmsSettingController;
use App\Extensions\MarketingBot\System\Http\Controllers\Setting\EmailSettingController;
use App\Extensions\MarketingBot\System\Http\Controllers\Setting\MessengerSettingController;
use App\Extensions\MarketingBot\System\Http\Controllers\Telegram\TelegramGroupController;
use App\Extensions\MarketingBot\System\Http\Controllers\Telegram\TelegramSubscriberController;
use App\Extensions\MarketingBot\System\Http\Controllers\Webhook\TelegramWebhookController;
use App\Extensions\MarketingBot\System\Http\Controllers\Webhook\MessengerWebhookController;
use App\Extensions\MarketingBot\System\Http\Controllers\Webhook\WhatsappWebhookController;
use App\Extensions\MarketingBot\System\Http\Controllers\Executor\CommunicationsExecutorController;
use App\Extensions\MarketingBot\System\Http\Controllers\Whatsapp\ContactController;
use App\Extensions\MarketingBot\System\Http\Controllers\Whatsapp\ContactListController;
use App\Extensions\MarketingBot\System\Http\Controllers\Whatsapp\SegmentController;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class MarketingBotServiceProvider extends ServiceProvider implements UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->registerConfig();
    }

    public function boot(Kernel $kernel): void
    {
        $this->registerTranslations()
            ->registerViews()
            ->registerRoutes()
            ->registerMigrations()
            ->publishAssets()
            ->registerComponents();

    }

    public function registerComponents(): static
    {
        //        $this->loadViewComponentsAs('example', []);

        return $this;
    }

    public function publishAssets(): static
    {
        $this->publishes([
            __DIR__ . '/../resources/assets/images' => public_path('vendor/marketing-bot/images'),
        ], 'extension');

        return $this;
    }

    public function registerConfig(): static
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/marketing-bot.php', 'marketing-bot');

        return $this;
    }

    protected function registerTranslations(): static
    {
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', 'marketing-bot');

        return $this;
    }

    public function registerViews(): static
    {
        $this->loadViewsFrom([__DIR__ . '/../resources/views'], 'marketing-bot');

        return $this;
    }

    public function registerMigrations(): static
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');

        return $this;
    }

    private function registerRoutes(): static
    {
        $this->router()
            ->group([
                'middleware' => 'api',
                'prefix'     => 'api/marketing-bot',
                'as'         => 'api.marketing-bot.',
            ], function (Router $router) {
                $router->any('whatsapp/{whatsappChannel}/webhook', WhatsappWebhookController::class)->name('whatsapp.webhook');
                $router->any('telegram/webhook/{token}', TelegramWebhookController::class)->name('telegram.webhook');
                $router->any('messenger/{messengerChannel}/webhook', MessengerWebhookController::class)->name('messenger.webhook');
            });

        $this->router()
            ->group([
                'prefix'     => 'api/executors/communications',
                'as'         => 'executors.communications.',
                'middleware' => ['api'],
            ], function (Router $router) {
                $router->post('send', [CommunicationsExecutorController::class, 'send'])->name('send');
                $router->post('schedule', [CommunicationsExecutorController::class, 'schedule'])->name('schedule');
                $router->post('pause', [CommunicationsExecutorController::class, 'pause'])->name('pause');
                $router->post('cancel', [CommunicationsExecutorController::class, 'cancel'])->name('cancel');
                $router->post('preview', [CommunicationsExecutorController::class, 'preview'])->name('preview');
                $router->post('analytics', [CommunicationsExecutorController::class, 'analytics'])->name('analytics');
                $router->post('draft', [CommunicationsExecutorController::class, 'draft'])->name('draft');
                $router->post('summarize', [CommunicationsExecutorController::class, 'summarize'])->name('summarize');
                $router->post('compliance-warning', [CommunicationsExecutorController::class, 'complianceWarning'])->name('compliance-warning');
            });

        $this->router()
            ->group([
                'controller' => InboxController::class,
                'prefix'     => 'dashboard/user/marketing-bot/inbox',
                'as'         => 'dashboard.user.marketing-bot.inbox.',
                'middleware' => ['web', 'auth'],
            ], function (Router $router) {
                $router->get('', 'index')->name('index');
                $router->post('conversations/name', 'name')->name('conversations.name.update');
                $router->get('conversations', 'conversations')->name('conversations');
                $router->post('conversations/search', 'searchConversation')->name('conversations.search');
                $router->get('conversations-with-paginate', 'conversationsWithPaginate')->name('conversations.with.paginate');
                $router->get('history', 'history')->name('history');
                $router->post('history', 'store');
                $router->delete('destroy', 'destroy')->name('destroy');
            });
        $this->router()
            ->group([
                'middleware' => [
                    'web', 'auth',
                ],
                'prefix'     => 'dashboard/user/marketing-bot',
                'as'         => 'dashboard.user.marketing-bot.',
            ], function (Router $router) {

                $router->get('', MarketingDashboardController::class)->name('dashboard');

                $router->post('image/upload', [GenerateController::class, 'image'])->name('image.upload');
                $router->post('generate/content', [GenerateController::class, 'generateContent'])->name('generate.content');

                $router->resource('telegram-campaign', TelegramCampaignController::class);
                $router->resource('whatsapp-campaign', WhatsappCampaignController::class);
                $router->resource('sms-campaign', SmsCampaignController::class);
                $router->resource('email-campaign', EmailCampaignController::class);



                $router->resource('contact', ContactController::class)->except('show', 'create');
                $router->resource('segment', SegmentController::class)->except('show', 'create');
                $router->resource('contact-list', ContactListController::class)->except('show');

                $router->resource('telegram-group', TelegramGroupController::class)
                    ->only(['index', 'destroy']);

                $router->resource('telegram-subscriber', TelegramSubscriberController::class)
                    ->only(['index', 'destroy']);
            });
        $this->router()
            ->group([
                'middleware' => ['web', 'auth'],
                'prefix'     => 'dashboard/user/marketing-bot/settings',
                'as'         => 'dashboard.user.marketing-bot.settings.',
            ], function (Router $router) {
                $router->get('', ViewSettingController::class)->name('index');
                $router->post('telegram', TelegramSettingController::class)->name('telegram');
                $router->post('whatsapp', WhatsappSettingController::class)->name('whatsapp');
                $router->post('messenger', MessengerSettingController::class)->name('messenger');
                $router->post('sms', SmsSettingController::class)->name('sms');
                $router->post('email', EmailSettingController::class)->name('email');
            });

        return $this;
    }

    private function router(): Router|Route
    {
        return $this->app['router'];
    }

    public static function uninstall(): void
    {
        // TODO: Implement uninstall() method.
    }
}