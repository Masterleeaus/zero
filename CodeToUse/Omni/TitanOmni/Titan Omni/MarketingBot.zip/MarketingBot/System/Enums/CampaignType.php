<?php

namespace App\Extensions\MarketingBot\System\Enums;

enum CampaignType: string
{
    case telegram = 'telegram';
    case whatsapp = 'whatsapp';
    case sms = 'sms';
    case email = 'email';
    case messenger = 'messenger';
}
