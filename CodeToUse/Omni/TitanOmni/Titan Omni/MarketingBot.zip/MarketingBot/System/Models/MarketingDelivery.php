<?php

namespace App\Extensions\MarketingBot\System\Models;

use Illuminate\Database\Eloquent\Model;

class MarketingDelivery extends Model
{
    protected $table = 'ext_marketing_deliveries';

    protected $fillable = [
        'idempotency_key',
        'campaign_id',
        'channel',
        'recipient_type',
        'recipient_id',
        'status',
        'provider_message_id',
        'error',
        'sent_at',
    ];

    protected $casts = [
        'sent_at' => 'datetime',
    ];
}
