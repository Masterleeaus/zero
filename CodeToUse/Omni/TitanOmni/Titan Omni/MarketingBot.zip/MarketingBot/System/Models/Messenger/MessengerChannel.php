<?php

namespace App\Extensions\MarketingBot\System\Models\Messenger;

use Illuminate\Database\Eloquent\Model;

class MessengerChannel extends Model
{
    protected $table = 'ext_messenger_channels';

    protected $fillable = [
        'user_id',
        'name',
        'page_access_token',
        'verify_token',
        'page_id',
    ];

    protected $casts = [
        'page_access_token' => 'encrypted',
        'verify_token' => 'encrypted',
    ];
}
