<?php

namespace App\Extensions\MarketingBot\System\Models\Email;

use Illuminate\Database\Eloquent\Model;

class EmailChannel extends Model
{
    protected $table = 'ext_email_channels';

    protected $fillable = [
        'user_id',
        'name',
        'from_email',
        'from_name',
        'reply_to',
    ];
}
