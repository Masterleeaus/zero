<?php

namespace App\Extensions\MarketingBot\System\Models\Whatsapp;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    protected $table = 'ext_contacts';

    protected $fillable = [
        'user_id',
        'name',
        'phone',
        'status',
        'opted_out_sms',
        'opted_out_email',
        'opted_out_whatsapp',
        'opted_out_telegram',
        'opted_out_messenger',
    ];

    public function scopeMy(Builder $builder, int $status = 1): void
    {
        $builder
            ->where('user_id', auth()->id())
            ->where('status',
        'opted_out_sms',
        'opted_out_email',
        'opted_out_whatsapp',
        'opted_out_telegram',
        'opted_out_messenger', $status);
    }
}
