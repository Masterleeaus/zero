<?php

namespace App\Extensions\MarketingBot\System\Models\Sms;

use Illuminate\Database\Eloquent\Model;

class SmsChannel extends Model
{
    protected $table = 'ext_sms_channels';

    protected $fillable = [
        'user_id',
        'name',
        'twilio_sid',
        'twilio_token',
        'from_number',
    ];

    protected $hidden = [
        'twilio_token',
    ];
}
