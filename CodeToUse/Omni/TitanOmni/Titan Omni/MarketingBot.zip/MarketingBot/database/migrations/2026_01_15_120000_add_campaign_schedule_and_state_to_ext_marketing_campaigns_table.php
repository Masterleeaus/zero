<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('ext_marketing_campaigns', function (Blueprint $table) {
            if (!Schema::hasColumn('ext_marketing_campaigns', 'scheduled_for')) {
                $table->timestamp('scheduled_for')->nullable()->index();
            }
            if (!Schema::hasColumn('ext_marketing_campaigns', 'state')) {
                $table->string('state')->default('draft')->index(); // draft|scheduled|paused|cancelled|running|completed
            }
            if (!Schema::hasColumn('ext_marketing_campaigns', 'paused_at')) {
                $table->timestamp('paused_at')->nullable();
            }
            if (!Schema::hasColumn('ext_marketing_campaigns', 'cancelled_at')) {
                $table->timestamp('cancelled_at')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('ext_marketing_campaigns', function (Blueprint $table) {
            foreach (['scheduled_for','state','paused_at','cancelled_at'] as $col) {
                if (Schema::hasColumn('ext_marketing_campaigns', $col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }
};
