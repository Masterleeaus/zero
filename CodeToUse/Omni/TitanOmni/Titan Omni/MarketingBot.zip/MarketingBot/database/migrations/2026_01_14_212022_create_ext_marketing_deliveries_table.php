<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ext_marketing_deliveries', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('campaign_id')->index();
            $table->string('channel'); // whatsapp|telegram|messenger
            $table->string('recipient_type');
            $table->string('recipient_id');
            $table->string('status')->default('queued'); // queued|sent|failed
            $table->string('provider_message_id')->nullable();
            $table->text('error')->nullable();
            $table->timestamp('sent_at')->nullable();
            $table->timestamps();

            $table->index(['campaign_id', 'status']);
            $table->unique(['campaign_id', 'channel', 'recipient_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_marketing_deliveries');
    }
};
