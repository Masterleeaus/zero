<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('ext_marketing_conversations', function (Blueprint $table) {
            if (!Schema::hasColumn('ext_marketing_conversations', 'summary')) {
                $table->text('summary')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('ext_marketing_conversations', function (Blueprint $table) {
            if (Schema::hasColumn('ext_marketing_conversations', 'summary')) {
                $table->dropColumn('summary');
            }
        });
    }
};
