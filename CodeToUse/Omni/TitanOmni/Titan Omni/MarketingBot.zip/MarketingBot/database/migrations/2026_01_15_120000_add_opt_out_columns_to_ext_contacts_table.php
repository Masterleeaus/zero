<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('ext_contacts', function (Blueprint $table) {
            if (!Schema::hasColumn('ext_contacts', 'opted_out_sms')) {
                $table->boolean('opted_out_sms')->default(false);
            }
            if (!Schema::hasColumn('ext_contacts', 'opted_out_email')) {
                $table->boolean('opted_out_email')->default(false);
            }
            if (!Schema::hasColumn('ext_contacts', 'opted_out_whatsapp')) {
                $table->boolean('opted_out_whatsapp')->default(false);
            }
            if (!Schema::hasColumn('ext_contacts', 'opted_out_telegram')) {
                $table->boolean('opted_out_telegram')->default(false);
            }
            if (!Schema::hasColumn('ext_contacts', 'opted_out_messenger')) {
                $table->boolean('opted_out_messenger')->default(false);
            }
        });
    }

    public function down(): void
    {
        Schema::table('ext_contacts', function (Blueprint $table) {
            foreach (['opted_out_sms','opted_out_email','opted_out_whatsapp','opted_out_telegram','opted_out_messenger'] as $col) {
                if (Schema::hasColumn('ext_contacts', $col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }
};
