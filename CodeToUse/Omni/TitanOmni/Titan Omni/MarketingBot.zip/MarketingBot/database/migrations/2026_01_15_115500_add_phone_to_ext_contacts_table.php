<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('ext_contacts', function (Blueprint $table) {
            if (!Schema::hasColumn('ext_contacts', 'phone')) {
                $table->string('phone')->nullable()->index();
            }
        });
    }

    public function down(): void
    {
        Schema::table('ext_contacts', function (Blueprint $table) {
            if (Schema::hasColumn('ext_contacts', 'phone')) {
                $table->dropColumn('phone');
            }
        });
    }
};
