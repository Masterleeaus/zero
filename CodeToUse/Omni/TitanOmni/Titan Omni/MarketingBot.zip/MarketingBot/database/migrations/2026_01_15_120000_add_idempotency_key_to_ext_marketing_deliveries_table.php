<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('ext_marketing_deliveries', function (Blueprint $table) {
            if (!Schema::hasColumn('ext_marketing_deliveries', 'idempotency_key')) {
                $table->string('idempotency_key')->nullable()->index();
            }
        });
    }

    public function down(): void
    {
        Schema::table('ext_marketing_deliveries', function (Blueprint $table) {
            if (Schema::hasColumn('ext_marketing_deliveries', 'idempotency_key')) {
                $table->dropColumn('idempotency_key');
            }
        });
    }
};
