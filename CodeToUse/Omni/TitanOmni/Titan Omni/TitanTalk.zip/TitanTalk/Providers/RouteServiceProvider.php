<?php

namespace Modules\TitanTalk\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    public function map(): void
    {
        $base = __DIR__ . '/../Routes';

        $web = $base . '/web.php';
        if (file_exists($web)) {
            Route::middleware('web')
                ->namespace('Modules\TitanTalk\Http\Controllers')
                ->group($web);
        }

        $api = $base . '/api.php';
        if (file_exists($api)) {
            Route::prefix('api')
                ->middleware('api')
                ->namespace('Modules\TitanTalk\Http\Controllers')
                ->group($api);
        }
    }
}
