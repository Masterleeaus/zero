<?php

use Illuminate\Support\Facades\Route;

// Web admin settings + Titan Talk management
Route::middleware(['web','auth'])->prefix('aiconverse')->group(function () {
    Route::get('/settings', 'SettingsController@index')->name('titantalk.settings');
    Route::post('/settings', 'SettingsController@save')->name('titantalk.settings.save');

    // Titan Talk – Conversations CRM linking
    Route::get('/conversations', 'ConversationController@index')->name('titantalk.conversations.index');
    Route::put('/conversations/{conversation}/crm', 'ConversationController@updateCrm')->name('titantalk.conversations.update-crm');
    Route::get('/conversations/{conversation}', 'ConversationController@show')->name('titantalk.conversations.show');

    // Titan Talk – Voice Bot manager
    Route::get('/voice-bots', 'VoiceBotController@index')->name('titantalk.voice-bots.index');
    Route::get('/voice-bots/create', 'VoiceBotController@create')->name('titantalk.voice-bots.create');
    Route::post('/voice-bots', 'VoiceBotController@store')->name('titantalk.voice-bots.store');
    Route::get('/voice-bots/{voice_bot}/edit', 'VoiceBotController@edit')->name('titantalk.voice-bots.edit');
    Route::put('/voice-bots/{voice_bot}', 'VoiceBotController@update')->name('titantalk.voice-bots.update');
    Route::delete('/voice-bots/{voice_bot}', 'VoiceBotController@destroy')->name('titantalk.voice-bots.destroy');

    // Titan Talk – Dashboard
    Route::get('/dashboard', 'DashboardController@index')->name('titantalk.dashboard');
});

// API chat endpoint (auth:api guard) - internal app usage
Route::middleware(['api','auth:api'])->prefix('api/aiconverse')->group(function () {
    Route::post('/send', 'ConverseController@send')->name('titantalk.api.send');
});

// Public webhooks for external channels (Twilio, Telegram, Messenger, Voice, etc.)
Route::middleware(['api'])->prefix('api/aiconverse')->group(function () {
    Route::post('/hook/{driver}', 'WebhookController@receive')->name('titantalk.api.hook');
}
);
