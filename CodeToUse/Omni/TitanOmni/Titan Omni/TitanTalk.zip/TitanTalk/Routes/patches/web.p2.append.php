<?php
use Illuminate\Support\Facades\Route;

Route::middleware(['web','auth'])->prefix('aiconverse')->group(function () {
    // Intents
    Route::get('/intents', 'IntentController@index')->name('titantalk.intents.index');
    Route::get('/intents/create', 'IntentController#create')->name('titantalk.intents.create');
    Route::post('/intents', 'IntentController@store')->name('titantalk.intents.store');
    Route::get('/intents/{id}/edit', 'IntentController@edit')->name('titantalk.intents.edit');
    Route::put('/intents/{id}', 'IntentController@update')->name('titantalk.intents.update');
    Route::delete('/intents/{id}', 'IntentController@destroy')->name('titantalk.intents.delete');
    Route::get('/intents/export', 'IntentController@export')->name('titantalk.intents.export');
    Route::post('/intents/import', 'IntentController@import')->name('titantalk.intents.import');

    // Entities
    Route::get('/entities', 'EntityController@index')->name('titantalk.entities.index');
    Route::get('/entities/create', 'EntityController#create')->name('titantalk.entities.create');
    Route::post('/entities', 'EntityController@store')->name('titantalk.entities.store');
    Route::get('/entities/{id}/edit', 'EntityController@edit')->name('titantalk.entities.edit');
    Route::put('/entities/{id}', 'EntityController@update')->name('titantalk.entities.update');
    Route::delete('/entities/{id}', 'EntityController@destroy')->name('titantalk.entities.delete');
    Route::get('/entities/export', 'EntityController@export')->name('titantalk.entities.export');
    Route::post('/entities/import', 'EntityController@import')->name('titantalk.entities.import');

    // Training phrases
    Route::get('/training', 'TrainingPhraseController@index')->name('titantalk.training.index');
    Route::post('/training', 'TrainingPhraseController@store')->name('titantalk.training.store');
    Route::delete('/training/{id}', 'TrainingPhraseController@destroy')->name('titantalk.training.delete');
    Route::get('/training/export', 'TrainingPhraseController@export')->name('titantalk.training.export');
});
