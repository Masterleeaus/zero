<?php
namespace Modules\TitanTalk\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

class InjectTitanTalkMenu
{
    public function handle(Request $request, Closure $next): Response
    {
        /** @var \Symfony\Component\HttpFoundation\Response $response */
        $response = $next($request);

        // Only attempt on HTML responses
        $ct = $response->headers->get('Content-Type');
        if (!$ct || stripos($ct, 'text/html') === false) {
            return $response;
        }

        $html = $response->getContent();
        if (!is_string($html) || stripos($html, '</body>') === false) {
            return $response;
        }

        // Check entitlement
        $companyId = 0;
        try {
            $companyId = (int) (function_exists('tenant') && tenant() ? tenant()->id : (function_exists('company') && company() ? company()->id : 0));
        } catch (\Throwable $e) { $companyId = 0; }

        $entitled = true;
        try {
            if ($companyId > 0) {
                $entitled = DB::table('module_settings')
                    ->where('company_id', $companyId)
                    ->where('module_name', 'titan-talk')
                    ->where('status', 'active')
                    ->exists();
            }
        } catch (\Throwable $e) {
            $entitled = true; // be permissive if table missing
        }

        if (!$entitled) return $response;

        // Build menu li
        $label = __('modules.module.titan-talk');
        if ($label === 'modules.module.titan-talk') {
            $label = __('app.menu.titan-talk');
        }
        if ($label === 'app.menu.titan-talk') {
            $label = __('Titan Talk');
        }
        $li = '<li class="titan-talk-menu"><a href="'.route('titantalk.dashboard').'"><i class="fa fa-comments"></i> <span>'.$label.'</span></a></li>';
// Try common sidebar menu containers
        $patterns = [
            # classic adminlte/worksuite
            ('<ul class="sidebar-menu">','</ul>'),
            ('<ul class="side-menu">','</ul>'),
            ('<ul id="sidebarnav">','</ul>'),
        ];

        $injected = false;
        foreach ($patterns as $p) {
            $start = stripos($html, $p[0]);
            if ($start !== false):
                $end = stripos($html, $p[1], $start);
                if ($end !== false):
                    $html = substr($html, 0, $end) . $li . substr($html, $end);
                    $injected = true;
                    break;
                endif;
            endif;
        }

        // Fallback: inject near closing body as last resort
        if (!$injected) {
            $html = str_ireplace('</body>', $li.'</body>', $html);
        }

        $response->setContent($html);
        return $response;
    }
}
