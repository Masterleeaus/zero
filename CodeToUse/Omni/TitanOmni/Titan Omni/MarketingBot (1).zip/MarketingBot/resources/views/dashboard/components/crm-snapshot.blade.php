@php($s = $snapshot ?? [])
<div class="mt-6">
    <div class="mb-3 flex items-center justify-between">
        <div>
            <h3 class="m-0 text-base font-semibold text-heading-foreground">@lang('CRM Snapshot')</h3>
            <p class="m-0 text-2xs opacity-70">@lang('Customers, leads, and pipelines — live from your CRM core.')</p>
        </div>
        <div class="flex gap-2">
            <x-button size="sm" variant="secondary"
                href="{{ \Illuminate\Support\Facades\Route::has('dashboard.user.customers.index') ? route('dashboard.user.customers.index') : url('/dashboard/user/customers') }}">
                @lang('Open Customers')
            </x-button>
            <x-button size="sm" variant="primary"
                href="{{ \Illuminate\Support\Facades\Route::has('dashboard.user.customers.create') ? route('dashboard.user.customers.create') : url('/dashboard/user/customers/create') }}">
                <x-tabler-plus class="size-4" />
                @lang('New Customer')
            </x-button>
        </div>
    </div>

    <div class="grid grid-cols-1 gap-4 lg:grid-cols-4">
        <x-card class="flex flex-col justify-center" class:body="flex flex-col justify-center">
            <p class="m-0 text-2xs font-medium opacity-70">@lang('Total Customers')</p>
            <p class="m-0 text-2xl font-semibold">{{ (int)($s['customers_total'] ?? 0) }}</p>
            <p class="m-0 text-2xs opacity-60">@lang('New (7d):') {{ (int)($s['customers_new_7d'] ?? 0) }}</p>
        </x-card>

        <x-card class="flex flex-col justify-center" class:body="flex flex-col justify-center">
            <p class="m-0 text-2xs font-medium opacity-70">@lang('Total Leads')</p>
            <p class="m-0 text-2xl font-semibold">{{ (int)($s['leads_total'] ?? 0) }}</p>
            <p class="m-0 text-2xs opacity-60">@lang('New (7d):') {{ (int)($s['leads_new_7d'] ?? 0) }}</p>
        </x-card>

        <x-card class="flex flex-col justify-center" class:body="flex flex-col justify-center">
            <p class="m-0 text-2xs font-medium opacity-70">@lang('Pipelines')</p>
            <p class="m-0 text-2xl font-semibold">{{ (int)($s['pipelines_total'] ?? 0) }}</p>
            <p class="m-0 text-2xs opacity-60">@lang('Active:') {{ (int)($s['pipelines_active'] ?? 0) }}</p>
            <p class="m-0 text-2xs opacity-60">@lang('Pipeline Stages:') {{ (int)($s['stages_total'] ?? 0) }}</p>
        </x-card>

        <x-card class="flex flex-col justify-center" class:body="flex flex-col justify-center">
            <p class="m-0 text-2xs font-medium opacity-70">@lang('Quick Actions')</p>
            <div class="mt-2 flex flex-wrap gap-2">
                <x-button size="xs" variant="secondary"
                    href="{{ url('/dashboard/user/pipelines') }}">
                    @lang('Pipelines')
                </x-button>
                <x-button size="xs" variant="secondary"
                    href="{{ url('/dashboard/user/broadcasts') }}">
                    @lang('Broadcasts')
                </x-button>
                <x-button size="xs" variant="secondary"
                    href="{{ url('/dashboard/user/inbox') }}">
                    @lang('Inbox')
                </x-button>
            </div>
            <p class="mt-2 m-0 text-2xs opacity-60">@lang('These links are safe fallbacks.')</p>
        </x-card>
    </div>

    <div class="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <x-card class="overflow-hidden" class:body="p-0">
            <div class="border-b border-border px-4 py-3">
                <p class="m-0 text-sm font-semibold">@lang('Recent Customers')</p>
            </div>
            <div class="p-4">
                @if(($recentCustomers ?? collect())->count())
                    <div class="space-y-2">
                        @foreach($recentCustomers as $c)
                            <div class="flex items-center justify-between gap-3 rounded-md bg-heading-foreground/5 px-3 py-2">
                                <div class="min-w-0">
                                    <p class="m-0 truncate text-2xs font-medium">
                                        {{ $c->name ?: ($c->company_name ?: ('#'.$c->id)) }}
                                    </p>
                                    <p class="m-0 truncate text-3xs opacity-70">{{ $c->email ?? $c->phone ?? '' }}</p>
                                </div>
                                <x-button size="xs" variant="link"
                                    href="{{ url('/dashboard/user/customers/'.$c->id) }}">
                                    @lang('Open')
                                </x-button>
                            </div>
                        @endforeach
                    </div>
                @else
                    <p class="m-0 text-2xs opacity-70">@lang('No customers found yet.')</p>
                @endif
            </div>
        </x-card>

        <x-card class="overflow-hidden" class:body="p-0">
            <div class="border-b border-border px-4 py-3">
                <p class="m-0 text-sm font-semibold">@lang('Recent Leads')</p>
            </div>
            <div class="p-4">
                @if(($recentLeads ?? collect())->count())
                    <div class="space-y-2">
                        @foreach($recentLeads as $l)
                            <div class="flex items-center justify-between gap-3 rounded-md bg-heading-foreground/5 px-3 py-2">
                                <div class="min-w-0">
                                    <p class="m-0 truncate text-2xs font-medium">{{ $l->client_name ?? ('#'.$l->id) }}</p>
                                    <p class="m-0 truncate text-3xs opacity-70">{{ $l->client_email ?? '' }} {{ ($l->mobile ?? $l->cell ?? $l->office) ? '• '.($l->mobile ?? $l->cell ?? $l->office) : '' }} {{ $l->source_name ? '• '.$l->source_name : '' }} {{ $l->status_name ? '• '.$l->status_name : '' }} {{ $l->status ? '• '.$l->status : '' }}</p>
                                </div>
                                <x-button size="xs" variant="link"
                                    href="{{ \Illuminate\Support\Facades\Route::has('dashboard.user.leads.show') ? route('dashboard.user.leads.show', ['lead' => $l->id]) : url('/dashboard/user/leads/'.$l->id) }}">
                                    @lang('Open')
                                </x-button>
                            </div>
                        @endforeach
                    </div>
                @else
                    <p class="m-0 text-2xs opacity-70">@lang('No leads found yet.')</p>
                @endif
            </div>
        </x-card>
    </div>
</div>
