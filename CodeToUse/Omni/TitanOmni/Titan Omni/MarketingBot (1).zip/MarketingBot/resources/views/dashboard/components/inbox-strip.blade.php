<div class="mt-6">
  <div class="rounded-2xl border border-white/10 bg-[#0B5F75]/70 shadow-sm overflow-hidden">
    <div class="p-5 md:p-6">
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">

        {{-- Channels column --}}
        <div class="lg:col-span-3">
          <div class="text-white/80 text-sm font-semibold mb-3">Channels</div>
          <div class="space-y-3">
            <div class="rounded-xl border border-white/10 bg-black/10 px-4 py-3 flex items-center justify-between">
              <div>
                <div class="text-white font-semibold">WhatsApp</div>
                <div class="text-white/60 text-xs">Connected</div>
              </div>
              <div class="text-white/80 text-sm">0</div>
            </div>

            <div class="rounded-xl border border-white/10 bg-black/10 px-4 py-3 flex items-center justify-between">
              <div>
                <div class="text-white font-semibold">SMS</div>
                <div class="text-white/60 text-xs">Needs setup</div>
              </div>
              <div class="text-white/80 text-sm">0</div>
            </div>

            <div class="rounded-xl border border-white/10 bg-black/10 px-4 py-3 flex items-center justify-between">
              <div>
                <div class="text-white font-semibold">Calls</div>
                <div class="text-white/60 text-xs">Needs setup</div>
              </div>
              <div class="text-white/80 text-sm">0</div>
            </div>
          </div>

	          <div class="mt-4 flex flex-wrap gap-2">
	            {{-- MarketingBot defines per-channel campaign resources. Default to WhatsApp broadcasts. --}}
	            <a href="{{ route('dashboard.user.marketing-bot.whatsapp-campaign.index') }}" class="px-4 py-2 rounded-xl bg-white/15 hover:bg-white/20 text-white font-semibold">
	              Broadcasts
	            </a>
            <a href="{{ route('dashboard.user.crm.leads.index') }}" class="px-4 py-2 rounded-xl bg-white/15 hover:bg-white/20 text-white font-semibold">
              Leads
            </a>
            <a href="{{ route('dashboard.user.crm.customers.index') }}" class="px-4 py-2 rounded-xl bg-white/15 hover:bg-white/20 text-white font-semibold">
              Customers
            </a>
          </div>
        </div>

        {{-- Inbox column (compact) --}}
        <div class="lg:col-span-6">
          <div class="flex items-center justify-between mb-3">
            <div>
              <div class="text-white/80 text-sm font-semibold">Inbox</div>
              <div class="text-white/60 text-xs">Latest conversations + follow-ups (shows when channels are connected).</div>
            </div>
            <a href="{{ route('dashboard.user.marketing-bot.inbox.index') }}" class="px-4 py-2 rounded-xl bg-white/15 hover:bg-white/20 text-white font-semibold">
              Open Inbox
            </a>
          </div>

          <div class="rounded-xl border border-white/10 bg-black/10 p-4">
            <div class="text-white font-semibold">Inbox preview will appear here once messages are connected.</div>
            <div class="text-white/60 text-sm mt-2">
              Next: connect WhatsApp/SMS → store threads/messages → show unread + latest previews.
            </div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
            <div class="rounded-xl border border-white/10 bg-black/10 p-4">
              <div class="text-white font-semibold">Follow-ups due</div>
              <div class="text-white/60 text-sm mt-1">We’ll populate this from leads + pipeline activity.</div>
            </div>
            <div class="rounded-xl border border-white/10 bg-black/10 p-4">
              <div class="text-white font-semibold">Delivery issues</div>
              <div class="text-white/60 text-sm mt-1">Failed sends / missing channel setup will show here.</div>
            </div>
          </div>
        </div>

        {{-- Quick stats --}}
        <div class="lg:col-span-3">
          <div class="text-white/80 text-sm font-semibold mb-3">Quick Stats</div>

          @php($t = $totals['today'] ?? [])

          <div class="grid grid-cols-2 gap-3">
            <div class="rounded-xl border border-white/10 bg-black/10 p-4">
              <div class="text-white/60 text-xs">Customers</div>
              <div class="text-white text-2xl font-bold mt-1">{{ $t['total_contacts'] ?? 0 }}</div>
            </div>
            <div class="rounded-xl border border-white/10 bg-black/10 p-4">
              <div class="text-white/60 text-xs">Leads</div>
              <div class="text-white text-2xl font-bold mt-1">{{ $t['total_leads'] ?? 0 }}</div>
            </div>
            <div class="rounded-xl border border-white/10 bg-black/10 p-4">
              <div class="text-white/60 text-xs">Pipelines</div>
              <div class="text-white text-2xl font-bold mt-1">{{ $t['pipelines'] ?? 1 }}</div>
            </div>
            <div class="rounded-xl border border-white/10 bg-black/10 p-4">
              <div class="text-white/60 text-xs">Stages</div>
              <div class="text-white text-2xl font-bold mt-1">{{ $t['stages'] ?? 7 }}</div>
            </div>
          </div>

          <div class="mt-3 grid grid-cols-2 gap-3">
            <div class="rounded-xl border border-white/10 bg-black/10 p-4">
              <div class="text-white/60 text-xs">SMS sent</div>
              <div class="text-white text-2xl font-bold mt-1">{{ $t['total_sms'] ?? 0 }}</div>
            </div>
            <div class="rounded-xl border border-white/10 bg-black/10 p-4">
              <div class="text-white/60 text-xs">Calls</div>
              <div class="text-white text-2xl font-bold mt-1">{{ $t['total_calls'] ?? 0 }}</div>
            </div>
          </div>

          <div class="mt-4">
            <a href="{{ route('dashboard.user.crm.pipelines.index') }}" class="w-full inline-flex items-center justify-center px-4 py-3 rounded-xl bg-white/15 hover:bg-white/20 text-white font-semibold">
              Open Pipeline Board
            </a>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>
