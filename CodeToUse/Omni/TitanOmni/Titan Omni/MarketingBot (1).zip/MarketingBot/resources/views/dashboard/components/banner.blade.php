@php
    $totals = $totals ?? [];
    $today  = $totals['today'] ?? [];

    // These are safe defaults until inbox + approvals are fully wired.
    $channelsActive   = ((int)($today['total_contacts'] ?? 0) > 0) ? 1 : 0;
    $messagesToday    = (int)($today['total_sms'] ?? 0);
    $failuresToday    = 0;
    $pendingApprovals = 0;
@endphp

<div
    class="group relative flex flex-wrap items-center justify-center gap-x-4 gap-y-7 overflow-hidden rounded-xl bg-gradient-to-r from-gradient-from/40 via-gradient-via/40 to-gradient-to/60 px-7 py-10 text-center dark:border dark:border-heading-foreground/10 dark:from-[rgba(186,255,219,0.07)] dark:via-[rgba(185,213,255,0.07)] dark:to-[rgba(228,188,252,0.07)] md:justify-start md:px-20 md:text-start">
    <div class="flex w-full flex-wrap items-center justify-center gap-x-7 gap-y-3 md:w-1/2 md:flex-nowrap md:justify-start">
        <div class="!flex flex-nowrap items-center justify-center gap-2.5 group-hover:motion-preset-confetti">
            <div class="size-16">
                <img
                    class="h-full w-full object-cover"
                    src="{{ asset('vendor/marketing-bot/images/telegram_banner.png') }}"
                    alt="@lang('Like Image')"
                >
            </div>
            <div class="size-16">
                <img
                    class="h-full w-full object-cover"
                    src="{{ asset('vendor/marketing-bot/images/whatsapp_banner.png') }}"
                    alt="@lang('Like Image')"
                >
            </div>
        </div>
        <h3 class="m-0 grow xl:pe-24">
            {{ trans('Message customers instantly on WhatsApp (and soon SMS/Calls) — fully linked to your CRM.') }}
        </h3>
    </div>

    <div class="md:ms-auto">
        <x-button
            href="{{ route('dashboard.user.marketing-bot.settings.index') }}"
            variant="ghost-shadow"
        >
            <x-tabler-settings class="size-4" />
            {{ trans('Channel Settings') }}
        </x-button>
    </div>

    {{-- Embedded Inbox strip (lives inside this hero card / big dark space). --}}
    <div class="w-full">
        <div class="rounded-xl border border-white/10 bg-black/10 p-5 text-start">
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <div class="text-sm font-semibold text-heading-foreground">{{ trans('Inbox') }}</div>
                    <div class="text-xs text-heading-foreground/60">{{ trans('Your latest conversations & follow-ups — right where you work.') }}</div>
                </div>

                <div class="flex flex-wrap items-center gap-2">
                    <x-button href="{{ route('dashboard.user.marketing-bot.inbox.index') }}" variant="ghost-shadow">
                        {{ trans('Open Inbox') }}
                    </x-button>
                    {{-- MarketingBot ships per-channel campaign resources (e.g. whatsapp-campaign, telegram-campaign).
                         Customer Connect defaults to WhatsApp broadcasts. --}}
                    <x-button href="{{ route('dashboard.user.marketing-bot.whatsapp-campaign.create') }}" variant="primary">
                        + {{ trans('New Broadcast') }}
                    </x-button>
                </div>
            </div>

            <div class="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
                <div class="rounded-xl border border-white/10 bg-black/10 p-4">
                    <div class="text-xs font-semibold uppercase tracking-wide text-heading-foreground/60">{{ trans('Channels') }}</div>
                    <div class="mt-3 space-y-2">
                        <div class="flex items-center justify-between rounded-lg border border-white/10 bg-black/10 px-3 py-2">
                            <div class="text-sm text-heading-foreground">WhatsApp</div>
                            <div class="text-xs text-heading-foreground/60">{{ $channelsActive > 0 ? trans('Connected') : trans('Not setup') }}</div>
                        </div>
                        <div class="flex items-center justify-between rounded-lg border border-white/10 bg-black/10 px-3 py-2">
                            <div class="text-sm text-heading-foreground">SMS</div>
                            <div class="text-xs text-heading-foreground/60">{{ trans('Bring your Twilio number') }}</div>
                        </div>
                        <div class="flex items-center justify-between rounded-lg border border-white/10 bg-black/10 px-3 py-2">
                            <div class="text-sm text-heading-foreground">Calls</div>
                            <div class="text-xs text-heading-foreground/60">{{ trans('Twilio Voice') }}</div>
                        </div>
                    </div>
                </div>

                <div class="rounded-xl border border-white/10 bg-black/10 p-4">
                    <div class="text-xs font-semibold uppercase tracking-wide text-heading-foreground/60">{{ trans('Preview') }}</div>
                    <div class="mt-3 rounded-lg border border-white/10 bg-black/10 p-3">
                        <div class="text-sm font-semibold text-heading-foreground">{{ trans('Inbox preview will appear here once messages are connected.') }}</div>
                        <div class="mt-1 text-xs text-heading-foreground/60">{{ trans('Next: connect WhatsApp/SMS → store threads/messages → show unread + latest previews.') }}</div>
                    </div>
                    <div class="mt-3 flex flex-wrap gap-3 text-sm">
                        <a class="text-heading-foreground/80 hover:text-heading-foreground" href="{{ route('dashboard.user.marketing-bot.settings.index') }}">{{ trans('Manage Channels') }}</a>
                        <span class="text-heading-foreground/30">•</span>
                        <a class="text-heading-foreground/80 hover:text-heading-foreground" href="{{ route('dashboard.user.marketing-bot.whatsapp-template.index') }}">{{ trans('Message Templates') }}</a>
                    </div>
                </div>

                <div class="rounded-xl border border-white/10 bg-black/10 p-4">
                    <div class="text-xs font-semibold uppercase tracking-wide text-heading-foreground/60">{{ trans('Today') }}</div>
                    <div class="mt-3 grid grid-cols-2 gap-2">
                        <div class="rounded-lg border border-white/10 bg-black/10 p-3">
                            <div class="text-xs text-heading-foreground/60">{{ trans('Channels') }}</div>
                            <div class="text-lg font-bold text-heading-foreground">{{ $channelsActive }}</div>
                        </div>
                        <div class="rounded-lg border border-white/10 bg-black/10 p-3">
                            <div class="text-xs text-heading-foreground/60">{{ trans('Sent') }}</div>
                            <div class="text-lg font-bold text-heading-foreground">{{ $messagesToday }}</div>
                        </div>
                        <div class="rounded-lg border border-white/10 bg-black/10 p-3">
                            <div class="text-xs text-heading-foreground/60">{{ trans('Failures') }}</div>
                            <div class="text-lg font-bold text-heading-foreground">{{ $failuresToday }}</div>
                        </div>
                        <div class="rounded-lg border border-white/10 bg-black/10 p-3">
                            <div class="text-xs text-heading-foreground/60">{{ trans('Approvals') }}</div>
                            <div class="text-lg font-bold text-heading-foreground">{{ $pendingApprovals }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
