<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ext_sms_channels', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->string('sms_provider')->default('twilio');
            $table->string('sms_sid')->nullable();
            $table->string('sms_token')->nullable();
            $table->string('sms_from_number')->nullable();
            $table->string('sms_environment')->default('production');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_sms_channels');
    }
};
