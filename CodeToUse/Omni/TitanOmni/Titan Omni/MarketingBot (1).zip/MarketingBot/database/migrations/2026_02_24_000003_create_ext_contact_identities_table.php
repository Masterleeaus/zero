<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ext_contact_identities', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('contact_id');
            $table->string('identity_type'); // phone | email | telegram | whatsapp
            $table->string('identity_value');
            $table->boolean('is_primary')->default(false);
            $table->timestamps();

            $table->index(['contact_id', 'identity_type']);
            $table->index(['identity_type', 'identity_value']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_contact_identities');
    }
};
