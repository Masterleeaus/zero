<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ext_marketing_inbound_payloads', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('conversation_id')->nullable();
            $table->string('channel')->nullable(); // sms | email | whatsapp | telegram
            $table->string('provider_message_id')->nullable();
            $table->json('payload')->nullable();
            $table->json('parsed')->nullable();
            $table->timestamp('received_at')->nullable();
            $table->timestamps();

            $table->index(['conversation_id']);
            $table->index(['channel']);
            $table->index(['provider_message_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_marketing_inbound_payloads');
    }
};
