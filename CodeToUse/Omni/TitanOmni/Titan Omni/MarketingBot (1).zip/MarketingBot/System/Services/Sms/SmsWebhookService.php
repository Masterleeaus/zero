<?php

namespace App\Extensions\MarketingBot\System\Services\Sms;

use App\Extensions\MarketingBot\System\Models\Inbound\InboundPayload;
use App\Extensions\MarketingBot\System\Models\MarketingConversation;
use App\Extensions\MarketingBot\System\Models\MarketingMessageHistory;
use App\Extensions\MarketingBot\System\Models\Sms\SmsChannel;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class SmsWebhookService
{
    public function handle(Request $request, SmsChannel $smsChannel): void
    {
        $conversation = $this->updateOrCreateMarketingConversation($request, $smsChannel);

        $body = (string) $request->input('Body', '');
        $smsSid = $request->input('SmsSid');

        // Store raw payload for audit/debug (optional but very useful)
        InboundPayload::query()->create([
            'conversation_id'      => $conversation->getKey(),
            'channel'              => 'sms',
            'provider_message_id'  => $smsSid,
            'payload'              => $request->all(),
            'parsed'               => [
                'from' => $request->input('From'),
                'to'   => $request->input('To'),
            ],
            'received_at'          => now(),
        ]);

        if (! empty($body)) {
            MarketingMessageHistory::query()->create([
                'conversation_id' => $conversation->getKey(),
                'message_id'      => $smsSid ?: random_int(100000000, 999999999),
                'model'           => null,
                'role'            => 'user',
                'message'         => $body,
                'type'            => 'default',
                'message_type'    => 'text',
                'content_type'    => 'text',
                'created_at'      => now(),
            ]);
        }
    }

    public function updateOrCreateMarketingConversation(Request $request, SmsChannel $smsChannel): Model|Builder
    {
        $from = (string) $request->input('From', '');
        $sessionId = Str::replaceFirst('+', '', $from);

        return MarketingConversation::query()
            ->firstOrCreate([
                'user_id'            => $smsChannel->getAttribute('user_id'),
                'type'               => 'sms',
                'session_id'         => $sessionId ?: Str::uuid()->toString(),
            ], [
                'conversation_name' => $sessionId ?: 'SMS',
                'customer_payload'  => [
                    'From' => $from,
                    'To'   => $request->input('To'),
                ],
            ]);
    }
}
