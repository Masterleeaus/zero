<?php

namespace App\Extensions\MarketingBot\System\Services\Email;

use App\Extensions\MarketingBot\System\Models\Email\EmailChannel;
use App\Extensions\MarketingBot\System\Models\Inbound\InboundPayload;
use App\Extensions\MarketingBot\System\Models\MarketingConversation;
use App\Extensions\MarketingBot\System\Models\MarketingMessageHistory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class EmailWebhookService
{
    /**
     * Provider-agnostic inbound handler.
     * Expects either JSON payload (recommended) or form-data.
     *
     * Minimal supported fields:
     * - from
     * - to
     * - subject (optional)
     * - text (preferred) OR body
     * - message_id (optional)
     */
    public function handle(Request $request, EmailChannel $emailChannel): void
    {
        // Optional verification: if inbound_secret exists, require it.
        if ($emailChannel->inbound_secret) {
            $secret = $request->header('X-Inbound-Secret') ?? $request->input('inbound_secret');
            if (! hash_equals((string) $emailChannel->inbound_secret, (string) $secret)) {
                abort(403);
            }
        }

        $conversation = $this->updateOrCreateMarketingConversation($request, $emailChannel);

        $text = (string) ($request->input('text') ?? $request->input('body') ?? '');
        $subject = (string) ($request->input('subject') ?? '');
        $providerId = (string) ($request->input('message_id') ?? $request->input('Message-Id') ?? '');

        InboundPayload::query()->create([
            'conversation_id'     => $conversation->getKey(),
            'channel'             => 'email',
            'provider_message_id' => $providerId ?: null,
            'payload'             => $request->all(),
            'parsed'              => [
                'from'    => $request->input('from'),
                'to'      => $request->input('to'),
                'subject' => $subject,
            ],
            'received_at'         => now(),
        ]);

        $messageText = trim($subject ? ($subject . "\n\n" . $text) : $text);

        if ($messageText !== '') {
            MarketingMessageHistory::query()->create([
                'conversation_id' => $conversation->getKey(),
                'message_id'      => $providerId ?: random_int(100000000, 999999999),
                'model'           => null,
                'role'            => 'user',
                'message'         => $messageText,
                'type'            => 'default',
                'message_type'    => 'text',
                'content_type'    => 'text',
                'created_at'      => now(),
            ]);
        }
    }

    public function updateOrCreateMarketingConversation(Request $request, EmailChannel $emailChannel): Model|Builder
    {
        $from = (string) $request->input('from', '');
        $sessionId = $this->normalizeEmailAsSessionId($from);

        return MarketingConversation::query()
            ->firstOrCreate([
                'user_id'    => $emailChannel->getAttribute('user_id'),
                'type'       => 'email',
                'session_id' => $sessionId ?: Str::uuid()->toString(),
            ], [
                'conversation_name' => $sessionId ?: 'Email',
                'customer_payload'  => [
                    'from' => $from,
                    'to'   => $request->input('to'),
                ],
            ]);
    }

    private function normalizeEmailAsSessionId(string $email): string
    {
        $email = trim(strtolower($email));
        // If the email contains a display name, try to extract inside <>
        if (str_contains($email, '<') && str_contains($email, '>')) {
            $between = Str::between($email, '<', '>');
            if (filter_var($between, FILTER_VALIDATE_EMAIL)) {
                return $between;
            }
        }
        return $email;
    }
}
