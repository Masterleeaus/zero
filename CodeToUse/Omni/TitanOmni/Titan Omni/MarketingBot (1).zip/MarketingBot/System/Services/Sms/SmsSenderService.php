<?php

namespace App\Extensions\MarketingBot\System\Services\Sms;

use App\Extensions\MarketingBot\System\Enums\CampaignStatus;
use App\Extensions\MarketingBot\System\Models\MarketingConversation;
use App\Extensions\MarketingBot\System\Models\MarketingMessageHistory;
use App\Extensions\MarketingBot\System\Models\Sms\SmsChannel;
use App\Extensions\MarketingBot\System\Models\Whatsapp\ContactList;
use App\Extensions\MarketingBot\System\Services\Common\Traits\HasMarketingCampaign;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Twilio\Rest\Client;

class SmsSenderService
{
    use HasMarketingCampaign;

    public ?SmsChannel $smsChannel = null;

    public function setSmsChannel($userId): self
    {
        $this->smsChannel = SmsChannel::query()->where('user_id', $userId)->first();

        return $this;
    }

    public function send(): void
    {
        $marketingCampaign = $this->getMarketingCampaign()->refresh();

        if ($marketingCampaign === CampaignStatus::running) {
            return;
        }

        $marketingCampaign->update(['status' => CampaignStatus::running->value]);

        $this->setSmsChannel($marketingCampaign->getAttribute('user_id'));

        if (! $this->smsChannel) {
            throw new Exception('SMS channel not found for user ID: ' . $marketingCampaign->getAttribute('user_id'));
        }

        $contacts = $marketingCampaign->getAttribute('contacts');
        $segments = $marketingCampaign->getAttribute('segments');

        $contactList = ContactList::query()
            ->whereHas('contacts', function ($query) use ($contacts) {
                $query->whereIn('contact_id', $contacts);
            })
            ->when($segments, function ($query) use ($segments) {
                $query->whereHas('segments', function ($query) use ($segments) {
                    $query->whereIn('segment_id', $segments);
                });
            })
            ->select('phone')
            ->get();

        if ($contactList->count()) {
            foreach ($contactList as $contact) {
                $this->sendMessageToContact($contact, (string) $marketingCampaign->getAttribute('content'));
            }
        }

        $marketingCampaign->update(['status' => CampaignStatus::published]);
    }

    public function sendMessageToContact(ContactList $contactList, string $content): void
    {
        try {
            $result = $this->sendText($contactList->phone, $content);

            $conversation = $this->updateOrCreateMarketingConversation($contactList->phone);

            MarketingMessageHistory::query()->create([
                'conversation_id' => $conversation->getKey(),
                'message_id'      => $result['sid'] ?? random_int(100000000, 999999999),
                'model'           => null,
                'role'            => 'user',
                'message'         => $content,
                'type'            => 'default',
                'message_type'    => 'text',
                'content_type'    => 'text',
                'created_at'      => now(),
            ]);
        } catch (Exception $e) {
            // swallow for campaign loop
        }
    }

    public function updateOrCreateMarketingConversation(string $phone): Model|Builder
    {
        $sessionId = Str::replaceFirst('+', '', $phone);

        return MarketingConversation::query()->firstOrCreate([
            'user_id'    => $this->smsChannel?->getAttribute('user_id'),
            'type'       => 'sms',
            'session_id' => $sessionId,
        ], [
            'conversation_name' => $sessionId,
            'customer_payload'  => [
                'From' => $phone,
            ],
        ]);
    }

    public function sendText(string $to, string $message): array
    {
        $client = $this->client();

        $to = $this->normalizePhone($to);
        $from = (string) $this->smsChannel?->sms_from_number;

        $msg = $client->messages->create($to, [
            'from' => $from,
            'body' => $message,
        ]);

        return [
            'sid' => $msg->__get('sid'),
        ];
    }

    private function normalizePhone(string $phone): string
    {
        $cleaned = preg_replace('/[\s-]+/', '', $phone);
        if (str_starts_with($cleaned, '+')) {
            return $cleaned;
        }
        return '+' . $cleaned;
    }

    private function client(): Client
    {
        return new Client((string) $this->smsChannel?->sms_sid, (string) $this->smsChannel?->sms_token);
    }
}
