<?php

namespace App\Extensions\MarketingBot\System\Services\Email;

use App\Extensions\MarketingBot\System\Models\Email\EmailChannel;
use Illuminate\Support\Facades\Mail;

class EmailSenderService
{
    public function sendText(EmailChannel $emailChannel, string $toEmail, string $subject, string $body): void
    {
        // Uses the application's mailer configuration.
        // Channel credentials are stored for governance + future provider drivers,
        // but we don't hot-swap mail config here.
        Mail::raw($body, function ($message) use ($emailChannel, $toEmail, $subject) {
            $message->to($toEmail)->subject($subject);
            if ($emailChannel->from_email) {
                $message->from($emailChannel->from_email, $emailChannel->from_name ?: null);
            }
        });
    }
}
