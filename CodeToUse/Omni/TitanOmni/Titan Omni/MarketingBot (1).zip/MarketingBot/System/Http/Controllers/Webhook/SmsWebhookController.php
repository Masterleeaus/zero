<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Webhook;

use App\Extensions\MarketingBot\System\Models\Sms\SmsChannel;
use App\Extensions\MarketingBot\System\Services\Sms\SmsWebhookService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SmsWebhookController extends Controller
{
    public function __construct(
        public SmsWebhookService $smsWebhookService,
    ) {}

    public function __invoke(Request $request, SmsChannel $smsChannel)
    {
        $this->smsWebhookService->handle($request, $smsChannel);

        // Twilio expects a 200 OK. We don't need to return any body.
        return response('OK', 200);
    }
}
