<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Setting;

use App\Extensions\MarketingBot\System\Models\Email\EmailChannel;
use App\Helpers\Classes\Helper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EmailSettingController extends Controller
{
    public function __invoke(Request $request)
    {
        if (Helper::appIsDemo()) {
            return back()->with([
                'status'  => 'error',
                'message' => trans('This feature is disabled in demo mode.'),
            ]);
        }

        $data = $request->validate([
            'email_provider'   => 'required|string',
            'from_email'       => 'required|email',
            'from_name'        => 'nullable|string',
            'smtp_host'        => 'nullable|string',
            'smtp_port'        => 'nullable|integer',
            'smtp_username'    => 'nullable|string',
            'smtp_password'    => 'nullable|string',
            'smtp_encryption'  => 'nullable|string',
            'api_key'          => 'nullable|string',
            'inbound_secret'   => 'nullable|string',
        ]);

        EmailChannel::query()->updateOrCreate([
            'user_id' => auth()->id(),
        ], $data);

        return back()->with([
            'message' => __('Email settings updated successfully.'),
            'type'    => 'success',
        ]);
    }
}
