<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Webhook;

use App\Extensions\MarketingBot\System\Models\Email\EmailChannel;
use App\Extensions\MarketingBot\System\Services\Email\EmailWebhookService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EmailWebhookController extends Controller
{
    public function __construct(
        public EmailWebhookService $emailWebhookService,
    ) {}

    public function __invoke(Request $request, EmailChannel $emailChannel)
    {
        $this->emailWebhookService->handle($request, $emailChannel);

        return response('OK', 200);
    }
}
