<?php

namespace App\Extensions\MarketingBot\System\Http\Controllers\Setting;

use App\Extensions\MarketingBot\System\Models\Sms\SmsChannel;
use App\Helpers\Classes\Helper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SmsSettingController extends Controller
{
    public function __invoke(Request $request)
    {
        if (Helper::appIsDemo()) {
            return back()->with([
                'status'  => 'error',
                'message' => trans('This feature is disabled in demo mode.'),
            ]);
        }

        $data = $request->validate([
            'sms_provider'    => 'required|string',
            'sms_sid'         => 'required|string',
            'sms_token'       => 'required|string',
            'sms_from_number' => 'required|string',
            'sms_environment' => 'required|string',
        ]);

        SmsChannel::query()->updateOrCreate([
            'user_id' => auth()->id(),
        ], $data);

        return back()->with([
            'message' => __('SMS settings updated successfully.'),
            'type'    => 'success',
        ]);
    }
}
