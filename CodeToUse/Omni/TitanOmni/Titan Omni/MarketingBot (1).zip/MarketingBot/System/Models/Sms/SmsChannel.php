<?php

namespace App\Extensions\MarketingBot\System\Models\Sms;

use Illuminate\Database\Eloquent\Model;

class SmsChannel extends Model
{
    protected $table = 'ext_sms_channels';

    protected $fillable = [
        'user_id',
        'sms_provider',
        'sms_sid',
        'sms_token',
        'sms_from_number',
        'sms_environment',
    ];
}
