<?php

namespace App\Extensions\MarketingBot\System\Models\Inbound;

use Illuminate\Database\Eloquent\Model;

class InboundPayload extends Model
{
    protected $table = 'ext_marketing_inbound_payloads';

    protected $fillable = [
        'conversation_id',
        'channel',
        'provider_message_id',
        'payload',
        'parsed',
        'received_at',
    ];

    protected $casts = [
        'payload' => 'array',
        'parsed' => 'array',
        'received_at' => 'datetime',
    ];
}
