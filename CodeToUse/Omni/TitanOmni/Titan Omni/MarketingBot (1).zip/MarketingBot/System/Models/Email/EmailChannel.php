<?php

namespace App\Extensions\MarketingBot\System\Models\Email;

use Illuminate\Database\Eloquent\Model;

class EmailChannel extends Model
{
    protected $table = 'ext_email_channels';

    protected $fillable = [
        'user_id',
        'email_provider',
        'from_email',
        'from_name',
        'smtp_host',
        'smtp_port',
        'smtp_username',
        'smtp_password',
        'smtp_encryption',
        'api_key',
        'inbound_secret',
    ];
}
