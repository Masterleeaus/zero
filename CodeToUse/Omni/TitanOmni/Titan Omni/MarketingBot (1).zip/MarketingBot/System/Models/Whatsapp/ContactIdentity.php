<?php

namespace App\Extensions\MarketingBot\System\Models\Whatsapp;

use Illuminate\Database\Eloquent\Model;

class ContactIdentity extends Model
{
    protected $table = 'ext_contact_identities';

    protected $fillable = [
        'contact_id',
        'identity_type',
        'identity_value',
        'is_primary',
    ];
}
