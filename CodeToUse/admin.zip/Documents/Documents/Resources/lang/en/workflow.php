<?php

return [
    'draft' => 'Draft',
    'review' => 'Review',
    'approved' => 'Approved',
    'archived' => 'Archived',
];
