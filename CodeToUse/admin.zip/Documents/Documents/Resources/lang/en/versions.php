<?php

return [
    'recent_versions' => 'Recent Versions',
    'restore' => 'Restore',
];
