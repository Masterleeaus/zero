<?php

return [
  'tags' => 'Tags',
  'manage' => 'Manage tags',
];
