<?php

return [
    'jobsite' => 'Jobsite',
    'job' => 'Job',
    'quote' => 'Quote',
    'invoice' => 'Invoice',
];
