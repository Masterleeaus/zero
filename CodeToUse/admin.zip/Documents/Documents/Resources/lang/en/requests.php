<?php

return [
  'requests' => 'Document Requests',
  'new' => 'New request',
  'upload_link' => 'Upload link',
];
