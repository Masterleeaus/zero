@if (!in_array('client', user_roles()) && user()->permission('view_asset') != 'none' && in_array(\Modules\Asset\Entities\AssetSetting::MODULE_NAME, user_modules()))
    <x-menu-item icon="display" :text="__('asset::app.menu.asset')" :link="route('assets.index')"
                 :addon="App::environment('demo')">
        <x-slot name="iconPath">
            <path
                d="M0 4s0-2 2-2h12s2 0 2 2v6s0 2-2 2h-4c0 .667.083 1.167.25 1.5H11a.5.5 0 0 1 0 1H5a.5.5 0 0 1 0-1h.75c.167-.333.25-.833.25-1.5H2s-2 0-2-2V4zm1.398-.855a.758.758 0 0 0-.254.302A1.46 1.46 0 0 0 1 4.01V10c0 .325.078.502.145.602.07.105.17.188.302.254a1.464 1.464 0 0 0 .538.143L2.01 11H14c.325 0 .502-.078.602-.145a.758.758 0 0 0 .254-.302 1.464 1.464 0 0 0 .143-.538L15 9.99V4c0-.325-.078-.502-.145-.602a.757.757 0 0 0-.302-.254A1.46 1.46 0 0 0 13.99 3H2c-.325 0-.502.078-.602.145z"/>
        </x-slot>
    </x-menu-item>
@endif
