<?php

return [
    'name' => 'SiteInspection'
];
